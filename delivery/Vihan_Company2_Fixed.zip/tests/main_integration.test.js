'use strict';
// main.js with a stubbed Electron: what does the window open when the Main PC is off / on?
const test = require('node:test'), assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const { spawn } = require('child_process');
const { createOfflineManager } = require('../runtime/electron-app/offline.js');
const TOKEN = 'tok123';

function env(withCache, port) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'vihan-main-'));
  const appdata = path.join(root, 'appdata'), userData = path.join(root, 'userdata');
  fs.mkdirSync(path.join(appdata, 'Vihan Enterprices'), { recursive: true }); fs.mkdirSync(userData, { recursive: true });
  fs.writeFileSync(path.join(appdata, 'Vihan Enterprices', 'connection.json'), JSON.stringify({ product: 'Vihan Enterprices', port, token: TOKEN, serverIpUrl: 'http://127.0.0.1:' + port, serverUrl: 'http://127.0.0.1:' + port }));
  if (withCache) {
    const dir = path.join(userData, 'OfflineCopy'); fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'offline-data.json'), JSON.stringify({ schemaVersion: 3, savedAt: new Date().toISOString(), revision: 5, items: { k1: { value: '1', keyRev: 1 } } }));
  }
  // legacy v1.0.34 snapshot that must be removed
  const legacyDir = path.join(userData, 'OfflineData'); fs.mkdirSync(legacyDir, { recursive: true });
  fs.writeFileSync(path.join(legacyDir, 'VihanClientReadOnlySnapshot.json'), '{"items":[]}');
  return { root, appdata, userData, legacy: path.join(legacyDir, 'VihanClientReadOnlySnapshot.json') };
}
function run(e, ms) {
  return new Promise((resolve, reject) => {
    const p = spawn(process.execPath, [path.join(__dirname, 'helpers', 'run_main_harness.js'), String(ms)], { env: { ...process.env, APPDATA: e.appdata, HARNESS_USERDATA: e.userData, ProgramData: path.join(e.root, 'none') } });
    let out = ''; p.stdout.on('data', d => out += d); p.stderr.on('data', d => out += d);
    p.on('close', () => { try { resolve(JSON.parse(out.trim().split('\n').pop())); } catch { reject(new Error('bad output: ' + out)); } });
  });
}
const deadPort = () => new Promise(r => { const s = http.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => r(p)); }); });

test('main.js: Main PC off + offline copy exists -> opens the local ORIGINAL app (read-only), once', async () => {
  const e = env(true, await deadPort());
  const r = await run(e, 2500);
  assert.ok(!r.crash, r.crash);
  const offlineLoads = r.loads.filter(u => /^http:\/\/127\.0\.0\.1:1789\d\/connect\?token=/.test(u));
  assert.strictEqual(offlineLoads.length, 1, JSON.stringify(r.loads));
  assert.strictEqual(r.loads.length, 1, 'no extra reloads: ' + JSON.stringify(r.loads));
  assert.ok(!fs.existsSync(e.legacy), 'old every-PC snapshot file is removed');
});
test('main.js: Main PC off + NO offline copy -> clear message, no data shown', async () => {
  const e = env(false, await deadPort());
  const r = await run(e, 2500);
  assert.ok(!r.crash, r.crash);
  assert.ok(r.loads.length >= 1 && r.loads.every(u => u.startsWith('data:')), JSON.stringify(r.loads));
  assert.match(r.loads[0], /offline copy/i);
});
test('main.js: Main PC on -> live app opens (not the offline copy); allowed PC syncs in background', async () => {
  const hits = [];
  const srv = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x'); hits.push(u.pathname);
    const j = (o, s = 200) => { const b = Buffer.from(JSON.stringify(o)); res.writeHead(s, { 'Content-Type': 'application/json', 'Content-Length': b.length }); res.end(b); };
    if (u.pathname === '/health') return j({ ok: true, product: 'Vihan Enterprices', serverName: 'MAIN' });
    if (u.pathname === '/api/offline/permission') return j({ ok: true, allowed: true });
    if (u.pathname === '/api/offline/data') return j({ full: true, revision: 3, items: { a: { value: '1', keyRev: 1 } } });
    if (u.pathname === '/api/offline/manifest') return j({ ok: true, items: [] });
    j({ error: 'nf' }, 404);
  });
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const port = srv.address().port;
  const e = env(false, port);
  const r = await run(e, 8500);
  srv.close();
  assert.ok(!r.crash, r.crash);
  assert.ok(r.loads.some(u => u.includes('/connect?token=' + TOKEN) && u.startsWith('http://127.0.0.1:' + port)), JSON.stringify(r.loads));
  assert.ok(!r.loads.some(u => /:1789\d\//.test(u)), 'must not open the offline copy while Main is on');
  assert.ok(hits.includes('/api/offline/permission') && hits.includes('/api/offline/data'), 'background sync ran: ' + hits);
  const saved = JSON.parse(fs.readFileSync(path.join(e.userData, 'OfflineCopy', 'offline-data.json'), 'utf8'));
  assert.strictEqual(saved.revision, 3);
});
