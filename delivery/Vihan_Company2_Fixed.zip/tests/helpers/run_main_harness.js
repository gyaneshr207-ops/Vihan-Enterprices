'use strict';
// Runs runtime/electron-app/main.js against a stubbed "electron" module and reports which URLs the window loaded.
// usage: node run_main_harness.js <ms-to-wait>      env: APPDATA, HARNESS_USERDATA
const Module = require('module'), path = require('path'), fs = require('fs');
const loads = [];
const ev = { on() {}, once() {} };
let openHandler = null, navHandler = null; const errorBoxes = [];
class BrowserWindow {
  constructor(o) { this.opts = o || {}; this.loaded = []; this.webContents = { setWindowOpenHandler: (h) => { if (!openHandler) openHandler = h; }, on: (n, f) => { if (n === 'will-navigate' && !navHandler) navHandler = f; }, executeJavaScript: async () => ({ pending: 0 }) }; BrowserWindow.all.push(this); }
  setMenuBarVisibility() {} maximize() {} show() {} focus() {} restore() {} isMinimized() { return false; } isDestroyed() { return false; } close() {}
  once() {} on() {}
  async loadURL(u) { this.loaded.push(String(u)); if (BrowserWindow.all[0] !== this) return; loads.push(String(u).startsWith('data:') ? 'data:' + decodeURIComponent(String(u).slice(30)).replace(/<style>[\s\S]*?<\/style>/g, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 400) : String(u)); }
}
BrowserWindow.all = []; BrowserWindow.getAllWindows = () => BrowserWindow.all;
const cleared = [];
const electron = {
  app: { setName() {}, setAppUserModelId() {}, commandLine: { appendSwitch() {} }, requestSingleInstanceLock: () => true, on() {}, whenReady: () => Promise.resolve(), getPath: (n) => n === 'userData' ? process.env.HARNESS_USERDATA : process.env.APPDATA, quit() {}, exit() {}, relaunch() {} },
  dialog: { showErrorBox: (t, m) => errorBoxes.push(String(m).split('\n')[0]) },
  BrowserWindow, shell: { openExternal: async () => {} },
  session: { defaultSession: { setPermissionCheckHandler() {}, setPermissionRequestHandler() {}, clearStorageData: (o) => { cleared.push(o.origin); return Promise.resolve(); } } }
};
const origLoad = Module._load;
Module._load = function (req, parent, isMain) { return req === 'electron' ? electron : origLoad.apply(this, arguments); };
process.resourcesPath = path.join(process.env.HARNESS_USERDATA, 'res');
process.on('uncaughtException', (e) => { console.log(JSON.stringify({ crash: String(e && e.stack || e) })); process.exit(1); });
process.on('unhandledRejection', (e) => { console.log(JSON.stringify({ crash: 'unhandled: ' + String(e && e.stack || e) })); process.exit(1); });
require(path.join(__dirname, '..', '..', 'runtime', 'electron-app', 'main.js'));
const cp = require('child_process'); const spawns = [];
setTimeout(async () => {
  let pressed = null;
  if (process.env.HARNESS_PRESS) {
    pressed = openHandler ? openHandler({ url: 'https://vihan-offline-admin.invalid/launch' }) : 'NO HANDLER';
    await new Promise(r => setTimeout(r, 400));
  }
  console.log(JSON.stringify({ loads, cleared, pressed, errorBoxes, childWindows: BrowserWindow.all.slice(1).map(w => ({ title: w.opts.title, loaded: w.loaded })) })); process.exit(0);
}, Number(process.argv[2]) || 1500);
