'use strict';
// Loads app/vihan-sync.js in a tiny fake browser and checks offline = read-only, online = unchanged.
const test = require('node:test'), assert = require('node:assert');
const fs = require('fs'), path = require('path'), vm = require('vm');
const SRC = fs.readFileSync(path.join(__dirname, '..', 'app', 'vihan-sync.js'), 'utf8');

function makeBrowser(offline) {
  const calls = { fetch: [], xhr: [], toasts: [] };
  class Storage { constructor() { this.m = new Map(); } getItem(k) { return this.m.has(k) ? this.m.get(k) : null; } setItem(k, v) { this.m.set(k, String(v)); } removeItem(k) { this.m.delete(k); } clear() { this.m.clear(); } key(i) { return [...this.m.keys()][i] ?? null; } get length() { return this.m.size; } }
  const el = () => ({ style: {}, classList: { toggle() {}, add() {}, remove() {} }, appendChild() {}, addEventListener() {}, setAttribute() {}, remove() {}, set innerHTML(v) {}, textContent: '' });
  const win = { __listeners: {} };
  win.addEventListener = () => {}; win.dispatchEvent = () => {};
  const sandbox = {
    window: win, Storage, localStorage: new Storage(), sessionStorage: new Storage(), console,
    document: { readyState: 'complete', hidden: false, head: el(), body: el(), createElement: () => el(), getElementById: (id) => (id === 'vihanServiceBadge' || id === 'vihanOfflineBanner' || id === 'vihanSaveProgress') ? null : el(), addEventListener() {}, querySelectorAll: () => [] },
    location: { port: offline ? '17890' : '17867', protocol: 'http:', hostname: '127.0.0.1', origin: 'http://127.0.0.1:' + (offline ? '17890' : '17867'), href: '', search: '' },
    fetch: (u) => { calls.fetch.push(String(u)); return Promise.reject(new Error('no network in test')); },
    XMLHttpRequest: class { open(m, u) { calls.xhr.push(u); } setRequestHeader() {} send() { setTimeout(() => this.onerror && this.onerror(), 1); } addEventListener() {} get upload() { return { addEventListener() {} }; } },
    requestAnimationFrame: (f) => setTimeout(f, 1), MutationObserver: class { observe() {} disconnect() {} takeRecords() { return []; } },
    setTimeout, clearTimeout, setInterval, clearInterval, Blob, TextEncoder, Uint8Array, DataView, URL, Date, JSON, Math, Promise, Object, Array, String, Number, Error, Map, Set, WeakSet, atob: (s) => Buffer.from(s, 'base64').toString('binary'), navigator: {}
  };
  sandbox.window.window = sandbox.window;
  Object.assign(win, sandbox); win.Storage = Storage;
  if (offline) { win.__VIHAN_OFFLINE__ = true; win.__VIHAN_OFFLINE_INFO__ = { savedAt: new Date(Date.now() - 5 * 3600e3).toISOString(), revision: 7 }; }
  vm.createContext(sandbox);
  vm.runInContext(SRC, sandbox);
  return { sandbox, win, calls };
}
const wait = (ms) => new Promise(r => setTimeout(r, ms));

test('offline: writing to localStorage never queues or sends anything to a server', async () => {
  const b = makeBrowser(true);
  b.sandbox.localStorage.setItem('company_1_daybook', '[1,2,3]');
  b.sandbox.localStorage.removeItem('company_1_daybook');
  await wait(400);
  assert.strictEqual(b.calls.xhr.length, 0, 'no XHR: ' + b.calls.xhr);
  assert.strictEqual(b.calls.fetch.length, 0, 'no fetch: ' + b.calls.fetch);
  assert.strictEqual(b.sandbox.localStorage.getItem('__vihan_pending_ops_v110'), null);
});
test('offline: attachment save and delete are refused', async () => {
  const b = makeBrowser(true);
  await assert.rejects(() => b.win.vihanBlobPut('d', 's', { id: 'x', blob: new Blob(['a']) }), /Offline Read-Only/);
  await assert.rejects(() => b.win.vihanBlobDelete('d', 's', 'x'), /Offline Read-Only/);
  assert.strictEqual(b.calls.fetch.length + b.calls.xhr.length, 0);
});
test('offline: file requests stay on the local origin (no Main PC / port+1)', async () => {
  const b = makeBrowser(true);
  await b.win.vihanBlobList('d', 's').catch(() => {});
  assert.ok(b.calls.fetch.length >= 1);
  for (const u of b.calls.fetch) assert.ok(u.startsWith('http://127.0.0.1:17890/') || u.startsWith('/api/'), u); // relative = same local origin
  assert.ok(b.calls.fetch.every(u => !u.includes(':17891')), 'must not use port+1');
});
test('offline: flush reports nothing pending and does not touch the network', async () => {
  const b = makeBrowser(true);
  assert.strictEqual(await b.win.vihanFlushPending(), true);
  assert.strictEqual(JSON.stringify(await b.win.vihanBeforeAppClose()), '{"pending":0}');
  assert.strictEqual(b.calls.xhr.length + b.calls.fetch.length, 0);
});
test('online (unchanged): a write is still queued and sent to /api/storage/batch', async () => {
  const b = makeBrowser(false);
  b.sandbox.localStorage.setItem('company_1_daybook', '[1]');
  await wait(300);
  assert.ok(b.calls.xhr.some(u => u === '/api/storage/batch'), 'xhr: ' + b.calls.xhr);
  assert.ok(b.calls.fetch.some(u => u.includes('/api/storage/changes')) || true);
});
test('online (unchanged): file service still uses main port + 1', async () => {
  const b = makeBrowser(false);
  await b.win.vihanBlobList('d', 's').catch(() => {});
  assert.ok(b.calls.fetch.some(u => u.startsWith('http://127.0.0.1:17868/')), b.calls.fetch.join(','));
});
