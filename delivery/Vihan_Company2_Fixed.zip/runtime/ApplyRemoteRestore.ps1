param([Parameter(Mandatory=$true)][string]$Archive)
$ErrorActionPreference='Stop'
$Product='Vihan Enterprices'
$Base=Join-Path $env:ProgramData $Product
$Data='D:\Vihan Enterprices\Data'
$BackupDir='D:\Vihan Enterprices\Backups'
$Inbox=Join-Path $Base 'RestoreInbox'
$Status=Join-Path $Inbox 'restore-status.json'
$MainTask='Vihan Enterprices Main Service'
$FilesTask='Vihan Enterprices File Service'
function Write-State([string]$state,[string]$detail){
  [pscustomobject]@{status=$state;detail=$detail;updatedAt=(Get-Date).ToString('o')} | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 $Status
}
function Stop-Tracked([string]$file){
  if(!(Test-Path $file)){return}
  try{
    $pidValue=[int](Get-Content $file -Raw)
    $process=Get-Process -Id $pidValue -ErrorAction SilentlyContinue
    if($process -and $process.ProcessName -match '^(powershell|pwsh)$'){Stop-Process -Id $pidValue -Force -ErrorAction SilentlyContinue}
  }catch{}
}
$stage=Join-Path $Inbox ('validated_'+[guid]::NewGuid().ToString('N'))
$prev=$Data+'_before_restore_'+(Get-Date -Format 'yyyyMMdd_HHmmss')
$switched=$false
try{
  if(!(Test-Path $Archive)){throw 'Uploaded archive not found'}
  New-Item -ItemType Directory -Path $stage -Force | Out-Null
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $zip=[IO.Compression.ZipFile]::OpenRead($Archive)
  try{
    foreach($entry in $zip.Entries){
      $name=$entry.FullName.Replace('\','/')
      if($name.StartsWith('/') -or $name -match '(^|/)\.\.(/|$)' -or $name -match '^[A-Za-z]:'){throw 'Unsafe archive file path'}
      if(!$name -or $name.EndsWith('/')){continue}
      $target=[IO.Path]::GetFullPath((Join-Path $stage $name))
      if(!$target.StartsWith(([IO.Path]::GetFullPath($stage)+'\'),[StringComparison]::OrdinalIgnoreCase)){throw 'Archive path escape detected'}
      New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
      [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$target,$true)
    }
  }finally{$zip.Dispose()}
  $manifest=Join-Path $stage 'backup_manifest.json'
  $dbFile=Join-Path $stage 'VihanEnterprices.db'
  if(!(Test-Path $manifest) -or !(Test-Path $dbFile)){throw 'Archive missing manifest or SQLite DB'}
  $meta=Get-Content $manifest -Raw | ConvertFrom-Json
  if([string]$meta.product -ne $Product){throw 'Not a Vihan Enterprices backup'}
  $stream=[IO.File]::OpenRead($dbFile)
  try{$sig=New-Object byte[] 16;[void]$stream.Read($sig,0,16);if([Text.Encoding]::ASCII.GetString($sig) -ne "SQLite format 3`0"){throw 'Not a valid SQLite database'}}finally{$stream.Dispose()}
  Write-State 'validated' 'Backup validated, stopping services'
  try{Stop-ScheduledTask -TaskName $MainTask -ErrorAction SilentlyContinue}catch{}
  try{Stop-ScheduledTask -TaskName $FilesTask -ErrorAction SilentlyContinue}catch{}
  Stop-Tracked (Join-Path $Base 'service.pid')
  Stop-Tracked (Join-Path $Base 'file_service.pid')
  Start-Sleep -Seconds 2
  if(Test-Path $Data){Move-Item -LiteralPath $Data -Destination $prev -ErrorAction Stop}
  $switched=$true
  New-Item -ItemType Directory -Path $Data -Force | Out-Null
  Copy-Item -LiteralPath $dbFile -Destination (Join-Path $Data 'VihanEnterprices.db') -Force
  $blobs=Join-Path $stage 'Blobs'
  if(Test-Path $blobs){Copy-Item -LiteralPath $blobs -Destination (Join-Path $Data 'Blobs') -Recurse -Force}
  else{New-Item -ItemType Directory -Path (Join-Path $Data 'Blobs') -Force | Out-Null}
  # WAL/shm are not restored. Backup writer checkpoints before copying main db.
  Write-State 'complete' ('Restored. Previous data retained: '+$prev)
}catch{
  $detail=$_.Exception.ToString()
  if($switched){
    try{if(Test-Path $Data){Remove-Item $Data -Recurse -Force};if(Test-Path $prev){Move-Item $prev $Data}}catch{$detail+='; rollback failed: '+$_.Exception.Message}
  }
  Write-State 'failed' $detail
}finally{
  try{Start-ScheduledTask -TaskName $MainTask -ErrorAction SilentlyContinue}catch{}
  try{Start-ScheduledTask -TaskName $FilesTask -ErrorAction SilentlyContinue}catch{}
  Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item $Archive -Force -ErrorAction SilentlyContinue
}
