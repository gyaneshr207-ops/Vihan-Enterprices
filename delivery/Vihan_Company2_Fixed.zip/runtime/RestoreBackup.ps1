$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Windows.Forms
$Product='Vihan Enterprices';$Base=Join-Path $env:ProgramData $Product;$DBase='D:\Vihan Enterprices';if(!(Test-Path 'D:\')){[System.Windows.Forms.MessageBox]::Show('D: drive available nahi hai. Restore cancel kiya gaya.',$Product,'OK','Error')|Out-Null;exit 2};$Data=Join-Path $DBase 'Data';$Pid=Join-Path $Base 'service.pid';$TaskName='Vihan Enterprices Main Service'
$d=New-Object System.Windows.Forms.OpenFileDialog;$d.Title='Vihan Enterprices Backup ZIP Select Karein';$d.Filter='Vihan Backup (*.zip)|*.zip'
$serverJson=Join-Path $Base 'server.json';try{if(Test-Path $serverJson){$sc=Get-Content $serverJson -Raw|ConvertFrom-Json;if($sc.backupDir -and (Test-Path ([string]$sc.backupDir))){$d.InitialDirectory=[string]$sc.backupDir}}}catch{}
if($d.ShowDialog() -ne 'OK'){exit}
if([System.Windows.Forms.MessageBox]::Show('Restore se current central data replace hoga. Continue?',$Product,'YesNo','Warning') -ne 'Yes'){exit}
try{Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue}catch{}
if(Test-Path $Pid){try{$id=[int](Get-Content $Pid -Raw);Stop-Process -Id $id -Force -ErrorAction SilentlyContinue;Start-Sleep 1}catch{}}
$stage=Join-Path $env:TEMP ('VihanRestore_'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $stage|Out-Null;Expand-Archive -Path $d.FileName -DestinationPath $stage -Force
if(!(Test-Path (Join-Path $stage 'backup_manifest.json'))){throw 'Invalid Vihan backup'}
$pre=Join-Path $DBase ('PreRestore_'+(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'));if(Test-Path $Data){Move-Item $Data $pre -Force};New-Item -ItemType Directory -Force -Path $Data|Out-Null;Copy-Item (Join-Path $stage '*') $Data -Recurse -Force;Remove-Item (Join-Path $Data 'backup_manifest.json') -Force -ErrorAction SilentlyContinue;Remove-Item $stage -Recurse -Force
try{Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop}catch{Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $PSScriptRoot 'MainService.ps1')+'"'))}
[System.Windows.Forms.MessageBox]::Show("Backup restore complete.`n`nSQLite backup ho to direct open hoga. Purana JSON backup ho to service usko automatically SQLite me migrate karegi.`n`nApp dobara open karein.",$Product)|Out-Null
