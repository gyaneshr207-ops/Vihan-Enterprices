using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

public sealed class VihanSqliteDb : IDisposable
{
    const int SQLITE_OK = 0;
    const int SQLITE_ROW = 100;
    const int SQLITE_DONE = 101;
    IntPtr _db = IntPtr.Zero;
    readonly object _gate = new object();

    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_open16([MarshalAs(UnmanagedType.LPWStr)] string filename, out IntPtr db);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_close_v2(IntPtr db);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_busy_timeout(IntPtr db, int ms);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_exec(IntPtr db, byte[] sql, IntPtr callback, IntPtr arg, out IntPtr errMsg);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_prepare_v2(IntPtr db, byte[] sql, int nByte, out IntPtr stmt, IntPtr tail);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_step(IntPtr stmt);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_finalize(IntPtr stmt);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_column_count(IntPtr stmt);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr sqlite3_column_name(IntPtr stmt, int iCol);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr sqlite3_column_text(IntPtr stmt, int iCol);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern int sqlite3_column_bytes(IntPtr stmt, int iCol);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern long sqlite3_column_int64(IntPtr stmt, int iCol);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr sqlite3_errmsg(IntPtr db);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    static extern void sqlite3_free(IntPtr p);

    static byte[] Utf8Z(string s)
    {
        if (s == null) s = "";
        byte[] raw = Encoding.UTF8.GetBytes(s);
        byte[] z = new byte[raw.Length + 1];
        Buffer.BlockCopy(raw, 0, z, 0, raw.Length);
        return z;
    }
    static string PtrUtf8(IntPtr p, int len = -1)
    {
        if (p == IntPtr.Zero) return null;
        if (len < 0)
        {
            len = 0;
            while (Marshal.ReadByte(p, len) != 0) len++;
        }
        byte[] b = new byte[len];
        if (len > 0) Marshal.Copy(p, b, 0, len);
        return Encoding.UTF8.GetString(b);
    }
    string Error()
    {
        return _db == IntPtr.Zero ? "SQLite error" : (PtrUtf8(sqlite3_errmsg(_db)) ?? "SQLite error");
    }

    public VihanSqliteDb(string path)
    {
        int rc = sqlite3_open16(path, out _db);
        if (rc != SQLITE_OK || _db == IntPtr.Zero) throw new Exception("SQLite open failed: " + Error());
        sqlite3_busy_timeout(_db, 8000);
        Exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA temp_store=MEMORY; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=8000; PRAGMA cache_size=-16384; PRAGMA wal_autocheckpoint=1000; PRAGMA mmap_size=134217728;");
    }

    public void Exec(string sql)
    {
        lock (_gate)
        {
            IntPtr err = IntPtr.Zero;
            int rc = sqlite3_exec(_db, Utf8Z(sql), IntPtr.Zero, IntPtr.Zero, out err);
            if (rc != SQLITE_OK)
            {
                string msg = err != IntPtr.Zero ? PtrUtf8(err) : Error();
                if (err != IntPtr.Zero) sqlite3_free(err);
                throw new Exception("SQLite exec failed: " + msg);
            }
        }
    }

    public long ScalarLong(string sql, long defaultValue)
    {
        lock (_gate)
        {
            IntPtr st = IntPtr.Zero;
            int rc = sqlite3_prepare_v2(_db, Utf8Z(sql), -1, out st, IntPtr.Zero);
            if (rc != SQLITE_OK) throw new Exception("SQLite prepare failed: " + Error());
            try
            {
                rc = sqlite3_step(st);
                if (rc == SQLITE_ROW) return sqlite3_column_int64(st, 0);
                if (rc == SQLITE_DONE) return defaultValue;
                throw new Exception("SQLite step failed: " + Error());
            }
            finally { if (st != IntPtr.Zero) sqlite3_finalize(st); }
        }
    }

    public string ScalarText(string sql, string defaultValue)
    {
        lock (_gate)
        {
            IntPtr st = IntPtr.Zero;
            int rc = sqlite3_prepare_v2(_db, Utf8Z(sql), -1, out st, IntPtr.Zero);
            if (rc != SQLITE_OK) throw new Exception("SQLite prepare failed: " + Error());
            try
            {
                rc = sqlite3_step(st);
                if (rc == SQLITE_ROW)
                {
                    IntPtr p = sqlite3_column_text(st, 0);
                    if (p == IntPtr.Zero) return defaultValue;
                    return PtrUtf8(p, sqlite3_column_bytes(st, 0));
                }
                if (rc == SQLITE_DONE) return defaultValue;
                throw new Exception("SQLite step failed: " + Error());
            }
            finally { if (st != IntPtr.Zero) sqlite3_finalize(st); }
        }
    }

    public List<Dictionary<string,string>> Query(string sql)
    {
        lock (_gate)
        {
            var rows = new List<Dictionary<string,string>>();
            IntPtr st = IntPtr.Zero;
            int rc = sqlite3_prepare_v2(_db, Utf8Z(sql), -1, out st, IntPtr.Zero);
            if (rc != SQLITE_OK) throw new Exception("SQLite prepare failed: " + Error());
            try
            {
                int cols = sqlite3_column_count(st);
                string[] names = new string[cols];
                for (int i=0;i<cols;i++) names[i] = PtrUtf8(sqlite3_column_name(st, i)) ?? ("c"+i);
                while (true)
                {
                    rc = sqlite3_step(st);
                    if (rc == SQLITE_DONE) break;
                    if (rc != SQLITE_ROW) throw new Exception("SQLite step failed: " + Error());
                    var row = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
                    for (int i=0;i<cols;i++)
                    {
                        IntPtr p = sqlite3_column_text(st, i);
                        row[names[i]] = p == IntPtr.Zero ? null : PtrUtf8(p, sqlite3_column_bytes(st, i));
                    }
                    rows.Add(row);
                }
                return rows;
            }
            finally { if (st != IntPtr.Zero) sqlite3_finalize(st); }
        }
    }

    public static string Quote(string s)
    {
        if (s == null) return "NULL";
        return "'" + s.Replace("\0", "").Replace("'", "''") + "'";
    }

    public void Dispose()
    {
        lock (_gate)
        {
            if (_db != IntPtr.Zero) { sqlite3_close_v2(_db); _db = IntPtr.Zero; }
        }
    }
}
