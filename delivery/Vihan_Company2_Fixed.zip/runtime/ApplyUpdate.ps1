$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Windows.Forms
$Product='Vihan Enterprices';$Root=Split-Path $PSScriptRoot -Parent
$d=New-Object System.Windows.Forms.OpenFileDialog;$d.Title='Vihan Enterprices Update Package Select Karein';$d.Filter='Vihan Update (*.veupdate;*.zip)|*.veupdate;*.zip';if($d.ShowDialog() -ne 'OK'){exit}
$stage=Join-Path $env:TEMP ('VihanUpdate_'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $stage|Out-Null
$zipForExpand=Join-Path $env:TEMP ('VihanManualUpdate_'+[guid]::NewGuid().ToString('N')+'.zip')
try{
  Copy-Item -LiteralPath $d.FileName -Destination $zipForExpand -Force
  Expand-Archive -Path $zipForExpand -DestinationPath $stage -Force
  $mf=Join-Path $stage 'manifest.json';if(!(Test-Path $mf)){throw 'Update manifest missing'}
  $m=Get-Content $mf -Raw|ConvertFrom-Json;if($m.product -ne $Product){throw 'Ye Vihan Enterprices update package nahi hai'}
  $app=Join-Path $stage 'app';if(!(Test-Path $app)){throw 'Update app files missing'}
  Copy-Item (Join-Path $app '*') (Join-Path $Root 'app') -Recurse -Force
  if(Test-Path (Join-Path $stage 'runtime')){Copy-Item (Join-Path $stage 'runtime\*') (Join-Path $Root 'runtime') -Recurse -Force}
  $hostSrc=Join-Path $Root 'runtime\electron-app'
  $hostDest=Join-Path $Root 'desktop-runtime\resources\app'
  if((Test-Path $hostSrc) -and (Test-Path (Join-Path $Root 'desktop-runtime\Vihan Enterprices.exe'))){
    if(Test-Path $hostDest){Remove-Item $hostDest -Recurse -Force -ErrorAction SilentlyContinue}
    New-Item -ItemType Directory -Force -Path $hostDest|Out-Null
    Copy-Item (Join-Path $hostSrc '*') $hostDest -Recurse -Force
  }
  [System.Windows.Forms.MessageBox]::Show(('Update complete: '+$m.appVersion+"`nPurana data/service file safe hai.`nDesktop app runtime aur Main/Client setting preserve hai."),$Product)|Out-Null
}finally{Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue;Remove-Item $zipForExpand -Force -ErrorAction SilentlyContinue}
