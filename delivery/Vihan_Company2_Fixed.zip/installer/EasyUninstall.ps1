param()
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
$p='Vihan Enterprices'
$a=[System.Windows.Forms.MessageBox]::Show('Remove Vihan Enterprices software from this PC? Your accounts and database are kept unless you separately choose to delete them.','Vihan Enterprices','YesNo','Warning')
if($a -ne 'Yes'){exit 0}
$d=[System.Windows.Forms.MessageBox]::Show('Delete ALL Vihan database, backups and attachments too? Choose NO to keep all data.','KEEP DATA OR DELETE DATA?','YesNo','Warning')
$purge=$d -eq 'Yes'
if($purge){$c=[System.Windows.Forms.MessageBox]::Show('PERMANENTLY DELETE database and backups? This cannot be undone.','FINAL CONFIRMATION','YesNo','Error');if($c -ne 'Yes'){exit 0}}
foreach($task in @('Vihan Enterprices Main Service','Vihan Enterprices File Service')) { & schtasks /End /TN $task 2>$null | Out-Null; & schtasks /Delete /TN $task /F 2>$null | Out-Null }
Get-Process -Name 'Vihan Enterprices' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
$dest=Join-Path $env:LOCALAPPDATA $p
if(Test-Path $dest){Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction Stop}
foreach($link in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Vihan Enterprices.lnk'),(Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Vihan Enterprices.lnk'),(Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\Vihan Enterprices'))){if(Test-Path $link){Remove-Item -LiteralPath $link -Recurse -Force}}
if($purge){foreach($path in @('D:\Vihan Enterprices\Data','D:\Vihan Enterprices\Backups','C:\Vihan Enterprices\Data','C:\Vihan Enterprices\Backups',(Join-Path $env:APPDATA $p),(Join-Path $env:ProgramData $p))){if(Test-Path $path){Remove-Item -LiteralPath $path -Recurse -Force}}}
[System.Windows.Forms.MessageBox]::Show('Uninstall completed. '+$(if($purge){'Data deletion requested.'}else{'Database and backups are kept safe.'}),$p,'OK','Information')|Out-Null
