# Browser regression tests कैसे दोहराएँ

Test tools: Node.js 24.19.0, Playwright 1.62.1, system Chromium (Linux).

- Existing tests: `node --test --test-force-exit tests/admin_and_launcher.test.js tests/bootstrap_offline.test.js tests/main_integration.test.js tests/offline.test.js tests/sync_js_offline.test.js`
- Browser tests: `node --test --test-concurrency=1 tests/company2_navigation.browser.test.js tests/company2_functions.browser.test.js`
- पूरा run: `node --test --test-concurrency=1 --test-reporter=tap --test-force-exit tests/*.test.js`

Browser tests को `playwright` Node module चाहिए। इसे test tooling directory में install करें; application dependencies/runtime में बदलाव जरूरी नहीं। Chromium executable default `/usr/bin/chromium` है; दूसरी location के लिए `CHROMIUM_PATH` environment variable दें। Windows PowerShell में test file paths explicitly दें यदि shell `*.test.js` glob expand न करे।

`tests/helpers/company2-browser-harness.js` test-only HTTP service है: isolated memory में storage revisions और file bytes रखता है। Browser actual supplied HTML/JS, real clicks, localStorage synchronization, raw binary uploads और downloads चलाता है। Main/Client test दो independent browser contexts इस्तेमाल करता है। यह Windows MainService, authentication/LAN configuration, actual SQLite, printer driver या Electron deployment का विकल्प/प्रमाण नहीं है। कोई production database या user data test में इस्तेमाल नहीं हुआ।

Print tests print document/frame और `window.print()` invocation जाँचते हैं; OS printer dialog और कागज पर output नहीं। Photo test optional CDN model deliberately block करके application का existing original-image fallback जाँचता है; AI inference pass claim नहीं है। Missing-module/error tests जानबूझकर error inject करके recovery जाँचते हैं; इन expected diagnostic errors को normal navigation errors नहीं गिना गया।
