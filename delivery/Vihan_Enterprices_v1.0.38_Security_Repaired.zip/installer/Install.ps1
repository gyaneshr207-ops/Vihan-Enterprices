param(
  [ValidateSet('Auto','Main','Client')]
  [string]$Mode='Auto'
)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
$Product='Vihan Enterprices'
$Version='1.0.38'
$ElectronVersion='38.2.0'
$ElectronSha256='4382B317DBBBC0BBF8A301304749324B88207218AAC240B670F1C1247C2A02B0'
$ElectronUrls=@(
  'https://github.com/electron/electron/releases/download/v38.2.0/electron-v38.2.0-win32-x64.zip',
  'https://npmmirror.com/mirrors/electron/v38.2.0/electron-v38.2.0-win32-x64.zip'
)
$Source=Split-Path $PSScriptRoot -Parent
$LegacyDest=Join-Path $env:LOCALAPPDATA $Product
$Dest='D:\Vihan Enterprices\Software'
# Existing installations are retained in-place. A path migration needs a
# separately approved backup/migration plan, never an installer side effect.
if(Test-Path (Join-Path $LegacyDest 'app\index.html')){$Dest=$LegacyDest}
$InstallBinding=Join-Path (Join-Path $env:APPDATA $Product) 'installation.json'
if(Test-Path $InstallBinding){
  $binding=Get-Content $InstallBinding -Raw|ConvertFrom-Json
  if($binding.root -and [string]$binding.root -notin @($LegacyDest,'D:\Vihan Enterprices\Software')){throw 'Unrecognized installation binding. Existing files were not moved or overwritten.'}
  if($binding.root -and (Test-Path (Join-Path ([string]$binding.root) 'app\index.html'))){$Dest=[string]$binding.root}
}
if($Dest -like 'D:*' -and !(Test-Path 'D:\')){throw 'D: drive is unavailable. Installation stopped; no silent software/data fallback.'}

$LogDir=$Dest
$Log=Join-Path $LogDir 'install.log'
$DesktopRuntime=Join-Path $Dest 'desktop-runtime'
$DesktopExe=Join-Path $DesktopRuntime 'Vihan Enterprices.exe'
$ElectronMarker=Join-Path $DesktopRuntime '.electron-version'

function Write-Log([string]$m){
  try{New-Item -ItemType Directory -Force -Path $LogDir|Out-Null;Add-Content -Path $Log -Encoding UTF8 -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+'  '+$m)}catch{}
}
function Show-Error([string]$m){
  Write-Log ('ERROR: '+$m)
  [System.Windows.Forms.MessageBox]::Show("Setup complete nahi hua.`n`n$m`n`nInstall log:`n$Log",$Product,'OK','Error')|Out-Null
}
function Get-FileSha([string]$p){return (Get-FileHash -Algorithm SHA256 -LiteralPath $p).Hash.ToUpperInvariant()}

function Stop-InstalledDesktopApp(){
  try{
    Get-Process -Name 'Vihan Enterprices' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 900
  }catch{}
}
function Ensure-ElectronRuntime(){
  $need=$true
  if((Test-Path $DesktopExe) -and (Test-Path $ElectronMarker)){
    try{$mk=(Get-Content $ElectronMarker -Raw).Trim();if($mk -eq $ElectronVersion){$need=$false}}catch{}
  }
  if(!$need){
    Write-Log "Bundled desktop runtime already ready: Electron $ElectronVersion"
  }else{
    if($env:PROCESSOR_ARCHITECTURE -notin @('AMD64','x86')){throw "Is build ke liye Windows x64 PC chahiye. Architecture: $env:PROCESSOR_ARCHITECTURE"}
    $zip=Join-Path $env:TEMP ("VihanElectron-$ElectronVersion-win32-x64.zip")
    $ok=$false
    if(Test-Path $zip){
      try{if((Get-FileSha $zip) -eq $ElectronSha256){$ok=$true;Write-Log 'Existing verified Electron ZIP cache found.'}else{Remove-Item $zip -Force -ErrorAction SilentlyContinue}}catch{Remove-Item $zip -Force -ErrorAction SilentlyContinue}
    }
    if(!$ok){
      Write-Host "Vihan Enterprices ka apna Desktop Runtime download ho raha hai (~126 MB)." -ForegroundColor Cyan
      Write-Host "Ye sirf pehli baar / runtime update par hoga. Microsoft Edge install hona zaroori nahi hai." -ForegroundColor DarkCyan
      foreach($u in $ElectronUrls){
        try{
          Write-Log "Electron download: $u"
          Remove-Item $zip -Force -ErrorAction SilentlyContinue
          $downloaded=$false
          try{
            Import-Module BitsTransfer -ErrorAction Stop
            Start-BitsTransfer -Source $u -Destination $zip -DisplayName 'Vihan Enterprices Desktop Runtime' -Description "Electron $ElectronVersion" -ErrorAction Stop
            $downloaded=$true
          }catch{
            Write-Log ('BITS warning: '+$_.Exception.Message)
          }
          if(!$downloaded){
            $oldProgress=$ProgressPreference;$ProgressPreference='SilentlyContinue'
            try{Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $zip -TimeoutSec 900; $downloaded=$true}finally{$ProgressPreference=$oldProgress}
          }
          if($downloaded -and (Test-Path $zip)){
            $hash=Get-FileSha $zip
            if($hash -ne $ElectronSha256){throw "Downloaded Desktop Runtime checksum match nahi hua. Expected $ElectronSha256, got $hash"}
            $ok=$true;break
          }
        }catch{Write-Log ('Electron source failed: '+$_.Exception.Message)}
      }
      if(!$ok){throw "Vihan Enterprices Desktop Runtime download nahi ho paya. Internet connection check karke setup dobara chalayein. Microsoft Edge ki zarurat nahi hai; setup apna runtime khud download karta hai."}
    }
    $stage=Join-Path $env:TEMP ('VihanElectronStage_'+[guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $stage|Out-Null
    try{
      Write-Host 'Desktop Runtime install kiya ja raha hai...' -ForegroundColor Cyan
      Expand-Archive -LiteralPath $zip -DestinationPath $stage -Force
      if(!(Test-Path (Join-Path $stage 'electron.exe'))){throw 'Electron runtime ZIP invalid: electron.exe missing'}
      if(Test-Path $DesktopRuntime){Remove-Item $DesktopRuntime -Recurse -Force -ErrorAction SilentlyContinue}
      New-Item -ItemType Directory -Force -Path $DesktopRuntime|Out-Null
      Copy-Item (Join-Path $stage '*') $DesktopRuntime -Recurse -Force
      Rename-Item (Join-Path $DesktopRuntime 'electron.exe') 'Vihan Enterprices.exe' -Force
      Set-Content -Path $ElectronMarker -Value $ElectronVersion -Encoding ASCII
      Write-Log "Bundled Electron $ElectronVersion installed."
    }finally{Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue}
  }

  $hostSrc=Join-Path $Dest 'runtime\electron-app'
  $hostDest=Join-Path $DesktopRuntime 'resources\app'
  if(!(Test-Path $hostSrc)){throw "Desktop host files missing: $hostSrc"}
  if(Test-Path $hostDest){Remove-Item $hostDest -Recurse -Force -ErrorAction SilentlyContinue}
  New-Item -ItemType Directory -Force -Path $hostDest|Out-Null
  Copy-Item (Join-Path $hostSrc '*') $hostDest -Recurse -Force
  if(!(Test-Path (Join-Path $hostDest 'main.js'))){throw 'Desktop app host main.js install nahi hua'}
}

try{
  Write-Log "===== Setup $Version start. Mode=$Mode ====="
  Stop-InstalledDesktopApp
  New-Item -ItemType Directory -Force -Path $Dest,(Join-Path $Dest 'app'),(Join-Path $Dest 'runtime')|Out-Null
  Write-Log "Copy app files from $Source"
  Copy-Item (Join-Path $Source 'app\*') (Join-Path $Dest 'app') -Recurse -Force
  Copy-Item (Join-Path $Source 'runtime\*') (Join-Path $Dest 'runtime') -Recurse -Force

  Ensure-ElectronRuntime

  $ws=New-Object -ComObject WScript.Shell
  $ps="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
  if(!(Test-Path $ps)){throw "Windows PowerShell nahi mila: $ps"}

  $desktop=[Environment]::GetFolderPath('Desktop')
  $lnk=Join-Path $desktop 'Vihan Enterprices.lnk'
  $s=$ws.CreateShortcut($lnk);$s.TargetPath=$DesktopExe;$s.Arguments='';$s.WorkingDirectory=$DesktopRuntime;$s.IconLocation="$env:SystemRoot\System32\imageres.dll,15";$s.Save()

  $menu=Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\Vihan Enterprices'
  New-Item -ItemType Directory -Force -Path $menu|Out-Null
  $mainLnk=Join-Path $menu 'Vihan Enterprices.lnk';$q=$ws.CreateShortcut($mainLnk);$q.TargetPath=$DesktopExe;$q.WorkingDirectory=$DesktopRuntime;$q.IconLocation="$env:SystemRoot\System32\imageres.dll,15";$q.Save()
  foreach($x in @(
    @('Vihan Enterprices Setup','FirstSetup.ps1'),
    @('Vihan Enterprices Repair Main Service','RepairMainService.ps1'),
    @('Vihan Enterprices Client Diagnostic','ClientDiagnostic.ps1'),
    @('Vihan Enterprices Apply Update','ApplyUpdate.ps1'),
    @('Vihan Enterprices Restore Backup','RestoreBackup.ps1'),
    @('Vihan Enterprices Reset Connection','ResetConnection.ps1')
  )){
    $p=Join-Path $menu ($x[0]+'.lnk');$z=$ws.CreateShortcut($p);$z.TargetPath=$ps;$z.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+(Join-Path $Dest ('runtime\'+$x[1]))+'"';$z.WorkingDirectory=$Dest;$z.IconLocation="$env:SystemRoot\System32\imageres.dll,15";$z.Save()
  }
  Write-Log 'Files + self desktop runtime + shortcuts installed.'

  $setup=Join-Path $Dest 'runtime\FirstSetup.ps1'
  if($Mode -eq 'Main'){
    & $ps -NoProfile -ExecutionPolicy Bypass -File $setup -MakeMain
    if($LASTEXITCODE -ne 0){throw "Main PC setup error code $LASTEXITCODE"}
  }elseif($Mode -eq 'Client'){
    & $ps -NoProfile -ExecutionPolicy Bypass -File $setup -ClientOnly
    if($LASTEXITCODE -ne 0){throw "Client PC setup error code $LASTEXITCODE"}
  }else{
    $existingConn=Join-Path (Join-Path $env:APPDATA $Product) 'connection.json'
    if(Test-Path $existingConn){
      Write-Log 'Existing Main/Client connection found. First setup skipped; role preserved.'
    }else{
      & $ps -NoProfile -ExecutionPolicy Bypass -File $setup
      if($LASTEXITCODE -ne 0){throw "First setup error code $LASTEXITCODE"}
    }
  }

  $serverConfig=Join-Path (Join-Path $env:ProgramData $Product) 'server.json'
  if(Test-Path $serverConfig){
    if(!(Test-Path 'D:\')){throw 'Ye Main PC hai aur D: drive available nahi hai. v1.0.38 central data D:\Vihan Enterprices\Data me rakhega. D: drive connect/enable karke setup dobara chalayein.'}
    try{
      $repair=Join-Path $Dest 'runtime\RepairMainService.ps1'
      if(Test-Path $repair){
        Write-Log 'Main PC detected: ensuring auto-start + repairing central service.'
        $rp=Start-Process powershell.exe -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$repair+'"'),'-NoPrompt') -PassThru -Wait
        if($rp.ExitCode -ne 0){throw ('Main service repair returned code '+$rp.ExitCode)}
      }else{
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $Dest 'runtime\MainService.ps1')+'"'))
      }
    }catch{throw ('Main service repair failed: '+$_.Exception.Message)}
    try{
      $updateDir='D:\\Vihan Enterprices\\Updates';$latest=Join-Path $updateDir 'latest.json'
      if(Test-Path $latest){
        try{
          $st=Get-Content $latest -Raw|ConvertFrom-Json
          $published=[version]([string]$st.version);$current=[version]'1.0.38'
          if($published -le $current){
            $arch=Join-Path $updateDir ('latest_archived_before_v1.0.38_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.json')
            Move-Item -LiteralPath $latest -Destination $arch -Force
            Write-Log ('Archived stale central update '+[string]$st.version+' -> '+$arch)
          }
        }catch{Write-Log ('Stale central update archive warning: '+$_.Exception.Message)}
      }
    }catch{Write-Log ('Central update cleanup warning: '+$_.Exception.Message)}
  }
  [pscustomobject]@{version=$Version;updatedAt=(Get-Date).ToString('o')}|ConvertTo-Json|Set-Content -Encoding UTF8 (Join-Path $Dest 'installed_version.json')
  New-Item -ItemType Directory -Force -Path (Split-Path $InstallBinding -Parent)|Out-Null
  [pscustomobject]@{root=$Dest;updatedAt=(Get-Date).ToString('o')}|ConvertTo-Json|Set-Content -Encoding UTF8 $InstallBinding
  Write-Log 'Setup completed successfully.'
  try{if(Test-Path $DesktopExe){Start-Process -FilePath $DesktopExe -WorkingDirectory $DesktopRuntime|Out-Null;Write-Log 'Desktop app relaunched after recovery/update.'}}catch{Write-Log ('Desktop relaunch warning: '+$_.Exception.Message)}
  exit 0
}catch{
  Show-Error $_.Exception.Message
  exit 1
}
