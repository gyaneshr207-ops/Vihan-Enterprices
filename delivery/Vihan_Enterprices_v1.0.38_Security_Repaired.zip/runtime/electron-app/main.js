const { app, BrowserWindow, shell, session, dialog, safeStorage } = require('electron');
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { createOfflineManager } = require('./offline');
const { downloadWithToken } = require('./download');

const PRODUCT = 'Vihan Enterprices';
const APP_VERSION = '1.0.38';
const DEFAULT_PORT = 17867;
let mainWindow = null;
let retryTimer = null;
let localStartAttemptedAt = 0;
let allowWindowClose = false;
let updateCheckTimer = null;
let autoUpdating = false;
let offlineActive = false;      // window is currently showing the local read-only copy
let lastLanScanAt = 0;
let currentBase = null;         // Main PC base URL while it is reachable, otherwise null
let offlineAdminWindow = null;

app.setName(PRODUCT);
app.setAppUserModelId('VihanEnterprices.DesktopApp');

// Camera support on LAN HTTP:
// Chromium exposes getUserMedia only in secure contexts. Vihan Enterprices is served
// by the trusted Main PC over private LAN HTTP, so register ONLY the configured
// Main Service origins as secure before Chromium starts. Electron permission handlers
// below still restrict camera access to those same service origins.
const launchMediaOrigins = new Set();
function addLaunchMediaOrigin(raw) {
  if (!raw) return;
  try {
    const u = new URL(String(raw));
    if (u.protocol === 'http:' || u.protocol === 'https:') launchMediaOrigins.add(u.origin);
  } catch {}
}
function loadEarlyJson(p) {
  if (!p || !fs.existsSync(p)) return null;
  try { return JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '')); } catch { return null; }
}
(function prepareCameraSecureOrigins() {
  const appData = process.env.APPDATA || '';
  const programData = process.env.ProgramData || process.env.PROGRAMDATA || 'C:\\ProgramData';
  const conn = loadEarlyJson(path.join(appData, PRODUCT, 'connection.json'));
  const srv = loadEarlyJson(path.join(programData, PRODUCT, 'server.json'));
  const port = Number((conn && conn.port) || (srv && srv.port) || DEFAULT_PORT) || DEFAULT_PORT;

  addLaunchMediaOrigin(`http://127.0.0.1:${port}`);
  addLaunchMediaOrigin(`http://localhost:${port}`);
  if (conn) {
    addLaunchMediaOrigin(conn.serverUrl);
    addLaunchMediaOrigin(conn.serverIpUrl);
    if (conn.serverIp) addLaunchMediaOrigin(`http://${conn.serverIp}:${port}`);
    if (conn.serverName) addLaunchMediaOrigin(`http://${conn.serverName}:${port}`);
  }
  if (srv) {
    if (srv.serverIp) addLaunchMediaOrigin(`http://${srv.serverIp}:${port}`);
    if (srv.serverName) addLaunchMediaOrigin(`http://${srv.serverName}:${port}`);
  }

  if (launchMediaOrigins.size) {
    app.commandLine.appendSwitch('unsafely-treat-insecure-origin-as-secure', [...launchMediaOrigins].join(','));
  }
})();

function trustedMediaOriginsNow() {
  const out = new Set(launchMediaOrigins);
  const c = readConnection();
  const s = readJson(localServerConfigPath());
  const port = Number((c && c.port) || (s && s.port) || DEFAULT_PORT) || DEFAULT_PORT;
  const add = (raw) => {
    if (!raw) return;
    try { const u = new URL(String(raw)); if (/^https?:$/.test(u.protocol)) out.add(u.origin); } catch {}
  };
  add(`http://127.0.0.1:${port}`);
  add(`http://localhost:${port}`);
  if (c) {
    add(c.serverUrl); add(c.serverIpUrl);
    if (c.serverIp) add(`http://${c.serverIp}:${port}`);
    if (c.serverName) add(`http://${c.serverName}:${port}`);
  }
  if (s) {
    if (s.serverIp) add(`http://${s.serverIp}:${port}`);
    if (s.serverName) add(`http://${s.serverName}:${port}`);
  }
  return out;
}
function isTrustedMediaUrl(raw) {
  try { const u = new URL(String(raw || '')); return /^https?:$/.test(u.protocol) && trustedMediaOriginsNow().has(u.origin); }
  catch { return false; }
}
function cameraOriginNeedsRestart(base) {
  try {
    const u = new URL(String(base || ''));
    if (u.protocol !== 'http:') return false;
    if (u.hostname === '127.0.0.1' || u.hostname === 'localhost' || u.hostname === '::1') return false;
    return !launchMediaOrigins.has(u.origin);
  } catch { return false; }
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });
}

function connectionPath() {
  return path.join(process.env.APPDATA || app.getPath('appData'), PRODUCT, 'connection.json');
}

function localServerConfigPath() {
  const pd = process.env.ProgramData || process.env.PROGRAMDATA || 'C:\\ProgramData';
  return path.join(pd, PRODUCT, 'server.json');
}

function readJson(p) {
  if (!p || !fs.existsSync(p)) return null;
  try { return JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '')); }
  catch { return null; }
}

function readConnection() {
  let c = readJson(connectionPath());
  if (c) return c;

  // Main PC safety: if connection.json was lost but server.json still exists,
  // rebuild an in-memory local connection so the app can recover itself.
  const s = readJson(localServerConfigPath());
  if (s && s.token) {
    const port = Number(s.port) || DEFAULT_PORT;
    c = {
      product: PRODUCT,
      appVersion: APP_VERSION,
      serverName: s.serverName || os.hostname(),
      serverIp: s.serverIp || '127.0.0.1',
      port,
      token: String(s.token),
      serverUrl: `http://${s.serverName || os.hostname()}:${port}`,
      serverIpUrl: `http://127.0.0.1:${port}`
    };
    try {
      fs.mkdirSync(path.dirname(connectionPath()), { recursive: true });
      fs.writeFileSync(connectionPath(), JSON.stringify(c, null, 2), 'utf8');
    } catch {}
    return c;
  }
  return null;
}

function getHealth(base, timeoutMs = 1200) {
  return new Promise((resolve) => {
    if (!base) return resolve(null);
    let u;
    try { u = new URL(base.replace(/\/$/, '') + '/health'); } catch { return resolve(null); }
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.get(u, { timeout: timeoutMs }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', d => { if (body.length < 4096) body += d; });
      res.on('end', () => {
        if (res.statusCode !== 200) return resolve(null);
        try { resolve(JSON.parse(body || '{}')); } catch { resolve(null); }
      });
    });
    req.on('timeout', () => { req.destroy(); resolve(null); });
    req.on('error', () => resolve(null));
  });
}

async function checkUrl(base, timeoutMs = 1200) {
  const h = await getHealth(base, timeoutMs);
  return !!(h && h.ok !== false && h.product === PRODUCT && !h.offline && h.service !== 'files');
}

function isLocalMain(c) {
  const s = readJson(localServerConfigPath());
  if (!s || !s.token) return false;
  if (c && c.token && String(c.token) !== String(s.token)) return false;
  return true;
}

function startLocalMainService() {
  if (!isLocalMain(readConnection())) return false;
  const now = Date.now();
  if (now - localStartAttemptedAt < 6000) return true;
  localStartAttemptedAt = now;

  try {
    const root = path.dirname(path.dirname(path.dirname(process.resourcesPath)));
    // In installed runtime, resources/app is the Electron host; application runtime is alongside desktop-runtime.
    const installRoot = path.dirname(path.dirname(process.execPath));
    const candidates = [
      path.join(installRoot, 'runtime', 'MainService.ps1'),
      path.join(path.dirname(process.execPath), '..', 'runtime', 'MainService.ps1'),
      path.join(root, 'runtime', 'MainService.ps1')
    ];
    const script = candidates.map(p => path.resolve(p)).find(p => fs.existsSync(p));
    if (!script) return false;
    const ps = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const child = spawn(ps, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', script], {
      detached: true,
      windowsHide: true,
      stdio: 'ignore'
    });
    child.unref();
    return true;
  } catch {
    return false;
  }
}

function localIPv4Prefixes() {
  const out = new Set();
  const nets = os.networkInterfaces();
  for (const list of Object.values(nets)) {
    for (const n of list || []) {
      if (!n || n.family !== 'IPv4' || n.internal) continue;
      const ip = String(n.address || '');
      if (/^(127\.|169\.254\.)/.test(ip)) continue;
      const parts = ip.split('.');
      if (parts.length === 4) out.add(parts.slice(0, 3).join('.'));
    }
  }
  return [...out].slice(0, 3);
}

async function scanLanForServer(c) {
  if (!c || !c.serverName) return null;
  const ports=[...new Set([Number(c.port)||DEFAULT_PORT,17867,18080,28080,8000])];
  const wanted = String(c.serverName).toLowerCase();
  const prefixes = localIPv4Prefixes();
  for (const prefix of prefixes) {
    for (let start = 1; start <= 254; start += 32) {
      const jobs = [];
      for (let i = start; i < Math.min(start + 32, 255); i++) {
        for(const candidatePort of ports){
          const base = `http://${prefix}.${i}:${candidatePort}`;
          jobs.push(getHealth(base, 350).then(h => ({ base, h })));
        }
      }
      const rs = await Promise.all(jobs);
      const hit = rs.find(x => x.h && String(x.h.product || '') === PRODUCT && String(x.h.serverName || '').toLowerCase() === wanted);
      if (hit) {
        try {
          c.serverIpUrl = hit.base;
          c.serverIp = new URL(hit.base).hostname;
          c.port = Number(new URL(hit.base).port);
          c.serverUrl = `http://${c.serverName}:${c.port}`;
          c.filePort = c.port+1;
          fs.writeFileSync(connectionPath(), JSON.stringify(c, null, 2), 'utf8');
        } catch {}
        return hit.base;
      }
    }
  }
  return null;
}

async function findBase(c, opts = {}) {
  if (!c) return null;
  const urls = [];

  // On Main PC always try localhost first. This makes the app independent of DHCP/IP changes.
  if (isLocalMain(c)) {
    const localCfg = readJson(localServerConfigPath()) || {};
    const port = Number(localCfg.port || c.port) || DEFAULT_PORT;
    urls.push(`http://127.0.0.1:${port}`);
  }
  if (c.serverIpUrl) urls.push(String(c.serverIpUrl));
  if (c.serverUrl && c.serverUrl !== c.serverIpUrl) urls.push(String(c.serverUrl));

  const seen = new Set();
  for (const u of urls) {
    const base = u.replace(/\/$/, '');
    if (seen.has(base)) continue;
    seen.add(base);
    if (await checkUrl(base, 1200)) return base;
  }

  // If this is the Main PC and the background service stopped, start it automatically.
  if (isLocalMain(c) && startLocalMainService()) {
    const localCfg = readJson(localServerConfigPath()) || {};
    const port = Number(localCfg.port || c.port) || DEFAULT_PORT;
    const localBase = `http://127.0.0.1:${port}`;
    for (let i = 0; i < 12; i++) {
      await new Promise(r => setTimeout(r, 500));
      if (await checkUrl(localBase, 900)) return localBase;
    }
  }

  // Client safety: if the Main PC's DHCP IP changed, find it automatically on the same LAN.
  if (opts.noScan) return null;
  const discovered = await scanLanForServer(c);
  if (discovered) return discovered;
  return null;
}

// ---- Offline read-only copy (v1.0.35) -------------------------------------------------
// The copy lives outside the installed application. It is only a safety copy of the Main PC
// data for PCs that the Main PC has allowed; it NEVER queues edits and NEVER writes to Main.
function offlineDataDirectory() {
  for (const dir of ['D:\\Vihan Enterprices\\OfflineCopy', 'C:\\Vihan Enterprices\\OfflineCopy']) {
    try { if (!fs.existsSync(path.parse(dir).root)) continue; const scoped=path.join(dir,'Users',crypto.createHash('sha256').update(os.userInfo().username+'|'+os.homedir()).digest('hex').slice(0,24));fs.mkdirSync(scoped, { recursive: true }); fs.accessSync(scoped, fs.constants.W_OK); return scoped; } catch {}
  }
  const d = path.join(app.getPath('userData'), 'OfflineCopy');
  try { fs.mkdirSync(d, { recursive: true }); } catch {}
  return d;
}
function legacySnapshotFiles() {
  // v1.0.33/34 saved a data copy on EVERY client every 2 minutes. It is replaced by the allow-listed copy.
  return ['D:\\Vihan Enterprices\\Data\\VihanClientReadOnlySnapshot.json', 'C:\\Vihan Enterprices\\Data\\VihanClientReadOnlySnapshot.json', path.join(app.getPath('userData'), 'OfflineData', 'VihanClientReadOnlySnapshot.json')];
}
function clearOfflineBrowserStorage() {
  // The offline pages keep a working copy in the browser profile of the local offline origin.
  try {
    for (let port = 17890; port <= 17899; port++) session.defaultSession.clearStorageData({ origin: 'http://127.0.0.1:' + port });
  } catch {}
}
const offline = createOfflineManager({
  hostname: os.hostname(),
  dataDir: offlineDataDirectory,
  appDir: () => path.join(path.dirname(path.dirname(process.execPath)), 'app'),
  log: (m) => { try { console.log('[offline]', m); } catch {} },
  onWipe: clearOfflineBrowserStorage,onScopeChange:clearOfflineBrowserStorage,
  encrypt:(text)=>{if(!safeStorage||!safeStorage.isEncryptionAvailable())throw new Error('Windows secure storage unavailable');return safeStorage.encryptString(text)},
  decrypt:(bytes)=>{if(!safeStorage||!safeStorage.isEncryptionAvailable())throw new Error('Windows secure storage unavailable');return safeStorage.decryptString(bytes)},
  userSession:async(base)=>{if(!session.defaultSession.cookies?.get)return null;const cookies=await session.defaultSession.cookies.get({url:base,name:'VE_SESSION'});return cookies[0]?.value||null}
});
// Native cookie events bind an offline cache to the most recently authenticated user.

function offlineSyncContext() {
  // Only a Client PC with a reachable Main PC may sync. The Main PC itself never keeps an offline copy.
  const c = readConnection();
  if (!c || !currentBase || isLocalMain(c)) return null;
  return { base: currentBase, fileBase: fileServiceBase(currentBase, c), token: String(c.token || '') };
}
function offlineHtml(message) {
  const safe = String(message || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  return `<!doctype html><html><head><meta charset="utf-8"><title>${PRODUCT}</title><style>
  body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#eef4fb;color:#172033;min-height:100vh;display:grid;place-items:center}
  .card{width:min(600px,90vw);background:#fff;border:1px solid #dbe4ef;border-radius:18px;padding:32px;box-shadow:0 18px 60px #0001;text-align:center}
  .logo{width:74px;height:74px;border-radius:20px;background:#e8f0ff;color:#315bea;font-size:30px;font-weight:800;display:grid;place-items:center;margin:0 auto 14px}
  h1{font-size:25px;margin:4px 0 10px}.muted{color:#667085;line-height:1.6}.err{margin-top:16px;padding:12px;border-radius:10px;background:#fff3f3;color:#a11f1f}
  </style></head><body><div class="card"><div class="logo">VE</div><h1>Vihan Enterprices</h1><div class="muted">Desktop App v${APP_VERSION}<br>Main Service ko automatically connect/repair kiya ja raha hai…</div><div class="err">${safe}</div><div class="muted" style="margin-top:14px">Main PC par service band hui ho to app use khud start karega.<br>Client PC par Main PC ka IP badla ho to app LAN me use automatically dhoondhega.<br>Retry automatically hota rahega.</div></div></body></html>`;
}


function versionParts(v){return String(v||'0').replace(/^v/i,'').split('.').map(x=>parseInt(x,10)||0)}
function versionCompare(a,b){const A=versionParts(a),B=versionParts(b),n=Math.max(A.length,B.length);for(let i=0;i<n;i++){const d=(A[i]||0)-(B[i]||0);if(d)return d>0?1:-1}return 0}
function localInstallRoot(){return path.dirname(path.dirname(process.execPath))}
function localDiskVersion(){try{const x=readJson(path.join(localInstallRoot(),'app','version.json'));return String((x&&x.version)||APP_VERSION)}catch{return APP_VERSION}}
function fileServiceBase(mainBase,c){try{const u=new URL(mainBase);u.port=String(Number((c&&c.filePort)||((Number(u.port)||DEFAULT_PORT)+1)));return u.origin}catch{return mainBase}}
function tokenRequestJson(url,token,method='GET',body=null){return new Promise((resolve,reject)=>{let u;try{u=new URL(url)}catch(e){return reject(e)};const lib=u.protocol==='https:'?https:http;const payload=body==null?null:Buffer.from(JSON.stringify(body));const req=lib.request(u,{method,timeout:3500,headers:{'X-Vihan-Token':String(token||''),'Cache-Control':'no-store',...(payload?{'Content-Type':'application/json','Content-Length':String(payload.length)}:{})}},res=>{let txt='';res.setEncoding('utf8');res.on('data',d=>{if(txt.length<1024*1024)txt+=d});res.on('end',()=>{let data=null;try{data=JSON.parse(txt||'{}')}catch{};if(res.statusCode>=200&&res.statusCode<300)resolve(data||{});else reject(new Error((data&&data.error)||('HTTP '+res.statusCode)))})});req.on('timeout',()=>{req.destroy(new Error('Update service timeout'))});req.on('error',reject);if(payload)req.write(payload);req.end()})}
function updateHtml(title,detail){return `<!doctype html><html><head><meta charset="utf-8"><title>${PRODUCT}</title><style>body{margin:0;font-family:Segoe UI,Arial;background:#eef4fb;min-height:100vh;display:grid;place-items:center;color:#172033}.card{width:min(620px,90vw);background:#fff;border:1px solid #dbe4ef;border-radius:18px;padding:34px;text-align:center;box-shadow:0 18px 60px #0001}.logo{width:74px;height:74px;border-radius:20px;background:#e8f0ff;color:#315bea;font-size:28px;font-weight:800;display:grid;place-items:center;margin:auto}.bar{height:10px;background:#e7edf6;border-radius:99px;overflow:hidden;margin-top:18px}.fill{height:100%;width:100%;background:#315bea;animation:pulse 1s infinite alternate}@keyframes pulse{from{opacity:.45}to{opacity:1}}.muted{color:#667085;line-height:1.6}</style></head><body><div class="card"><div class="logo">VE</div><h2>${title}</h2><p class="muted">${detail}</p><div class="bar"><div class="fill"></div></div><p class="muted">Data, permissions aur connection safe rahenge.</p></div></body></html>`}
async function heartbeatUpdateService(base,c,status='running'){
  try{
    const fb=fileServiceBase(base,c),main=isLocalMain(c);
    let o={hasCache:false,savedAt:'',keys:0,lastError:'',allowed:undefined};
    if(!main){try{o=offline.getStatus()}catch{}}
    await tokenRequestJson(fb+'/api/update/heartbeat',c.token,'POST',{pcName:os.hostname(),version:localDiskVersion(),role:main?'Main PC':'Client PC',status,
      offlineHasCache:!!o.hasCache,offlineSavedAt:String(o.savedAt||''),offlineKeys:Number(o.keys)||0,offlineError:String(o.lastError||''),offlineAllowed:o.allowed===true?'yes':(o.allowed===false?'no':'')})
  }catch{}
}
async function maybeAutoUpdate(base,c){
  if(autoUpdating)return true;
  const diskVer=localDiskVersion();
  // Recovery safety: if app files are newer than the currently running desktop host,
  // never enter a restart loop. Continue opening the service; the safe updater/manual
  // recovery setup will refresh the desktop host on the next successful update.
  if(versionCompare(diskVer,APP_VERSION)>0){
    try{console.warn('Vihan desktop host version',APP_VERSION,'is behind app files',diskVer,'— continuing without restart loop.')}catch{}
  }
  let st;const fb=fileServiceBase(base,c);
  try{st=await tokenRequestJson(fb+'/api/update/status',c.token);await heartbeatUpdateService(base,c,'running')}catch{return false}
  const latest=String(st?.latest?.version||'');if(!latest||versionCompare(latest,diskVer)<=0)return false;
  // Main PC updates are applied once by the SYSTEM File Service updater.
  // Do not launch a second desktop updater from the Main PC app (race/partial-update risk).
  if(isLocalMain(c)){try{await heartbeatUpdateService(base,c,'main-update-managed-by-service')}catch{};return false}
  // Never reload a client with unacknowledged saves/conflicts to apply an update.
  if(mainWindow&&!mainWindow.isDestroyed()){
    try{const state=await Promise.race([mainWindow.webContents.executeJavaScript('window.vihanBeforeAppClose ? window.vihanBeforeAppClose() : Promise.resolve({pending:0})',true),new Promise(r=>setTimeout(()=>r(null),5200))]);if(!state||Number(state.pending)>0){await heartbeatUpdateService(base,c,'update-waiting-for-pending-saves');return false}}catch{return false}
  }
  autoUpdating=true;
  try{
    if(mainWindow&&!mainWindow.isDestroyed()){
      try{await Promise.race([mainWindow.webContents.executeJavaScript('window.vihanBeforeAppClose ? window.vihanBeforeAppClose() : Promise.resolve({pending:0})',true),new Promise(r=>setTimeout(r,4500))])}catch{}
      await mainWindow.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(updateHtml('Vihan Enterprices Update','v'+latest+' download/install ho raha hai. App automatically restart hogi…')))
    }
    const dir=path.join(localInstallRoot(),'updates');fs.mkdirSync(dir,{recursive:true});const pkg=path.join(dir,'Vihan_Enterprices_Update_v'+latest+'.veupdate');
    const expected=String(st?.latest?.sha256||'');
    await downloadWithToken(fb+'/api/update/package',c.token,pkg,null,expected);
    const src=path.join(localInstallRoot(),'runtime','AutoUpdater.ps1');if(!fs.existsSync(src))throw new Error('AutoUpdater missing');const temp=path.join(os.tmpdir(),'VihanAutoUpdater_'+Date.now()+'.ps1');fs.copyFileSync(src,temp);
    const exe=process.execPath;const ps=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
    const child=spawn(ps,['-NoProfile','-ExecutionPolicy','Bypass','-File',temp,'-PackagePath',pkg,'-InstallRoot',localInstallRoot(),'-RelaunchExe',exe,'-DelaySeconds','2'],{detached:true,windowsHide:true,stdio:'ignore'});child.unref();
    await heartbeatUpdateService(base,c,'updating');setTimeout(()=>app.exit(0),400);return true
  }catch(e){autoUpdating=false;try{await heartbeatUpdateService(base,c,'update-error');if(mainWindow&&!mainWindow.isDestroyed())mainWindow.webContents.executeJavaScript(`window.alert(${JSON.stringify('Auto Update error: '+e.message)})`,true).catch(()=>{})}catch{};return false}
}
function scheduleCentralUpdateChecks(base,c){if(updateCheckTimer)clearInterval(updateCheckTimer);updateCheckTimer=setInterval(()=>{if(!autoUpdating)maybeAutoUpdate(base,c).catch(()=>{})},45000)}

async function openService() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const c = readConnection();
  if (!c) {
    await mainWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(offlineHtml('Connection setting nahi mili. Start Menu se “Vihan Enterprices Setup” ek baar chalayein.')));
    scheduleRetry();
    return;
  }
  // While showing the offline copy, check for the Main PC quietly (no full LAN scan more than every 10 minutes).
  const doScan = !offlineActive || Date.now() - lastLanScanAt > 10 * 60 * 1000;
  if (doScan) lastLanScanAt = Date.now();
  const base = await findBase(c, { noScan: !doScan });
  if (!base) {
    currentBase = null;
    // Already showing the offline copy: keep the page as it is (never reload under the user's hands).
    if (offlineActive) { scheduleRetry(30000); return; }
    if (!isLocalMain(c)) {
      const info = await offline.startServer().catch(() => null);
      if (info) {
        try { await mainWindow.loadURL(info.url); offlineActive = true; scheduleRetry(30000); return; } catch {}
      }
    }
    const st = offline.getStatus();
    const why = st.allowed === false
      ? 'Is PC ko Main PC se offline copy ki permission nahi hai.'
      : (st.lastError ? 'Offline copy abhi tayyar nahi hai: ' + st.lastError : 'Is PC par abhi tak offline copy sync nahi hui. Main PC chalu hone par app ek baar kholiye.');
    await mainWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(offlineHtml('Main PC se connection nahi ho paya. ' + why)));
    scheduleRetry();
    return;
  }
  currentBase = base;
  offlineActive = false;
  try{const status=await tokenRequestJson(base+'/api/status',c.token);const port=Number(status.fileServicePort);if(Number.isInteger(port)&&port>0&&port<=65535&&port!==Number(c.filePort)){c.filePort=port;fs.writeFileSync(connectionPath(),JSON.stringify(c,null,2),'utf8')}}catch{}

  if (retryTimer) { clearTimeout(retryTimer); retryTimer = null; }

  if (await maybeAutoUpdate(base, c)) return;
  scheduleCentralUpdateChecks(base, c);

  // If DHCP changed the Main PC IP, scanLanForServer has already saved the new
  // connection. Chromium secure-origin switches are startup-only, so relaunch once
  // to activate camera support for the newly discovered trusted LAN origin.
  if (cameraOriginNeedsRestart(base)) {
    try {
      await mainWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(offlineHtml('Main PC ka network address update hua hai. Camera support activate karne ke liye app ek baar restart ho rahi hai…')));
    } catch {}
    setTimeout(() => { try { app.relaunch(); } catch {} app.exit(0); }, 700);
    return;
  }

  const url = base + '/connect?token=' + encodeURIComponent(String(c.token || ''));
  try { await mainWindow.loadURL(url); }
  catch {
    await mainWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(offlineHtml('Main Service mil gayi, lekin page load nahi hui. Dobara try ho raha hai.')));
    scheduleRetry();
  }
}

function scheduleRetry(ms = 5000) {
  if (retryTimer) return;
  retryTimer = setTimeout(async () => {
    retryTimer = null;
    await openService();
  }, ms);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    title: PRODUCT,
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#eef4fb',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      nativeWindowOpen: true,
      backgroundThrottling: false
    }
  });
  mainWindow.setMenuBarVisibility(false);
  mainWindow.maximize();
  mainWindow.once('ready-to-show', () => mainWindow && mainWindow.show());

  // v1.0.38: "Offline PC Access" opens a small in-app window (page served by the Main Service).
  // No Admin Key, no UAC, no PowerShell: the Main Service itself only accepts permission changes
  // that arrive from the Main PC (loopback / its own address) with a valid service login.
  const OFFLINE_ADMIN_URL = 'https://vihan-offline-admin.invalid/launch';
  function launchOfflineAdmin() {
    if (offlineActive || !currentBase) {
      dialog.showErrorBox('Offline Client Management', 'Main PC se connection nahi hai. Ye setting Main PC chalu hone par, Main PC ke app se hi badli ja sakti hai.');
      return;
    }
    try {
      if (offlineAdminWindow && !offlineAdminWindow.isDestroyed()) { offlineAdminWindow.focus(); return; }
      offlineAdminWindow = new BrowserWindow({
        title: 'Offline PC Access — ' + PRODUCT, width: 980, height: 660, minWidth: 720, minHeight: 480,
        parent: mainWindow || undefined, autoHideMenuBar: true, backgroundColor: '#eef4fb',
        webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true }
      });
      offlineAdminWindow.setMenuBarVisibility(false);
      offlineAdminWindow.on('closed', () => { offlineAdminWindow = null; });
      offlineAdminWindow.loadURL(currentBase + '/app/offline-admin.html').catch(err => dialog.showErrorBox('Offline Client Management', String(err && err.message || err)));
    } catch (err) { dialog.showErrorBox('Offline Client Management', String(err && err.message || err)); }
  }
  // Accept both a popup and a same-window click navigation, with a normal HTTPS URL.
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (url === OFFLINE_ADMIN_URL) { event.preventDefault(); launchOfflineAdmin(); }
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url === OFFLINE_ADMIN_URL || url === 'vihan-admin://offline') {
      launchOfflineAdmin();
      return {action:'deny'};
    }
    if (/^https?:/i.test(url) || url === 'about:blank' || /^blob:/i.test(url) || /^data:/i.test(url)) {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          autoHideMenuBar: true,
          webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, nativeWindowOpen: true }
        }
      };
    }
    if (url) shell.openExternal(url).catch(() => {});
    return { action: 'deny' };
  });

  mainWindow.webContents.on('did-create-window', (child) => {
    try { child.setMenuBarVisibility(false); } catch {}
  });

  mainWindow.on('close', (e) => {
    if (allowWindowClose || !mainWindow || mainWindow.isDestroyed()) return;
    e.preventDefault();
    const wc = mainWindow.webContents;
    Promise.race([
      wc.executeJavaScript('window.vihanBeforeAppClose ? window.vihanBeforeAppClose() : Promise.resolve({pending:0})', true).catch(() => null),
      new Promise(r => setTimeout(() => r(null), 5200))
    ]).finally(() => {
      allowWindowClose = true;
      try { mainWindow.close(); } catch { app.quit(); }
    });
  });
  mainWindow.on('closed', () => { mainWindow = null; allowWindowClose = false; });
  openService();
}

app.whenReady().then(() => {
  if(session.defaultSession.cookies?.on)session.defaultSession.cookies.on('changed',(_event,cookie)=>{if(cookie?.name!=='VE_SESSION')return;offline.wipeCache('User session changed; rebuild scoped offline copy');const context=offlineSyncContext();if(cookie.value&&context)setTimeout(()=>offline.syncOnce(context).catch(()=>{}),250)});
  // Camera permission is granted only to the configured Vihan Main Service origin.
  // Windows can still deny camera access globally through Privacy & security settings.
  try {
    session.defaultSession.setPermissionCheckHandler((webContents, permission, requestingOrigin) => {
      if (permission !== 'media') return false;
      return isTrustedMediaUrl(requestingOrigin || (webContents && webContents.getURL()));
    });
    session.defaultSession.setPermissionRequestHandler((webContents, permission, callback, details) => {
      if (permission !== 'media') return callback(false);
      const requestUrl = (details && (details.requestingUrl || details.securityOrigin)) || (webContents && webContents.getURL()) || '';
      callback(isTrustedMediaUrl(requestUrl));
    });
  } catch {}
  try { offline.cleanupLegacy(legacySnapshotFiles()); } catch {}
  try { offline.startScheduler(offlineSyncContext); } catch {}
  createWindow();
});
app.on('before-quit', () => { try { offline.stopScheduler(); offline.stopServer(); } catch {} });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
