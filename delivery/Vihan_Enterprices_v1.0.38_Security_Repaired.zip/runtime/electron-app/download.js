'use strict';
const fs=require('fs'),path=require('path'),http=require('http'),https=require('https'),crypto=require('crypto');
const {pipeline}=require('stream/promises');
async function downloadWithToken(url,token,destination,onProgress,expectedSha256){
  if(!/^[a-f0-9]{64}$/i.test(String(expectedSha256||'')))throw new Error('Update checksum is missing or invalid');
  const parsed=new URL(url);if(!['http:','https:'].includes(parsed.protocol))throw new Error('Unsupported download protocol');
  fs.mkdirSync(path.dirname(destination),{recursive:true});
  const temporary=destination+'.part.'+crypto.randomBytes(6).toString('hex');let response;
  try{
    response=await new Promise((resolve,reject)=>{
      const req=(parsed.protocol==='https:'?https:http).get(parsed,{timeout:120000,headers:{'X-Vihan-Token':String(token||''),'Cache-Control':'no-store'}},resolve);
      req.on('timeout',()=>req.destroy(new Error('Update download timeout')));req.on('error',reject);
    });
    if(response.statusCode!==200){response.resume();throw new Error('Update download HTTP '+response.statusCode)}
    let bytes=0;const expectedSize=Number(response.headers['content-length']||0),hash=crypto.createHash('sha256');
    response.on('data',chunk=>{bytes+=chunk.length;hash.update(chunk);if(onProgress)onProgress(bytes,expectedSize)});
    await pipeline(response,fs.createWriteStream(temporary));
    if(expectedSize&&bytes!==expectedSize)throw new Error('Incomplete update download');
    if(hash.digest('hex').toLowerCase()!==expectedSha256.toLowerCase())throw new Error('Update checksum mismatch');
    const fd=fs.openSync(temporary,'r+');try{fs.fsyncSync(fd)}finally{fs.closeSync(fd)}
    fs.renameSync(temporary,destination);return destination;
  }catch(error){if(response)response.destroy();try{fs.unlinkSync(temporary)}catch{}throw error}
}
module.exports={downloadWithToken};
