#define MyAppName "Vihan Enterprices"
#define MyAppVersion "1.0.38"
#define MyAppPublisher "Vihan Enterprices"
[Setup]
AppId={{0F915C66-5EB7-46E0-8236-B4D816FE55E1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\VihanEnterpricesInstallerSource
DefaultGroupName={#MyAppName}
OutputDir=Output
OutputBaseFilename=Vihan_Enterprices_v1.0.38_Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
WizardStyle=modern
ArchitecturesAllowed=x64compatible
UninstallDisplayName=Vihan Enterprices
[Files]
Source: "app\*"; DestDir: "{app}\app"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "runtime\*"; DestDir: "{app}\runtime"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "installer\*"; DestDir: "{app}\installer"; Flags: ignoreversion recursesubdirs createallsubdirs
[Tasks]
Name: "main"; Description: "Main PC / Server"; GroupDescription: "Choose this PC role:"; Flags: exclusive
Name: "client"; Description: "Client PC"; GroupDescription: "Choose this PC role:"; Flags: exclusive unchecked
[Run]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\Install.ps1"" -Mode Main"; Description: "Install Main PC"; Flags: waituntilterminated; Tasks: main
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\installer\Install.ps1"" -Mode Client"; Description: "Install Client PC"; Flags: waituntilterminated; Tasks: client

[Code]
function InitializeUninstall(): Boolean;
var
  ExitCode: Integer;
begin
  Result := Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
    '-NoProfile -ExecutionPolicy Bypass -File "' + ExpandConstant('{app}\installer\EasyUninstall.ps1') + '"',
    '', SW_SHOWNORMAL, ewWaitUntilTerminated, ExitCode);
  if Result then
    Result := ExitCode = 0;
  if not Result then
    MsgBox('Uninstall cancelled or failed. Application/data removal was not confirmed.', mbInformation, MB_OK);
end;
