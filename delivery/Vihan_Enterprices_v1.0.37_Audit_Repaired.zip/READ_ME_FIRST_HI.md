# VIHAN ENTERPRICES 1.0.37

पहले reports/audit/AUDIT_REPORT_HI.md और INSTALL_UPDATE_HI.md पढ़ें। 77 automated tests passed; वास्तविक Windows verification बाकी है। Server-side user/company authorization और plaintext credential model की confirmed समस्या अभी unresolved है। इसे 100% certified software न मानें। Production data/config इस ZIP में नहीं है। Existing install/data को blindly move/reset न करें। Installer source .iss और installer/Install.ps1 शामिल हैं; compiled .exe उपलब्ध नहीं।
