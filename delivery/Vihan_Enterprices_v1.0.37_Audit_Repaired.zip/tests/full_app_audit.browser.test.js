'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright');const {startFixture,openCompany2}=require('./helpers/company2-browser-harness');
let browser,fixture,page,context,errors;
test.before(async()=>browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox'],headless:true}));
test.after(async()=>browser?.close());
test.beforeEach(async()=>{fixture=await startFixture();({page,context,errors}=await openCompany2(browser,fixture));await page.evaluate(()=>backToAdmin())});
test.afterEach(async()=>{await context?.close();await fixture?.close()});
const until=(fn,arg)=>page.waitForFunction(fn,arg,{timeout:9000});
const nav=label=>page.locator('.sidebar > button.nav').filter({hasText:label}).click();

test('all Admin sections and existing static button handler targets load without undefined functions',async()=>{
 for(const [label,id] of [['Admin Dashboard','dashboard'],['Company Management','companies'],['Staff Management','staffManagement'],['All Users','users'],['System Settings','settings']]){await nav(label);assert.ok(await page.locator('#'+id).isVisible());assert.equal(await page.locator('.sidebar .nav.active').count(),1)}
 const controls=await page.evaluate(()=>[...document.querySelectorAll('button[onclick]')].map(b=>{const code=b.getAttribute('onclick'),target=/^\s*([\w$]+)\s*\(/.exec(code)?.[1];return{id:b.id,label:b.textContent.trim().slice(0,120),handler:code,target,type:target?(0,eval)('typeof '+target):'expression'}}));
 const missing=controls.filter(x=>x.target&&x.type==='undefined');assert.deepEqual(missing,[]);
 fs.writeFileSync(path.join(__dirname,'../reports/audit/control-inventory.json'),JSON.stringify(controls,null,2));assert.ok(controls.length>100);assert.deepEqual(errors,[]);
});

test('Company create/edit and Company 1/Utopiya identity survive reload without cross-company data changes',async()=>{
 await nav('Company Management');await page.evaluate(()=>editCompany(''));await page.locator('#cName').fill('Audit Test Company');await page.locator('#cAdmin').fill('audit-admin');await page.locator('#cPass').fill('fixture-only');await page.evaluate(()=>saveCompany());await until(()=>getData().companies.some(c=>c.name==='Audit Test Company'));
 const created=await page.evaluate(()=>getData().companies.find(c=>c.name==='Audit Test Company').id);await page.evaluate(id=>editCompany(id),created);await page.locator('#cName').fill('Edited Audit Company');await page.evaluate(()=>saveCompany());await until(()=>getData().companies.some(c=>c.name==='Edited Audit Company'));
 await page.evaluate(id=>editCompany(id),created);await page.locator('#cName').fill('Company 2');await page.evaluate(()=>saveCompany());assert.equal(await page.evaluate(id=>getData().companies.find(c=>c.id===id).name,created),'Edited Audit Company');await page.evaluate(()=>closeModal('companyModal'));
 const before=await page.evaluate(()=>getData().companies.find(c=>c.name==='Company 2'));
 for(const name of ['Company 3','Company 4','Company 5','Edited Audit Company']){await page.evaluate(name=>viewCompany(getData().companies.find(c=>c.name===name).id),name);assert.ok(await page.locator('#companyHome').isVisible());assert.equal(await page.locator('#appCompany').innerText(),name);await page.locator('#backAdmin').click()}
 await page.evaluate(()=>{const d=getData(),c=d.companies.find(c=>c.id===d.studentCompanyId);c.name='Utopiya Library';save(d);viewCompany(c.id)});assert.ok(await page.locator('.companyOnly').filter({hasText:'Students'}).isVisible());assert.deepEqual(await page.evaluate(()=>getData().companies.find(c=>c.name==='Company 2')),before);
 assert.equal(await page.evaluate(()=>vihanWaitForSaved()),true);await page.reload();await until(()=>document.getElementById('app').style.display==='block');assert.ok(await page.locator('#companyHome').isVisible());assert.equal(await page.locator('#appCompany').innerText(),'Utopiya Library');assert.deepEqual(errors,[]);
});

test('Company 1 student validation, double-save prevention, edit/search and company data isolation',async()=>{
 await page.evaluate(()=>viewCompany(getData().companies[0].id));await nav('Students');await page.evaluate(()=>openStudent());await page.evaluate(()=>saveStudent());assert.equal(await page.evaluate(()=>studentCompany().students.length),0);
 await page.locator('#sName').fill('Audit Student');await page.locator('#sFather').fill('Fixture Father');await page.locator('#sPhone').fill('9876543210');await page.evaluate(()=>{saveStudent();saveStudent()});await until(()=>studentCompany().students.length===1&&!saveStudent._saving);
 const id=await page.evaluate(()=>studentCompany().students[0].id);await page.evaluate(id=>editStudent(id),id);await page.locator('#sName').fill('Edited Student');await page.evaluate(()=>saveStudent());await until(()=>studentCompany().students[0].name==='Edited Student'&&!saveStudent._saving);await page.locator('#studentSearch').fill('missing-name');assert.ok(!(await page.locator('#students').innerText()).includes('Edited Student'));await page.locator('#studentSearch').fill('Edited Student');assert.ok((await page.locator('#students').innerText()).includes('Edited Student'));
 assert.equal(await page.evaluate(()=>getData().companies.slice(1).reduce((n,c)=>n+c.students.length,0)),0);assert.deepEqual(errors,[]);
});

test('Company 1 Joining, Payment, Leave and Reports navigation and a linked joining/payment',async()=>{
 await page.evaluate(()=>viewCompany(getData().companies[0].id));await nav('Students');await page.evaluate(()=>openStudent());await page.locator('#sName').fill('Fees Student');await page.evaluate(()=>saveStudent());await until(()=>!saveStudent._saving&&studentCompany().students.length===1);
 for(const [label,id] of [['Student Joining','studentJoining'],['Student Leave','studentLeave'],['Payment In / Out','paymentIn'],['Student Report','studentReport']]){await nav(label);assert.ok(await page.locator('#'+id).isVisible());assert.equal(await page.locator('.sidebar .nav.active').count(),1)}
 await nav('Student Joining');await page.evaluate(()=>openJoiningForm());await page.evaluate(()=>{selectedJoiningStudentId=studentCompany().students[0].id;jSheetNo.value='AUDIT-1';jJoiningDate.value='2026-10-20';jFees.value='500';jPaid.value='100';saveJoining()});await until(()=>studentCompany().joinings.length===1);assert.equal(await page.evaluate(()=>studentCompany().payments.filter(p=>p.source==='Student Joining').length),1);
 await nav('Payment In / Out');await page.evaluate(()=>{selectedPaymentStudentId=studentCompany().students[0].id;paymentAmount.value='50';paymentDescription.value='Audit fee payment'});await page.evaluate(()=>savePaymentIn());await until(()=>studentCompany().payments.length===2);assert.equal(await page.evaluate(()=>studentCompany().payments.reduce((n,p)=>n+Number(p.amount||0),0)),150);await nav('Student Report');assert.ok((await page.locator('#studentReport').innerText()).includes('Fees Student'));assert.deepEqual(errors,[]);
});

test('Staff create/edit/tabs/delete and settings backup error reporting',async()=>{
 await nav('Staff Management');await page.evaluate(()=>sm712ClearStaff());await page.locator('#sm712CompanyChecks input').first().check();await page.locator('#sm712Name').fill('Audit Staff');await page.locator('#sm712MonthlySalary').fill('12000');await page.evaluate(()=>sm712SaveStaff());await until(()=>sm712Data().staff.length===1);const id=await page.evaluate(()=>sm712Data().staff[0].id);await page.evaluate(id=>sm712EditStaff(id),id);await page.locator('#sm712Name').fill('Edited Staff');await page.evaluate(()=>sm712SaveStaff());assert.equal(await page.evaluate(()=>sm712Data().staff[0].name),'Edited Staff');
 for(const tab of ['attendance','salary','permissions','activity','staff']){await page.locator('.sm712-tab').filter({hasText:({attendance:'Attendance',salary:'Salary',permissions:'Permissions',activity:'Activity Report',staff:'Add Staff / Staff List'})[tab]}).click();assert.ok(await page.locator('#sm712Panel_'+tab).isVisible())}
 await page.evaluate(id=>sm712DeleteStaff(id),id);assert.equal(await page.evaluate(()=>sm712Data().staff.length),0);
 await nav('System Settings');await page.route('**/api/backup',r=>r.fulfill({status:500,contentType:'application/json',body:'{"error":"injected backup disk failure"}'}));await page.evaluate(()=>ve104BackupNow());assert.ok((await page.locator('#ve104BackupMessage').innerText()).includes('injected backup disk failure'));assert.ok(!(await page.locator('#ve104BackupMessage').innerText()).includes('successfully'));assert.deepEqual(errors,[]);
});

test('successful backup response updates last-backup status without ReferenceError',async()=>{
 await nav('System Settings');await page.route('**/api/backup',r=>r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({ok:true,file:'fixture-backup.zip',backupPath:'D:\\Backups'})}));await page.evaluate(()=>ve104BackupNow());assert.ok((await page.locator('#ve104LastBackup').innerText()).includes('fixture-backup.zip'));assert.ok((await page.locator('#ve104BackupMessage').innerText()).includes('successfully'));assert.deepEqual(errors,[]);
});

test('two clients conflict: stale text is not retried over Main data and remains pending for review',async()=>{
 const second=await openCompany2(browser,fixture);try{
  await page.evaluate(()=>localStorage.setItem('audit_conflict','Main version'));assert.equal(await page.evaluate(()=>vihanWaitForSaved()),true);
  await second.page.evaluate(()=>localStorage.setItem('audit_conflict','Client unsaved version'));assert.equal(await second.page.evaluate(()=>vihanFlushPending()),false);await second.page.waitForTimeout(1000);
  assert.equal(fixture.storage.get('audit_conflict').value,'Main version');assert.equal(await second.page.evaluate(()=>localStorage.getItem('audit_conflict')),'Client unsaved version');assert.equal(await second.page.evaluate(()=>vihanConflicts().length),1);
  assert.equal(await second.page.evaluate(()=>vihanWaitForSaved(500)),false);assert.deepEqual(second.errors,[]);
 }finally{await second.context.close()}
});

test('user cannot directly open Admin pages or denied sidebar modules',async()=>{
 const user=await openCompany2(browser,fixture,'user');try{
  for(const id of ['companies','staffManagement','users','settings','auditReportV612']){await user.page.evaluate(id=>page(id),id);assert.ok(await user.page.locator('#'+id).isHidden())}
  await user.page.evaluate(()=>{localStorage.setItem('company2_user_role_permissions_v408',JSON.stringify({user:{c2InquiryAccess:true}}));db609ApplyCompany2MainModulePermissions()});assert.ok(await user.page.locator('#allDocumentsBtnV819').isHidden());await user.page.evaluate(()=>v1033Company2Navigate('All Documents'));assert.ok(await user.page.locator('#allDocumentsPageV819').isHidden());assert.deepEqual(user.errors,[]);
 }finally{await user.context.close()}
});

test('failed text save remains pending and never reports Main PC confirmed saved',async()=>{
 await page.route('**/api/storage/batch',route=>route.fulfill({status:500,contentType:'application/json',body:'{"error":"injected database failure"}'}));
 await page.evaluate(()=>localStorage.setItem('audit_failed_save','pending local data'));
 assert.equal(await page.evaluate(()=>vihanWaitForSaved(600)),false);
 assert.equal(await page.evaluate(()=>localStorage.getItem('audit_failed_save')),'pending local data');
 assert.ok((await page.locator('#vihanServiceBadge').innerText()).includes('Pending'));
 assert.ok(!fixture.storage.has('audit_failed_save'));
});

test('configured File Service on a nonadjacent port is used directly for file listing',async()=>{
 const custom=await startFixture({nonAdjacentFilePort:true});const client=await openCompany2(browser,custom);
 try{await client.page.locator('#allDocumentsBtnV819').click();await client.page.waitForFunction(()=>document.getElementById('v819Body')?.textContent.length>0);const lists=custom.requests.filter(x=>x.path==='/api/blob/list');assert.ok(lists.length>0);assert.ok(lists.every(x=>x.port===custom.filePort));assert.notEqual(custom.filePort,Number(new URL(custom.url).port)+1);assert.deepEqual(client.errors,[])}finally{await client.context.close();await custom.close()}
});
for(const keepLocal of [true,false])test('conflict resolution applies only explicit operator choice: '+(keepLocal?'keep local':'keep Main'),async()=>{
 const second=await openCompany2(browser,fixture);
 try{await page.evaluate(()=>localStorage.setItem('audit_choice','Main version'));assert.equal(await page.evaluate(()=>vihanWaitForSaved()),true);await second.page.evaluate(()=>localStorage.setItem('audit_choice','Local version'));await second.page.evaluate(()=>vihanFlushPending());assert.equal(await second.page.evaluate(()=>vihanConflicts().length),1);
 const result=await second.page.evaluate(async keep=>{const previous=window.confirm;window.confirm=()=>true;let calls=0;if(!keep)window.confirm=()=>++calls>1;try{return await vihanResolveConflicts()}finally{window.confirm=previous}},keepLocal);assert.equal(result,true);assert.equal(fixture.storage.get('audit_choice').value,keepLocal?'Local version':'Main version');assert.equal(await second.page.evaluate(()=>vihanConflicts().length),0);assert.equal(await second.page.evaluate(()=>localStorage.getItem('audit_choice')),keepLocal?'Local version':'Main version');assert.deepEqual(second.errors,[]);
 }finally{await second.context.close()}
});

test('Staff attendance update is idempotent and salary/payment ledger balances match saved entries',async()=>{
 await nav('Staff Management');await page.evaluate(()=>sm712ClearStaff());await page.locator('#sm712CompanyChecks input').first().check();await page.locator('#sm712Name').fill('Payroll Fixture');await page.locator('#sm712MonthlySalary').fill('12000');await page.locator('#sm712SalaryBasis').selectOption('30');await page.evaluate(()=>sm712SaveStaff());const id=await page.evaluate(()=>sm712Data().staff[0].id);
 await page.locator('.sm712-tab').filter({hasText:'Attendance'}).click();await page.locator('#sm729SummaryBtn').click();await page.locator('#sm729Date').fill('2026-10-20');await page.locator('#sm729Staff').selectOption(id);await page.locator('#sm729StatusButtons [data-status="Present"]').click();await page.evaluate(()=>{sm729SaveSummary();sm729SaveSummary()});assert.equal(await page.evaluate(()=>sm712Data().attendance.length),1);assert.equal(await page.evaluate(()=>sm712Data().attendance[0].status),'Present');
 await page.locator('.sm712-tab').filter({hasText:'Salary',exact:true}).click();await page.evaluate(id=>{sm712SalaryMonth.value='2026-10';sm712SalaryStaff.value=id;sm712Bonus.value='0';sm712Advance.value='0';sm712Deduction.value='0';sm712PaidAmount.value='100';sm712SaveSalary()},id);assert.equal(await page.evaluate(()=>sm712Data().salary[0].net),400);assert.equal(await page.evaluate(()=>sm712Data().salary[0].paid),100);assert.equal(await page.evaluate(()=>sm712Data().salary[0].balance),300);assert.deepEqual(errors,[]);
});
