'use strict';
// Run:  node --test tests/offline.test.js     (Node 18+; no packages needed)
process.env.TZ = 'Asia/Kolkata';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http');
const { createOfflineManager, isSyncDue, latestSlotStart, RETRY_MS } = require('../runtime/electron-app/offline.js');

const TOKEN = 'tok123';
const at = (y, m, d, h, mi = 0) => new Date(y, m - 1, d, h, mi, 0, 0).getTime();

// ---------- schedule ----------
test('schedule: first sync is due immediately', () => {
  assert.strictEqual(isSyncDue(at(2026, 10, 19, 11), {}, 'PC1').due, true);
});
test('schedule: synced after last 8PM -> not due all day', () => {
  const st = { lastSuccessAt: at(2026, 10, 18, 20, 12) };
  for (const h of [0, 8, 14, 19]) assert.strictEqual(isSyncDue(at(2026, 10, 19, h, 59), st, 'PC1').due, false, 'hour ' + h);
});
test('schedule: after 8PM it becomes due once stagger delay passes (max 10 min)', () => {
  const st = { lastSuccessAt: at(2026, 10, 18, 20, 12) };
  assert.strictEqual(isSyncDue(at(2026, 10, 19, 20, 0), st, 'PC1').reason === 'stagger-wait' || isSyncDue(at(2026, 10, 19, 20, 0), st, 'PC1').due, true);
  assert.strictEqual(isSyncDue(at(2026, 10, 19, 20, 11), st, 'PC1').due, true);
});
test('schedule: different PCs get different start delays', () => {
  const st = { lastSuccessAt: at(2026, 10, 18, 20, 12) };
  const t = at(2026, 10, 19, 20, 0) + 1000;
  const r = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map(n => isSyncDue(t, st, n).due);
  assert.ok(r.includes(false), 'at least one PC should still be waiting');
});
test('schedule: failed attempt is retried every 30 min, not sooner', () => {
  const st = { lastSuccessAt: at(2026, 10, 18, 20, 12), lastAttemptAt: at(2026, 10, 19, 20, 11) };
  assert.strictEqual(isSyncDue(at(2026, 10, 19, 20, 30), st, 'PC1').due, false);
  assert.strictEqual(isSyncDue(at(2026, 10, 19, 20, 11) + RETRY_MS + 1000, st, 'PC1').due, true);
});
test('schedule: a PC that was just switched ON starts within ~2 minutes (not 30)', () => {
  const t0 = at(2026, 10, 19, 11, 0);
  const st = { lastAttemptAt: t0, lastResult: 'not-allowed' };
  assert.strictEqual(isSyncDue(t0 + 60 * 1000, st, 'PC1').due, false);
  assert.strictEqual(isSyncDue(t0 + 2 * 60 * 1000 + 1000, st, 'PC1').due, true);
  assert.strictEqual(isSyncDue(t0 + 5 * 60 * 1000, { lastAttemptAt: t0, lastResult: 'error' }, 'PC1').due, false, 'real errors still wait 30 min');
});
test('schedule: PC was off at 8PM -> catch-up when opened next morning', () => {
  const st = { lastSuccessAt: at(2026, 10, 18, 20, 12) };
  assert.strictEqual(isSyncDue(at(2026, 10, 20, 8, 5), st, 'PC1').due, true);   // missed 19th 8PM
  assert.strictEqual(isSyncDue(at(2026, 10, 19, 21, 0), st, 'PC1').due, true);
});
test('schedule: before 8PM the slot is yesterday 8PM', () => {
  assert.strictEqual(latestSlotStart(at(2026, 10, 19, 9)), at(2026, 10, 18, 20));
  assert.strictEqual(latestSlotStart(at(2026, 10, 19, 20, 1)), at(2026, 10, 19, 20));
});

// ---------- mock Main PC ----------
function mockMain(model) {
  const h = (req, res) => {
    const u = new URL(req.url, 'http://x'); const p = u.pathname;
    model.hits.push(p);
    const json = (o, s = 200) => { const b = Buffer.from(JSON.stringify(o)); res.writeHead(s, { 'Content-Type': 'application/json', 'Content-Length': b.length }); res.end(b); };
    if (req.headers['x-vihan-token'] !== TOKEN) return json({ error: 'auth' }, 401);
    const pc = u.searchParams.get('pc');
    if (p === '/api/offline/permission') return json({ ok: true, allowed: model.allowed.has(pc) });
    if (!model.allowed.has(pc)) return json({ error: 'Offline copy is not allowed for this PC' }, 403);
    if (p === '/api/offline/data') {
      const since = Number(u.searchParams.get('since')) || 0;
      if (since <= 0 || model.forceFull) return json({ full: true, revision: model.rev, items: model.items });
      return json({ full: false, revision: model.rev, changes: model.changes.filter(c => c.revision > since) });
    }
    if (p === '/api/offline/manifest') return json({ ok: true, items: model.blobs.map(b => ({ db: b.db, store: b.store, id: b.id, updatedAt: b.updatedAt, blobType: b.type, hasBlob: !!b.bytes, size: b.bytes ? b.bytes.length : 0, recordJson: JSON.stringify(b.record) })) });
    if (p === '/api/offline/blob') {
      if (model.failBlob) { res.writeHead(500); return res.end(); }
      const b = model.blobs.find(x => x.db === u.searchParams.get('db') && x.store === u.searchParams.get('store') && x.id === u.searchParams.get('id'));
      if (!b || !b.bytes) return json({ error: 'File not found' }, 404);
      res.writeHead(200, { 'Content-Type': b.type, 'Content-Length': b.bytes.length }); return res.end(b.bytes);
    }
    json({ error: 'nf' }, 404);
  };
  return new Promise(r => { const s = http.createServer(h); s.listen(0, '127.0.0.1', () => r({ s, base: 'http://127.0.0.1:' + s.address().port })); });
}
function freshModel() {
  return {
    hits: [], allowed: new Set(['PC-CLIENT']), rev: 10, forceFull: false, failBlob: false,
    items: { company_1_daybook: { value: '[{"amt":100}]', keyRev: 3 }, company_1_ledger: { value: '{"a":1}', keyRev: 4 }, mcSession_not_here: { value: 'x', keyRev: 1 }, gone: { value: 'del', deleted: true, keyRev: 2 } },
    changes: [],
    blobs: [{ db: 'docsDB', store: 'files', id: 'f1', updatedAt: '2026-10-18T10:00:00Z', type: 'application/pdf', bytes: Buffer.from('%PDF-1.4 hello'), record: { id: 'f1', name: 'a.pdf' } },
             { db: 'docsDB', store: 'files', id: 'f2', updatedAt: '2026-10-18T10:05:00Z', type: 'image/png', bytes: Buffer.from([137, 80, 78, 71, 1, 2, 3]), record: { id: 'f2', name: 'b.png' } },
             { db: 'docsDB', store: 'files', id: 'nofile', updatedAt: '2026-10-18T10:06:00Z', type: '', bytes: null, record: { id: 'nofile', name: 'folder' } }]
  };
}
function mkManager(dir, host = 'PC-CLIENT', extra = {}) {
  const appDir = path.join(dir, 'app'); fs.mkdirSync(appDir, { recursive: true });
  fs.writeFileSync(path.join(appDir, 'bootstrap.html'), '<html>BOOT</html>');
  fs.writeFileSync(path.join(appDir, 'vihan-sync.js'), '(function(){})();');
  fs.writeFileSync(path.join(appDir, 'index.html'), '<html>APP</html>');
  return createOfflineManager({ hostname: host, dataDir: () => path.join(dir, 'data'), appDir: () => appDir, ...extra });
}
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'vihan-off-'));
const get = (url, cookie) => new Promise((resolve, reject) => { http.get(url, { headers: cookie ? { Cookie: cookie } : {} }, r => { const c = []; r.on('data', d => c.push(d)); r.on('end', () => resolve({ status: r.statusCode, headers: r.headers, body: Buffer.concat(c) })); }).on('error', reject); });
const send = (method, url, cookie) => new Promise((resolve, reject) => { const u = new URL(url); const q = http.request({ hostname: u.hostname, port: u.port, path: u.pathname + u.search, method, headers: { Cookie: cookie, 'Content-Length': 2 } }, r => { r.resume(); r.on('end', () => resolve(r.statusCode)); }); q.on('error', reject); q.end('{}'); });

// ---------- sync ----------
test('sync: PC that is NOT allowed gets no data and no files', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir, 'PC-OTHER');
  const r = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r.skipped, 'not-allowed');
  assert.strictEqual(om.hasUsableCache(), false);
  assert.ok(!m.hits.includes('/api/offline/data') && !m.hits.includes('/api/offline/manifest'));
  assert.ok(!fs.existsSync(path.join(dir, 'data', 'offline-data.json')));
  s.close();
});
test('sync: allowed PC gets data + attachments; deleted keys excluded', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir);
  const r = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r.ok, true);
  const d = om._internals.loadData();
  assert.deepStrictEqual(Object.keys(d.items).sort(), ['company_1_daybook', 'company_1_ledger', 'mcSession_not_here']);
  assert.strictEqual(d.revision, 10);
  const st = om._internals.readState();
  assert.ok(st.lastSuccessAt > 0 && st.allowed === true);
  assert.strictEqual(st.blobs.downloaded, 2);
  assert.strictEqual(fs.readdirSync(om._paths.files()).length, 2);
  s.close();
});
test('sync: second run only fetches changes and changed attachments', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir);
  await om.syncOnce({ base, fileBase: base, token: TOKEN });
  m.rev = 12; m.changes = [{ revision: 11, key: 'company_1_daybook', value: '[{"amt":999}]', keyRev: 5, deleted: false }, { revision: 12, key: 'company_1_ledger', deleted: true, keyRev: 6 }];
  m.blobs[0].updatedAt = '2026-10-19T08:00:00Z'; m.blobs[0].bytes = Buffer.from('%PDF-1.4 changed content');
  m.hits.length = 0;
  const r = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r.ok, true);
  const d = om._internals.loadData();
  assert.strictEqual(d.items.company_1_daybook.value, '[{"amt":999}]');
  assert.ok(!d.items.company_1_ledger);
  assert.strictEqual(d.revision, 12);
  assert.strictEqual(r.blobs.downloaded, 1, 'only the changed attachment is downloaded');
  assert.strictEqual(m.hits.filter(h => h === '/api/offline/blob').length, 1);
  s.close();
});
test('sync: empty/settings-only answer from Main never erases a useful copy', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir);
  await om.syncOnce({ base, fileBase: base, token: TOKEN });
  m.items = {}; m.rev = 1; m.forceFull = true;
  const r = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r.ok, false);
  assert.strictEqual(Object.keys(om._internals.loadData().items).length, 3);
  s.close();
});
test('sync: Main restored from older backup (lower revision) -> full replacement', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir);
  await om.syncOnce({ base, fileBase: base, token: TOKEN });
  m.rev = 5; m.items = { company_1_daybook: { value: '[]', keyRev: 1 }, company_1_ledger: { value: '{}', keyRev: 1 }, k3: { value: '1', keyRev: 1 } };
  const r = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(om._internals.loadData().revision, 5);
  s.close();
});
test('sync: attachment failure keeps data, is NOT marked complete, and is retried', async () => {
  const m = freshModel(); m.failBlob = true; const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir);
  const r = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r.ok, false);
  assert.ok(om.hasUsableCache());
  assert.ok(!om._internals.readState().lastSuccessAt);
  m.failBlob = false;
  const r2 = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r2.ok, true);
  assert.strictEqual(r2.blobs.downloaded, 2);
  s.close();
});
test('sync: Main unreachable keeps the old copy', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir);
  await om.syncOnce({ base, fileBase: base, token: TOKEN });
  s.close();
  const r = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r.ok, false);
  assert.ok(om.hasUsableCache());
});
test('sync: permission removed on Main -> offline copy is deleted from this PC', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  let wiped = 0;
  const om = mkManager(dir, 'PC-CLIENT', { onWipe: () => wiped++ });
  await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.ok(om.hasUsableCache());
  m.allowed.delete('PC-CLIENT');
  const r = await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(r.skipped, 'not-allowed');
  assert.strictEqual(om.hasUsableCache(), false);
  assert.strictEqual(fs.existsSync(om._paths.files()), false);
  assert.strictEqual(wiped, 1);
  s.close();
});
test('sync: deleted attachment on Main is removed from the copy', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir);
  await om.syncOnce({ base, fileBase: base, token: TOKEN });
  m.blobs.splice(1, 1);
  await om.syncOnce({ base, fileBase: base, token: TOKEN });
  assert.strictEqual(fs.readdirSync(om._paths.files()).length, 1);
  assert.strictEqual(Object.keys(om._internals.loadIndex().items).length, 2);
  s.close();
});

// ---------- local read-only server ----------
test('server: needs auth, serves original pages, snapshot, blobs, refuses all writes', async () => {
  const m = freshModel(); const { s, base } = await mockMain(m); const dir = tmp();
  const om = mkManager(dir);
  assert.strictEqual(await om.startServer(), null, 'no server without a copy');
  await om.syncOnce({ base, fileBase: base, token: TOKEN });
  const info = await om.startServer();
  assert.ok(info && info.port >= 17890);
  assert.strictEqual((await get(info.origin + '/api/snapshot')).status, 401);
  const c = await get(info.url);
  assert.strictEqual(c.status, 302);
  const cookie = c.headers['set-cookie'][0].split(';')[0];
  assert.strictEqual((await get(info.origin + '/connect?token=bad')).status, 403);
  assert.match((await get(info.origin + '/', cookie)).body.toString(), /BOOT/);
  assert.match((await get(info.origin + '/app/index.html', cookie)).body.toString(), /APP/);
  const js = (await get(info.origin + '/app/vihan-sync.js', cookie)).body.toString();
  assert.ok(js.startsWith('window.__VIHAN_OFFLINE__=true;'));
  const snap = JSON.parse((await get(info.origin + '/api/storage/changes?since=10', cookie)).body);
  assert.strictEqual(snap.full, true); assert.strictEqual(snap.revision, 10);
  assert.strictEqual(snap.items.company_1_daybook.value, '[{"amt":100}]');
  const list = JSON.parse((await get(info.origin + '/api/blob/list?db=docsDB&store=files', cookie)).body);
  assert.deepStrictEqual(list.items.map(x => x.id), ['f1', 'f2', 'nofile']);
  const f = await get(info.origin + '/api/blob/file?db=docsDB&store=files&id=f1', cookie);
  assert.strictEqual(f.body.toString(), '%PDF-1.4 hello'); assert.strictEqual(f.headers['content-type'], 'application/pdf');
  const meta = JSON.parse((await get(info.origin + '/api/blob/meta?db=docsDB&store=files&id=nofile', cookie)).body);
  assert.strictEqual(meta.hasBlob, false);
  assert.strictEqual((await get(info.origin + '/api/blob/file?db=docsDB&store=files&id=nofile', cookie)).status, 404);
  const g = JSON.parse((await get(info.origin + '/api/blob/get?db=docsDB&store=files&id=f2', cookie)).body);
  assert.strictEqual(Buffer.from(g.blobBase64, 'base64').length, 7);
  for (const p of ['/api/storage/set', '/api/storage/batch', '/api/storage/remove', '/api/blob/put', '/api/blob/put-binary', '/api/blob/delete', '/api/backup/restore'])
    assert.strictEqual(await send('POST', info.origin + p, cookie), 403, p);
  assert.strictEqual((await get(info.origin + '/app/..%2f..%2fdata%2foffline-data.json', cookie)).status, 404);
  assert.strictEqual((await get(info.origin + '/app/../data/offline-data.json', cookie)).status, 404);
  const st = JSON.parse((await get(info.origin + '/api/status', cookie)).body);
  assert.strictEqual(st.offline, true); assert.ok(st.savedAt);
  om.stopServer(); s.close();
});

test('sync: failed refresh of an existing attachment retains its previous bytes and index reference',async()=>{
 const model=freshModel(),{s,base}=await mockMain(model),dir=tmp(),manager=mkManager(dir);
 try{
  assert.equal((await manager.syncOnce({base,fileBase:base,token:TOKEN})).ok,true);
  const key='docsDB|files|f1',before=manager._internals.loadIndex().items[key],oldBytes=fs.readFileSync(path.join(manager._paths.files(),before.file));
  model.blobs[0].updatedAt='2026-10-20T12:00:00Z';model.blobs[0].bytes=Buffer.from('new remote content');model.failBlob=true;
  const failed=await manager.syncOnce({base,fileBase:base,token:TOKEN});assert.equal(failed.ok,false);
  const retained=manager._internals.loadIndex().items[key];assert.equal(retained.file,before.file);assert.deepEqual(fs.readFileSync(path.join(manager._paths.files(),retained.file)),oldBytes);
  model.failBlob=false;assert.equal((await manager.syncOnce({base,fileBase:base,token:TOKEN})).ok,true);
  assert.deepEqual(fs.readFileSync(path.join(manager._paths.files(),manager._internals.loadIndex().items[key].file)),model.blobs[0].bytes);
 }finally{s.closeAllConnections();await new Promise(r=>s.close(r));fs.rmSync(dir,{recursive:true,force:true})}
});
