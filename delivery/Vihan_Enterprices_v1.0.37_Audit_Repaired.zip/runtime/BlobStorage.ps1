# Loaded by both services. Call under the shared data-I/O mutex.
function Save-VihanBlob($Record,[IO.Stream]$Stream=$null,[long]$ExpectedLength=-1){
  $dbn=[string]$Record.db;$store=[string]$Record.store;$itemId=[string]$Record.id
  foreach($part in @($dbn,$store,$itemId)){if([string]::IsNullOrWhiteSpace($part) -or $part.Contains('|')){throw 'Invalid attachment identity'}}
  $key=Blob-Key $dbn $store $itemId
  $old=$db.Query('SELECT blob_file,blob_type FROM blob_meta WHERE blob_key='+(Q $key)+' LIMIT 1')
  $oldFile=if($old.Count){[string]$old[0]['blob_file']}else{''}
  $file=$oldFile;$type=if($old.Count){[string]$old[0]['blob_type']}else{''}
  $newFile=$null
  try{
    if($null -ne $Stream -or $Record.PSObject.Properties['blobBase64']){
      $file=(Hash-Key $key)+'_'+[guid]::NewGuid().ToString('N')+'.bin'
      $newFile=Join-Path $BlobDir $file;$temp=$newFile+'.tmp'
      try{
        if($null -ne $Stream){Save-StreamToFile $Stream $temp;if($ExpectedLength -ge 0 -and (Get-Item -LiteralPath $temp).Length -ne $ExpectedLength){throw 'Incomplete attachment upload'}}
        else{[IO.File]::WriteAllBytes($temp,[Convert]::FromBase64String([string]$Record.blobBase64))}
        Move-Item -LiteralPath $temp -Destination $newFile -ErrorAction Stop
      }finally{Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}
      $type=[string]$Record.blobType
    }
    $recordJson=$Record.record|ConvertTo-Json -Depth 100 -Compress
    $db.Exec('INSERT OR REPLACE INTO blob_meta(blob_key,db_name,store_name,item_id,record_json,blob_file,blob_type,updated_at) VALUES('+(Q $key)+','+(Q $dbn)+','+(Q $store)+','+(Q $itemId)+','+(Q $recordJson)+','+(Q $file)+','+(Q $type)+','+(Q ((Get-Date).ToString('o')))+');')
  }catch{if($newFile){Remove-Item -LiteralPath $newFile -Force -ErrorAction SilentlyContinue};throw}
  # Metadata commit succeeded; only now can the previously referenced file go.
  if($newFile -and $oldFile -and $oldFile -ne $file){Remove-Item -LiteralPath (Join-Path $BlobDir $oldFile) -Force -ErrorAction SilentlyContinue}
}
function Remove-VihanBlob($Record){
  $key=Blob-Key ([string]$Record.db) ([string]$Record.store) ([string]$Record.id)
  $rows=$db.Query('SELECT blob_file FROM blob_meta WHERE blob_key='+(Q $key)+' LIMIT 1')
  $db.Exec('DELETE FROM blob_meta WHERE blob_key='+(Q $key)+';')
  if($rows.Count -and $rows[0]['blob_file']){Remove-Item -LiteralPath (Join-Path $BlobDir ([string]$rows[0]['blob_file'])) -Force -ErrorAction SilentlyContinue}
}
