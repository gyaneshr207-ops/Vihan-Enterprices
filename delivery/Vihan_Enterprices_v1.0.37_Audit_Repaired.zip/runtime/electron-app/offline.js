'use strict';
/*
 * Vihan Enterprices - Offline Read-Only copy (v1.0.35)
 *
 * What this module does (Client PC only, never the Main PC):
 *   1. Once per day (8 PM, retry every 30 min until it succeeds, catch-up when the app
 *      is opened later) copies the Main PC data + attachments into a local folder.
 *      Only PCs allowed on the Main PC ("offline-clients.json") receive the data.
 *   2. When the Main PC cannot be reached, serves the ORIGINAL app pages from a small
 *      local server (127.0.0.1 only) that answers the same /api calls from the saved copy.
 *   3. Every write is refused. Nothing done offline is ever sent back to the Main PC.
 *
 * The module has no Electron dependency so it can be tested with plain Node.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

const SYNC_HOUR = 20;                       // 8 PM
const RETRY_MS = 30 * 60 * 1000;            // retry spacing after a failed/unfinished sync
const NOT_ALLOWED_RECHECK_MS = 2 * 60 * 1000; // how often a not-yet-allowed PC re-checks its permission
const JITTER_MAX_SEC = 600;                 // spread clients over 10 minutes after 8 PM
const MAX_BLOB_BYTES = 200 * 1024 * 1024;   // larger single attachments are skipped
const MAX_DATA_BYTES = 300 * 1024 * 1024;
const BLOB_PARALLEL = 2;
const PORT_FIRST = 17890, PORT_LAST = 17899;
const READ_ONLY_MSG = 'Offline Read-Only: Main PC band hai, isliye ye kaam abhi nahi ho sakta.';

// ---------- small helpers ----------
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function ensureDir(d) { fs.mkdirSync(d, { recursive: true }); }
function atomicWrite(file, text) {
  ensureDir(path.dirname(file));
  const tmp = file + '.tmp';
  const fd = fs.openSync(tmp, 'w');
  try { fs.writeSync(fd, text); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  fs.renameSync(tmp, file);
}
function readJsonFile(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')); } catch { return null; }
}
function blobKey(db, store, id) { return String(db) + '|' + String(store) + '|' + String(id); }
function blobFileName(key) { return crypto.createHash('sha256').update(key).digest('hex') + '.bin'; }

// ---------- schedule (pure functions, unit tested) ----------
function latestSlotStart(now) {
  const d = new Date(now);
  d.setHours(SYNC_HOUR, 0, 0, 0);
  if (d.getTime() > now) d.setDate(d.getDate() - 1);
  return d.getTime();
}
function jitterMs(hostname, slot) {
  const h = crypto.createHash('sha256').update(String(hostname) + '|' + slot).digest();
  return (h.readUInt32BE(0) % (JITTER_MAX_SEC + 1)) * 1000;
}
/*
 * Due when the newest completed sync is older than the most recent 8 PM.
 *  - first ever sync: due immediately
 *  - after 8 PM: due after a small per-PC delay; if it fails, retried every 30 minutes
 *  - PC was off at 8 PM: due as soon as the app opens and the Main PC is reachable
 *  - already synced since the last 8 PM: never due (so at most one full sync per day)
 */
function isSyncDue(now, state, hostname) {
  state = state || {};
  if (!state.lastSuccessAt) {
    // A PC that is not allowed yet only asks the Main PC "am I allowed now?" (tiny request) every 2 minutes,
    // so a newly switched-ON PC starts quickly. Real sync retries keep the 30 minute spacing.
    const wait = state.lastResult === 'not-allowed' ? NOT_ALLOWED_RECHECK_MS : RETRY_MS;
    if (state.lastAttemptAt && now - state.lastAttemptAt < wait) return { due: false, reason: 'retry-wait' };
    return { due: true, reason: 'first-sync' };
  }
  const slot = latestSlotStart(now);
  if (state.lastSuccessAt >= slot) return { due: false, reason: 'already-synced' };
  if (now < slot + jitterMs(hostname, slot)) return { due: false, reason: 'stagger-wait' };
  if (state.lastAttemptAt && state.lastAttemptAt > slot && now - state.lastAttemptAt < RETRY_MS) return { due: false, reason: 'retry-wait' };
  return { due: true, reason: 'daily' };
}

// ---------- HTTP helpers (client -> Main PC) ----------
function request(url, { token, method = 'GET', timeout = 60000 } = {}) {
  return new Promise((resolve, reject) => {
    let u; try { u = new URL(url); } catch (e) { return reject(e); }
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request(u, { method, timeout, headers: { 'X-Vihan-Token': String(token || ''), 'Cache-Control': 'no-store' } }, (res) => {
      const chunks = [];
      res.on('data', d => chunks.push(d));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('Request timeout')));
    req.on('error', reject);
    req.end();
  });
}
async function getJson(url, token, timeout) {
  const r = await request(url, { token, timeout });
  let data = null;
  try { data = JSON.parse(r.body.toString('utf8')); } catch {}
  if (r.status !== 200) { const e = new Error((data && data.error) || ('HTTP ' + r.status)); e.status = r.status; throw e; }
  return data;
}
function downloadToFile(url, token, dest, expectedSize) {
  return new Promise((resolve, reject) => {
    let u; try { u = new URL(url); } catch (e) { return reject(e); }
    const lib = u.protocol === 'https:' ? https : http;
    const tmp = dest + '.tmp';
    ensureDir(path.dirname(dest));
    const req = lib.request(u, { method: 'GET', timeout: 120000, headers: { 'X-Vihan-Token': String(token || ''), 'Cache-Control': 'no-store' } }, (res) => {
      if (res.statusCode !== 200) { res.resume(); const e = new Error('HTTP ' + res.statusCode); e.status = res.statusCode; return reject(e); }
      const out = fs.createWriteStream(tmp);
      let written = 0;
      res.on('data', d => { written += d.length; });
      res.pipe(out);
      out.on('finish', () => {
        const want = Number(res.headers['content-length'] || expectedSize || 0);
        if (want && written !== want) { try { fs.unlinkSync(tmp); } catch {} return reject(new Error('Incomplete download')); }
        try { fs.renameSync(tmp, dest); resolve(written); } catch (e) { reject(e); }
      });
      out.on('error', e => { try { fs.unlinkSync(tmp); } catch {} reject(e); });
      res.on('error', e => { try { out.destroy(); fs.unlinkSync(tmp); } catch {} reject(e); });
    });
    req.on('timeout', () => req.destroy(new Error('Download timeout')));
    req.on('error', e => { try { fs.unlinkSync(tmp); } catch {} reject(e); });
    req.end();
  });
}

// ---------- the manager ----------
function createOfflineManager(opts) {
  const hostname = opts.hostname;
  const log = opts.log || (() => {});
  const dir = () => opts.dataDir();
  const P = {
    data: () => path.join(dir(), 'offline-data.json'),
    state: () => path.join(dir(), 'offline-state.json'),
    index: () => path.join(dir(), 'blobs', 'index.json'),
    files: () => path.join(dir(), 'blobs', 'files'),
    log: () => path.join(dir(), 'offline-sync.log')
  };

  function fileLog(msg) {
    try {
      const line = new Date().toISOString() + '  ' + msg + '\n';
      ensureDir(dir());
      const f = P.log();
      try { if (fs.statSync(f).size > 400 * 1024) fs.writeFileSync(f, fs.readFileSync(f, 'utf8').slice(-200 * 1024)); } catch {}
      fs.appendFileSync(f, line);
    } catch {}
    try { log(msg); } catch {}
  }

  // --- state ---
  function readState() { return readJsonFile(P.state()) || {}; }
  function patchState(p) { const s = Object.assign(readState(), p); try { atomicWrite(P.state(), JSON.stringify(s, null, 1)); } catch {} return s; }

  // --- data copy ---
  let dataCache = null, dataStamp = '';
  function loadData() {
    try {
      const st = fs.statSync(P.data());
      const stamp = st.mtimeMs + ':' + st.size;
      if (dataCache && stamp === dataStamp) return dataCache;
      const d = JSON.parse(fs.readFileSync(P.data(), 'utf8'));
      if (!d || typeof d.items !== 'object' || Array.isArray(d.items)) return null;
      dataCache = d; dataStamp = stamp; return d;
    } catch { return null; }
  }
  function dataKeyCount(d) { return d && d.items ? Object.keys(d.items).length : 0; }
  function hasUsableCache() { return dataKeyCount(loadData()) > 0; }

  // --- attachment copy ---
  let indexCache = null, indexStamp = '';
  function loadIndex() {
    try {
      const st = fs.statSync(P.index());
      const stamp = st.mtimeMs + ':' + st.size;
      if (indexCache && stamp === indexStamp) return indexCache;
      const d = JSON.parse(fs.readFileSync(P.index(), 'utf8'));
      if (!d || typeof d.items !== 'object') return { items: {} };
      indexCache = d; indexStamp = stamp; return d;
    } catch { return { items: {} }; }
  }
  function saveIndex(idx) { atomicWrite(P.index(), JSON.stringify(idx)); indexCache = null; indexStamp = ''; }

  function wipeCache(reason) {
    fileLog('Offline copy deleted: ' + reason);
    for (const f of [P.data(), P.index()]) { try { fs.unlinkSync(f); } catch {} }
    try { fs.rmSync(P.files(), { recursive: true, force: true }); } catch {}
    dataCache = null; dataStamp = ''; indexCache = null; indexStamp = '';
    try { if (opts.onWipe) opts.onWipe(); } catch {}
  }

  function mergeData(existing, resp) {
    // returns {items, revision} or throws
    if (!resp || typeof resp !== 'object') throw new Error('Invalid data response');
    const revision = Number(resp.revision) || 0;
    let items;
    if (resp.full) {
      items = {};
      for (const [k, rec] of Object.entries(resp.items || {})) {
        if (!rec || rec.deleted) continue;
        items[k] = { value: String(rec.value == null ? '' : rec.value), keyRev: Number(rec.keyRev) || 0 };
      }
      const oldCount = dataKeyCount(existing), newCount = Object.keys(items).length;
      // Never replace a useful copy with an empty / almost empty Main response.
      if (oldCount > 0 && (newCount === 0 || (oldCount >= 20 && newCount < oldCount * 0.2))) {
        throw new Error('Main PC ne bahut kam data bheja (' + newCount + ' vs ' + oldCount + '); purani offline copy rakhi gayi');
      }
    } else {
      items = Object.assign({}, existing ? existing.items : {});
      for (const ch of (resp.changes || [])) {
        if (!ch || !ch.key) continue;
        if (ch.deleted) delete items[ch.key];
        else items[ch.key] = { value: String(ch.value == null ? '' : ch.value), keyRev: Number(ch.keyRev) || 0 };
      }
    }
    return { items, revision };
  }

  async function syncData(base, token) {
    const existing = loadData();
    let since = existing ? Number(existing.revision) || 0 : 0;
    const q = (n) => base + '/api/offline/data?pc=' + encodeURIComponent(hostname) + '&since=' + n;
    let resp = await getJson(q(since), token, 120000);
    if (since > 0 && Number(resp.revision || 0) < since) { since = 0; resp = await getJson(q(0), token, 120000); } // Main was restored/replaced -> full copy
    if (since === 0 && !resp.full) throw new Error('Main PC ne poora data nahi bheja');
    const merged = mergeData(existing, resp);
    const payload = JSON.stringify({ schemaVersion: 3, savedAt: new Date().toISOString(), source: base, revision: merged.revision, items: merged.items });
    if (Buffer.byteLength(payload) > MAX_DATA_BYTES) throw new Error('Data copy bahut badi hai; purani copy rakhi gayi');
    atomicWrite(P.data(), payload);
    dataCache = null; dataStamp = '';
    return { keys: Object.keys(merged.items).length, revision: merged.revision, full: !!resp.full };
  }

  async function syncBlobs(base, fileBase, token) {
    const m = await getJson(base + '/api/offline/manifest?pc=' + encodeURIComponent(hostname), token, 180000);
    const list = Array.isArray(m.items) ? m.items : [];
    const idx = loadIndex();
    const items = idx.items || {};
    const seen = new Set();
    const todo = [];
    for (const it of list) {
      const key = blobKey(it.db, it.store, it.id);
      seen.add(key);
      let record = null;
      try { record = it.recordJson ? JSON.parse(it.recordJson) : (it.record || null); } catch {}
      const old = items[key];
      const fileOk = old && old.file && fs.existsSync(path.join(P.files(), old.file));
      const same = old && old.updatedAt === it.updatedAt && old.size === Number(it.size || 0) && (!it.hasBlob || fileOk);
      if (same) { old.record = record; continue; }
      const entry = { db: String(it.db), store: String(it.store), id: String(it.id), updatedAt: String(it.updatedAt || ''), blobType: String(it.blobType || ''), size: Number(it.size || 0), hasBlob: false, file: '', record, skipped: false };
      if (it.hasBlob && entry.size > MAX_BLOB_BYTES) { entry.skipped = true; items[key] = entry; continue; }
      items[key] = entry;
      if (it.hasBlob) todo.push({ key, entry, previous: old });
    }
    let done = 0, failed = 0, missing = 0, bytes = 0;
    let next = 0;
    async function worker() {
      while (next < todo.length) {
        const job = todo[next++];
        const e = job.entry;
        const name = blobFileName(job.key);
        const url = fileBase + '/api/offline/blob?pc=' + encodeURIComponent(hostname) + '&db=' + encodeURIComponent(e.db) + '&store=' + encodeURIComponent(e.store) + '&id=' + encodeURIComponent(e.id);
        try {
          bytes += await downloadToFile(url, token, path.join(P.files(), name), e.size);
          e.file = name; e.hasBlob = true; done++;
        } catch (err) {
          if (err && err.status === 404) { missing++; e.hasBlob = false; fileLog('Attachment Main PC par nahi mila: ' + job.key); }
          else { failed++; e.updatedAt = ''; if(job.previous&&job.previous.file&&fs.existsSync(path.join(P.files(),job.previous.file)))items[job.key]={...job.previous,updatedAt:''}; fileLog('Attachment download fail: ' + job.key + ' - ' + (err && err.message)); }
        }
        if ((done + failed + missing) % 20 === 0) { try { saveIndex({ items }); } catch {} }
        await sleep(30); // keep the Main PC light
      }
    }
    await Promise.all(Array.from({ length: BLOB_PARALLEL }, worker));
    // remove attachments that no longer exist on Main (but never wipe everything because of an empty answer)
    if (!(list.length === 0 && Object.keys(items).length >= 5)) {
      for (const key of Object.keys(items)) if (!seen.has(key)) { const f = items[key].file; delete items[key]; if (f) { try { fs.unlinkSync(path.join(P.files(), f)); } catch {} } }
    } else fileLog('Manifest khali aaya; purane attachments rakhe gaye');
    saveIndex({ items });
    try {
      const keep = new Set(Object.values(items).map(x => x.file).filter(Boolean));
      for (const f of fs.readdirSync(P.files())) if (!keep.has(f)) { try { fs.unlinkSync(path.join(P.files(), f)); } catch {} }
    } catch {}
    return { total: list.length, downloaded: done, failed, missing, skipped: Object.values(items).filter(x => x.skipped).length, bytes };
  }

  let syncing = false;
  async function syncOnce({ base, fileBase, token }) {
    if (syncing) return { skipped: 'busy' };
    syncing = true;
    const started = Date.now();
    patchState({ lastAttemptAt: started });
    try {
      const perm = await getJson(base + '/api/offline/permission?pc=' + encodeURIComponent(hostname), token, 15000);
      if (!perm || perm.ok !== true) throw new Error('Permission check fail');
      if (!perm.allowed) {
        if (hasUsableCache() || fs.existsSync(P.index())) wipeCache('Main PC ne is PC ko offline copy ki permission nahi di');
        patchState({ allowed: false, lastError: '', lastResult: 'not-allowed' });
        return { skipped: 'not-allowed' };
      }
      const d = await syncData(base, token);
      const b = await syncBlobs(base, fileBase, token);
      const complete = b.failed === 0;
      const patch = { allowed: true, lastDataAt: Date.now(), dataRevision: d.revision, keys: d.keys, blobs: b, lastError: complete ? '' : (b.failed + ' attachment download baaki — dobara try hoga'), lastResult: complete ? 'ok' : 'partial' };
      if (complete) patch.lastSuccessAt = Date.now();
      patchState(patch);
      fileLog('Sync ' + (complete ? 'complete' : 'partial') + ': ' + d.keys + ' keys, rev ' + d.revision + ', attachments new ' + b.downloaded + '/' + b.total + ', failed ' + b.failed + ', ' + Math.round((Date.now() - started) / 1000) + 's');
      return { ok: complete, data: d, blobs: b };
    } catch (e) {
      patchState({ lastError: String(e && e.message || e), lastResult: 'error' });
      fileLog('Sync error: ' + (e && e.message));
      return { ok: false, error: String(e && e.message || e) };
    } finally { syncing = false; }
  }

  // --- scheduler ---
  let timer = null;
  function startScheduler(getContext) {
    stopScheduler();
    const t0 = Date.now();
    const startDelay = jitterMs(hostname, 'start' + t0);   // catch-up after the app opens: each PC waits 0-10 min so the Main PC is not hit by all PCs at once
    const tick = async () => {
      try {
        const ctx = getContext();            // {base,fileBase,token} or null when Main PC is not reachable / this is the Main PC
        if (!ctx || syncing) return;
        const due = isSyncDue(Date.now(), readState(), hostname);
        if (!due.due) return;
        if (due.reason === 'daily' && Date.now() < t0 + startDelay) return;
        fileLog('Sync shuru (' + due.reason + ')');
        await syncOnce(ctx);
      } catch (e) { fileLog('Scheduler error: ' + (e && e.message)); }
    };
    timer = setInterval(tick, 60 * 1000);
    if (timer.unref) timer.unref();
    setTimeout(tick, 5000);
    return tick;
  }
  function stopScheduler() { if (timer) { clearInterval(timer); timer = null; } }

  // --- local read-only server ---
  let server = null, serverInfo = null, authToken = '';
  const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };
  function sendJson(res, obj, status = 200) {
    const b = Buffer.from(JSON.stringify(obj));
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': b.length, 'Cache-Control': 'no-store' });
    res.end(b);
  }
  function sendText(res, text, status = 200, type = 'text/plain; charset=utf-8') {
    const b = Buffer.from(text); res.writeHead(status, { 'Content-Type': type, 'Content-Length': b.length, 'Cache-Control': 'no-store' }); res.end(b);
  }
  function cookieOk(req) {
    const m = /(?:^|;\s*)VE_OFFLINE_AUTH=([^;]+)/.exec(req.headers.cookie || '');
    return !!(m && authToken && m[1] === authToken);
  }
  function serveStatic(res, rel) {
    const root = path.resolve(opts.appDir());
    const full = path.resolve(root, rel);
    if (full !== root && !full.startsWith(root + path.sep)) return sendText(res, 'Not Found', 404);
    let buf;
    try { buf = fs.readFileSync(full); } catch { return sendText(res, 'Not Found', 404); }
    if (path.basename(full).toLowerCase() === 'vihan-sync.js') {
      const d = loadData();
      const info = { savedAt: d && d.savedAt || '', revision: d && d.revision || 0 };
      buf = Buffer.concat([Buffer.from('window.__VIHAN_OFFLINE__=true;window.__VIHAN_OFFLINE_INFO__=' + JSON.stringify(info) + ';\n'), buf]);
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream', 'Content-Length': buf.length, 'Cache-Control': 'no-store' });
    res.end(buf);
  }
  function blobRecord(db, store, id) { return loadIndex().items[blobKey(db, store, id)] || null; }

  function handle(req, res) {
    let u; try { u = new URL(req.url, 'http://127.0.0.1'); } catch { return sendText(res, 'Bad request', 400); }
    const p = u.pathname, method = req.method.toUpperCase();
    if (p === '/health') return sendJson(res, { ok: true, product: 'Vihan Enterprices', offline: true });
    if (p === '/connect') {
      if (u.searchParams.get('token') !== authToken) return sendText(res, 'Invalid service file.', 403);
      res.writeHead(302, { 'Set-Cookie': 'VE_OFFLINE_AUTH=' + authToken + '; Path=/; HttpOnly; SameSite=Strict', Location: '/', 'Cache-Control': 'no-store' });
      return res.end();
    }
    if (!cookieOk(req)) return sendText(res, 'Offline service authorization required.', 401);
    if (p === '/' || p === '/index.html') return serveStatic(res, 'bootstrap.html');
    if (p.startsWith('/app/')) return serveStatic(res, p.slice(5));
    if (p.startsWith('/api/')) {
      if (method !== 'GET') return sendJson(res, { error: READ_ONLY_MSG, readOnly: true }, 403);
      const d = loadData();
      if (p === '/api/status') return sendJson(res, { ok: true, offline: true, readOnly: true, product: 'Vihan Enterprices', serverName: 'OFFLINE COPY', serverIp: '', savedAt: d ? d.savedAt : '', revision: d ? d.revision : 0, backupPath: '-' });
      if (!d) return sendJson(res, { error: 'Offline copy available nahi hai' }, 503);
      if (p === '/api/snapshot' || p === '/api/storage/changes') return sendJson(res, { full: true, revision: d.revision, items: d.items, keyRevs: {} });
      const db = u.searchParams.get('db') || '', store = u.searchParams.get('store') || '', id = u.searchParams.get('id') || '';
      if (p === '/api/blob/list') {
        const rows = Object.values(loadIndex().items).filter(x => x.db === db && x.store === store && x.record).sort((a, b) => String(a.updatedAt).localeCompare(String(b.updatedAt)));
        return sendJson(res, { items: rows.map(x => x.record) });
      }
      const rec = blobRecord(db, store, id);
      if (p === '/api/blob/meta') {
        if (!rec) return sendJson(res, { error: 'Not found' }, 404);
        return sendJson(res, { record: rec.record, hasBlob: !!(rec.file && fs.existsSync(path.join(P.files(), rec.file))), blobType: rec.blobType });
      }
      if (p === '/api/blob/file' || p === '/api/blob/get') {
        if (!rec) return sendJson(res, { error: 'Not found' }, 404);
        const fp = rec.file ? path.join(P.files(), rec.file) : '';
        if (!fp || !fs.existsSync(fp)) return sendJson(res, { error: rec.skipped ? 'File bahut badi hone ki wajah se offline copy me nahi hai' : 'No file' }, 404);
        if (p === '/api/blob/get') return sendJson(res, { record: rec.record, blobBase64: fs.readFileSync(fp).toString('base64'), blobType: rec.blobType });
        const size = fs.statSync(fp).size;
        res.writeHead(200, { 'Content-Type': rec.blobType || 'application/octet-stream', 'Content-Length': size, 'Cache-Control': 'no-store' });
        return fs.createReadStream(fp).pipe(res);
      }
      return sendJson(res, { error: 'Not found' }, 404);
    }
    return sendText(res, 'Not Found', 404);
  }

  function startServer() {
    if (serverInfo) return Promise.resolve(serverInfo);
    if (!hasUsableCache()) return Promise.resolve(null);
    authToken = crypto.randomBytes(24).toString('hex');
    return new Promise((resolve) => {
      let port = PORT_FIRST;
      const tryListen = () => {
        const s = http.createServer(handle);
        s.on('error', () => { try { s.close(); } catch {} if (++port <= PORT_LAST) tryListen(); else resolve(null); });
        s.listen(port, '127.0.0.1', () => {
          server = s;
          serverInfo = { port, origin: 'http://127.0.0.1:' + port, url: 'http://127.0.0.1:' + port + '/connect?token=' + authToken };
          fileLog('Offline server chalu: ' + serverInfo.origin);
          resolve(serverInfo);
        });
      };
      tryListen();
    });
  }
  function stopServer() { if (server) { try { server.close(); } catch {} server = null; serverInfo = null; } }

  function cleanupLegacy(legacyFiles) { for (const f of legacyFiles || []) { try { if (fs.existsSync(f)) { fs.unlinkSync(f); fileLog('Purani snapshot file hata di: ' + f); } } catch {} } }

  function getStatus() {
    const d = loadData(), s = readState();
    return { hasCache: dataKeyCount(d) > 0, savedAt: d ? d.savedAt : '', keys: dataKeyCount(d), allowed: s.allowed, lastError: s.lastError || '', lastSuccessAt: s.lastSuccessAt || 0 };
  }

  return { startServer, stopServer, startScheduler, stopScheduler, syncOnce, hasUsableCache, getStatus, cleanupLegacy, wipeCache, _paths: P, _internals: { readState, patchState, loadData, loadIndex } };
}

module.exports = { createOfflineManager, isSyncDue, latestSlotStart, jitterMs, SYNC_HOUR, RETRY_MS, READ_ONLY_MSG };
