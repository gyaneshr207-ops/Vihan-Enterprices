param([switch]$MakeMain,[switch]$ClientOnly)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
$Product='Vihan Enterprices';$Version='1.0.37';$Port=17867;$FilePort=17868
$ClientDir=Join-Path $env:APPDATA $Product
New-Item -ItemType Directory -Force -Path $ClientDir|Out-Null
$Conn=Join-Path $ClientDir 'connection.json'
$Diag=Join-Path $PSScriptRoot 'ClientDiagnostic.ps1'
function Save-Client($o){$o|ConvertTo-Json -Depth 10|Set-Content -Encoding UTF8 $Conn}
function Is-Admin(){return (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
function Pick-IPv4(){
  try{
    $routes=Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction Stop | Where-Object{$_.NextHop -and $_.NextHop -ne '0.0.0.0'}
    $best=$routes | ForEach-Object{
      $if=Get-NetIPInterface -InterfaceIndex $_.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue
      [pscustomobject]@{Route=$_;Score=([int]$_.RouteMetric+[int]($if.InterfaceMetric))}
    } | Sort-Object Score | Select-Object -First 1
    if($best){
      $ip=Get-NetIPAddress -InterfaceIndex $best.Route.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object{$_.IPAddress -notmatch '^(127\.|169\.254\.)'} | Select-Object -First 1
      if($ip){return $ip.IPAddress}
    }
  }catch{}
  try{
    $x=Get-NetIPAddress -AddressFamily IPv4|Where-Object{$_.IPAddress -notmatch '^(127\.|169\.254\.)' -and $_.PrefixOrigin -ne 'WellKnown'}|Select-Object -First 1
    if($x){return $x.IPAddress}
  }catch{}
  try{return ([Net.Dns]::GetHostAddresses($env:COMPUTERNAME)|Where-Object{$_.AddressFamily -eq 'InterNetwork' -and $_.IPAddressToString -notmatch '^(127\.|169\.254\.)'}|Select-Object -First 1).IPAddressToString}catch{return '127.0.0.1'}
}
function Test-Service($c){
  $urls=@();if($c.serverIpUrl){$urls+=[string]$c.serverIpUrl};if($c.serverUrl -and $c.serverUrl -ne $c.serverIpUrl){$urls+=[string]$c.serverUrl}
  foreach($u in $urls){
    try{$r=Invoke-WebRequest -UseBasicParsing -Uri ($u.TrimEnd('/')+'/health') -TimeoutSec 4;if($r.StatusCode -eq 200){$health=$r.Content|ConvertFrom-Json;if($health.product -eq $Product -and !$health.offline -and $health.service -ne 'files'){return $u.TrimEnd('/')}}}catch{}
  }
  return $null
}
function Client-Setup(){
  $d=New-Object System.Windows.Forms.OpenFileDialog
  $d.Title='Vihan Enterprices Main Service File Select Karein'
  $d.Filter='Vihan Service File (*.veservice)|*.veservice|JSON (*.json)|*.json|All files (*.*)|*.*'
  $d.CheckFileExists=$true
  if($d.ShowDialog() -ne 'OK'){[System.Windows.Forms.MessageBox]::Show('Client setup cancel kiya gaya. App install ho chuki hai; setup baad me Start Menu se khol sakte hain.',$Product,'OK','Information')|Out-Null;return 0}
  try{
    $c=Get-Content $d.FileName -Raw|ConvertFrom-Json
    if($c.product -ne $Product -or [string]::IsNullOrWhiteSpace([string]$c.token) -or ([string]::IsNullOrWhiteSpace([string]$c.serverUrl) -and [string]::IsNullOrWhiteSpace([string]$c.serverIpUrl))){throw 'Service file valid nahi hai'}
    Save-Client $c
    $base=Test-Service $c
    if($base){
      [System.Windows.Forms.MessageBox]::Show("CLIENT PC READY.`n`nService file save ho gayi aur Main Service connect ho rahi hai.`nServer: $base`n`nAb Desktop ka 'Vihan Enterprices' icon open karein.",$Product,'OK','Information')|Out-Null
      return 0
    }
    $ans=[System.Windows.Forms.MessageBox]::Show("App CLIENT PC par install ho gayi aur service file save ho gayi.`n`nLekin abhi Main Service connect nahi ho rahi.`n`nCheck karein:`n1. Main PC ON hai`n2. Same LAN/Wi-Fi hai`n3. Main PC service running hai`n4. Windows Firewall me TCP $Port allowed hai`n`nDiagnostic report abhi chalayein?",$Product,'YesNo','Warning')
    if($ans -eq 'Yes' -and (Test-Path $Diag)){& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Diag}
    return 0
  }catch{
    [System.Windows.Forms.MessageBox]::Show("Service file import nahi hui.`n`n$($_.Exception.Message)",$Product,'OK','Error')|Out-Null
    return 2
  }
}
function Main-Setup(){
  if(!(Is-Admin)){
    $args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'),'-MakeMain')
    $p=Start-Process powershell.exe -Verb RunAs -ArgumentList $args -PassThru -Wait
    return $p.ExitCode
  }
  $Base=Join-Path $env:ProgramData $Product
  $dBase='D:\Vihan Enterprices'
  $dataDir=Join-Path $dBase 'Data'
  $fallbackBackup=Join-Path $Base 'Backups'
  $preferredBackup=Join-Path $dBase 'Backups'
  if(!(Test-Path 'D:\')){throw 'Main PC me D: drive available nahi hai. v1.0.33 central SQLite data D:\Vihan Enterprices\Data me rakhega.'}
  New-Item -ItemType Directory -Force -Path $Base,$dataDir,$preferredBackup,$fallbackBackup|Out-Null
  $backupDir=$preferredBackup
  $serverJson=Join-Path $Base 'server.json'
  if(Test-Path $serverJson){
    try{$old=Get-Content $serverJson -Raw|ConvertFrom-Json}catch{throw 'Existing server.json is invalid. Repair configuration from a verified backup; refusing to replace connection identity.'}
  }
  if($old -and $old.token){$token=[string]$old.token}else{
    $rng=New-Object Security.Cryptography.RNGCryptoServiceProvider;$bytes=New-Object byte[] 32;$rng.GetBytes($bytes);$rng.Dispose();$token=[Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
  }
  if($old){
    . (Join-Path $PSScriptRoot 'StoragePaths.ps1')
    $paths=Get-VihanStoragePaths $old;$dataDir=$paths.Data;$backupDir=$paths.Backup
  }
  $initialize=if($old){$old.initializeDatabase -eq $true}else{$true}
  if($initialize){
    foreach($folder in @($dataDir,(Join-Path $Base 'Data'))){
      foreach($name in @('VihanEnterprices.db','storage.json','storage.wal','blobmeta.json')){
        if(Test-Path (Join-Path $folder $name)){throw 'Existing data found without configuration. Recover server.json first; no automatic migration or database initialization.'}
      }
    }
  }
  $ip=Pick-IPv4;$hostName=$env:COMPUTERNAME;$serverUrl="http://${hostName}:$Port";$serverIpUrl="http://${ip}:$Port"
  $cfg=[pscustomobject]@{product=$Product;appVersion=$Version;serverName=$hostName;serverIp=$ip;port=$Port;filePort=$FilePort;token=$token;dataDir=$dataDir;backupDir=$backupDir;initializeDatabase=$initialize;createdAt=(Get-Date).ToString('o')}
  $cfg|ConvertTo-Json|Set-Content -Encoding UTF8 $serverJson
  $client=[pscustomobject]@{product=$Product;appVersion=$Version;serverUrl=$serverUrl;serverIpUrl=$serverIpUrl;serverName=$hostName;serverIp=$ip;port=$Port;filePort=$FilePort;token=$token;dataDir=$dataDir;backupDir=$backupDir;createdAt=(Get-Date).ToString('o')}
  Save-Client $client

  & netsh http delete urlacl url="http://+:$Port/" 2>$null | Out-Null
  # v1.0.27: Main Service SYSTEM account ke under boot se chalegi.
  & netsh http add urlacl url="http://+:$Port/" sddl="D:(A;;GX;;;SY)(A;;GX;;;BU)" | Out-Null
  & netsh http delete urlacl url="http://+:$FilePort/" 2>$null | Out-Null
  & netsh http add urlacl url="http://+:$FilePort/" sddl="D:(A;;GX;;;SY)(A;;GX;;;BU)" | Out-Null
  try{
    Get-NetFirewallRule -DisplayName 'Vihan Enterprices Main Service' -ErrorAction SilentlyContinue|Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName 'Vihan Enterprices Main Service' -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -Profile Any|Out-Null
    Get-NetFirewallRule -DisplayName 'Vihan Enterprices File Service' -ErrorAction SilentlyContinue|Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName 'Vihan Enterprices File Service' -Direction Inbound -Action Allow -Protocol TCP -LocalPort $FilePort -Profile Any|Out-Null
  }catch{}

  # V1.0.27: Main Service ko SYSTEM boot task ke roop me start karein; lock/login par depend nahi.
  $repair=Join-Path $PSScriptRoot 'RepairMainService.ps1'
  if(Test-Path $repair){
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $repair -NoPrompt
    if($LASTEXITCODE -ne 0){throw ('Main/File service repair failed with exit code '+$LASTEXITCODE)}
  }else{
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $PSScriptRoot 'MainService.ps1')+'"'))
  }

  $serviceFile=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Vihan_Enterprices_Main_Service.veservice'
  $client|ConvertTo-Json|Set-Content -Encoding UTF8 $serviceFile
  $ok=$null
  for($i=0;$i -lt 12;$i++){Start-Sleep -Milliseconds 500;$ok=Test-Service $client;if($ok){break}}
  if($ok){
    [System.Windows.Forms.MessageBox]::Show("MAIN PC READY.`n`nMain Service chal rahi hai.`nIP: $ip`nMain Port: $Port`nFile Port: $FilePort`n`nDesktop par service file ban gayi:`nVihan_Enterprices_Main_Service.veservice`n`nCentral Data:`n$dataDir`n`nMain Backup Location:`n$backupDir`n`nIsi service file ko Client PCs par import karein.",$Product,'OK','Information')|Out-Null
    return 0
  }
  $err=Join-Path $Base 'service_error.txt'
  [System.Windows.Forms.MessageBox]::Show("Main PC setup files ban gaye, lekin service start verify nahi hui.`n`nIP: $ip  Port: $Port`n`nError file (agar bani ho):`n$err",$Product,'OK','Warning')|Out-Null
  return 3
}

if($MakeMain){exit (Main-Setup)}
if($ClientOnly){exit (Client-Setup)}
$r=[System.Windows.Forms.MessageBox]::Show("Vihan Enterprices first setup`n`nYES = MAIN PC`nNO = CLIENT PC`nCANCEL = Baad me setup",$Product,'YesNoCancel','Question')
if($r -eq 'Yes'){exit (Main-Setup)}
if($r -eq 'No'){exit (Client-Setup)}
exit 0
