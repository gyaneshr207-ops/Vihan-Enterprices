param([switch]$NoPrompt)
$ErrorActionPreference='Stop'
$Product='Vihan Enterprices';$Port=17867;$FilePort=17868
$Base=Join-Path $env:ProgramData $Product
$ServerJson=Join-Path $Base 'server.json'
$Log=Join-Path $Base 'service_repair.log'
$TaskName='Vihan Enterprices Main Service';$FileTaskName='Vihan Enterprices File Service'
function Log([string]$m){try{New-Item -ItemType Directory -Force -Path $Base|Out-Null;Add-Content -Path $Log -Encoding UTF8 -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+'  '+$m)}catch{}}
function Is-Admin(){return (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
function Test-Local([int]$p){try{$r=Invoke-WebRequest -UseBasicParsing -Uri ("http://127.0.0.1:$p/health") -TimeoutSec 2;return $r.StatusCode -eq 200}catch{return $false}}

if(!(Test-Path $ServerJson)){Log 'server.json nahi mila; ye Client PC hai. Repair skip.';exit 0}
try{$cfg=Get-Content $ServerJson -Raw|ConvertFrom-Json;if($cfg.port){$Port=[int]$cfg.port};if($cfg.filePort){$FilePort=[int]$cfg.filePort}else{$FilePort=$Port+1}}catch{$FilePort=$Port+1}

if(!(Is-Admin)){
  try{
    $args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'),'-NoPrompt')
    $p=Start-Process powershell.exe -Verb RunAs -ArgumentList $args -PassThru -Wait
    exit $p.ExitCode
  }catch{Log ('Elevation failed: '+$_.Exception.Message);exit 5}
}

try{
  if(!(Test-Path 'D:\')){throw 'Main PC me D: drive available nahi hai. Central data D:\Vihan Enterprices\Data me configured hai.'}
  . (Join-Path $PSScriptRoot 'StoragePaths.ps1')
  $fresh=Get-Content $ServerJson -Raw|ConvertFrom-Json
  $paths=Get-VihanStoragePaths $fresh
  $dataDir=$paths.Data;$backupDir=$paths.Backup
  # Repair must not relocate data or overwrite the operator's configured paths.
  [void](Assert-VihanDatabaseStart $fresh $paths.Database (Join-Path $Base 'Data'))
  New-Item -ItemType Directory -Force -Path $backupDir|Out-Null
  Log ('Configured central database retained: '+$paths.Database)
  $script=Join-Path $PSScriptRoot 'MainService.ps1'
  if(!(Test-Path $script)){throw "MainService.ps1 nahi mila: $script"}
  $fileScript=Join-Path $PSScriptRoot 'FileService.ps1'
  if(!(Test-Path $fileScript)){throw "FileService.ps1 nahi mila: $fileScript"}

  # v1.0.27: service SYSTEM account ke under chalegi. Isliye user login/lock par depend nahi rahegi.
  & netsh http delete urlacl url="http://+:$Port/" 2>$null | Out-Null
  & netsh http add urlacl url="http://+:$Port/" sddl="D:(A;;GX;;;SY)(A;;GX;;;BU)" | Out-Null
  & netsh http delete urlacl url="http://+:$FilePort/" 2>$null | Out-Null
  & netsh http add urlacl url="http://+:$FilePort/" sddl="D:(A;;GX;;;SY)(A;;GX;;;BU)" | Out-Null

  try{
    Get-NetFirewallRule -DisplayName 'Vihan Enterprices Main Service' -ErrorAction SilentlyContinue|Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName 'Vihan Enterprices Main Service' -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -Profile Any|Out-Null
    Get-NetFirewallRule -DisplayName 'Vihan Enterprices File Service' -ErrorAction SilentlyContinue|Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName 'Vihan Enterprices File Service' -Direction Inbound -Action Allow -Protocol TCP -LocalPort $FilePort -Profile Any|Out-Null
  }catch{Log ('Firewall warning: '+$_.Exception.Message)}

  foreach($candidate in @(17867,18080,28080,8000,17868,18081,28081,8001)){
    & netsh http add urlacl url="http://+:$candidate/" sddl="D:(A;;GX;;;SY)(A;;GX;;;BU)" 2>$null | Out-Null
  }
  try{New-NetFirewallRule -DisplayName 'Vihan Enterprices Dynamic Port Fallback' -Direction Inbound -Action Allow -Protocol TCP -LocalPort @(17867,18080,28080,8000,17868,18081,28081,8001) -Profile Private -ErrorAction SilentlyContinue|Out-Null}catch{}

  # Old per-user Startup shortcut hata dein; ab real server task SYSTEM par boot se chalega.
  try{
    $startup=[Environment]::GetFolderPath('Startup')
    $oldLnk=Join-Path $startup 'Vihan Enterprices Main Service.lnk'
    Remove-Item $oldLnk -Force -ErrorAction SilentlyContinue
  }catch{}

  # Main PC ko server mode me AC power par sleep/hibernate se bachayein.
  # Screen lock/monitor off allowed hai; sirf system sleep nahi karega.
  try{& powercfg.exe /change standby-timeout-ac 0 | Out-Null; Log 'AC sleep disabled for Main PC server mode.'}catch{Log ('Power standby warning: '+$_.Exception.Message)}
  try{& powercfg.exe /change hibernate-timeout-ac 0 | Out-Null; Log 'AC hibernate timeout disabled for Main PC server mode.'}catch{Log ('Power hibernate warning: '+$_.Exception.Message)}

  # Update/migration ke dauran Task Scheduler purani service ko dobara auto-restart na kare.
  try{Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue;Stop-ScheduledTask -TaskName $FileTaskName -ErrorAction SilentlyContinue;Start-Sleep -Milliseconds 500}catch{}

  Stop-VihanTrackedService (Join-Path $Base 'service.pid') $script
  Stop-VihanTrackedService (Join-Path $Base 'file_service.pid') $fileScript

  # Boot-time SYSTEM task: Windows lock screen, sign-out, ya restart ke baad login se pehle bhi chalegi.
  try{
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    $psExe="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $action=New-ScheduledTaskAction -Execute $psExe -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$script+'"') -WorkingDirectory $PSScriptRoot
    $trigger=New-ScheduledTaskTrigger -AtStartup
    $principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -RestartCount 99 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -WakeToRun
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Vihan Enterprices central Main Service. Runs at Windows startup even when no user is logged in or PC is locked.' -Force | Out-Null
    Stop-ScheduledTask -TaskName $FileTaskName -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName $FileTaskName -Confirm:$false -ErrorAction SilentlyContinue
    $fileAction=New-ScheduledTaskAction -Execute $psExe -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$fileScript+'" -Port '+$FilePort) -WorkingDirectory $PSScriptRoot
    Register-ScheduledTask -TaskName $FileTaskName -Action $fileAction -Trigger $trigger -Principal $principal -Settings $settings -Description 'Vihan Enterprices dedicated file/upload/backup service. Keeps the main data service responsive.' -Force | Out-Null
    Log 'SYSTEM boot Scheduled Tasks ensured for Main + File services.'
  }catch{throw ('SYSTEM Scheduled Task create nahi hui: '+$_.Exception.Message)}

  # Abhi isi waqt service start karein; restart ka wait nahi.
  try{Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop;Start-ScheduledTask -TaskName $FileTaskName -ErrorAction Stop}catch{throw ('Main/File Service task start nahi hui: '+$_.Exception.Message)}

  $ok=$false
  for($i=0;$i -lt 24;$i++){Start-Sleep -Milliseconds 500;if((Test-Local $Port) -and (Test-Local $FilePort)){$ok=$true;break}}
  if(!$ok){
    $err=Join-Path $Base 'service_error.txt'
    Log "Service verify failed. Error file: $err"
    if(!$NoPrompt){Add-Type -AssemblyName System.Windows.Forms;[System.Windows.Forms.MessageBox]::Show("Main Service start verify nahi hui.`n`nError file:`n$err",$Product,'OK','Warning')|Out-Null}
    exit 3
  }

  try{
    $task=Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    $info=Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue
    $status=[pscustomobject]@{version='1.0.37';mode='SYSTEM_AT_STARTUP_CENTRAL_AUTO_UPDATE_ANTI_FREEZE';taskState=[string]$task.State;lastRunTime=$info.LastRunTime;lastTaskResult=$info.LastTaskResult;port=$Port;filePort=$FilePort;updatedAt=(Get-Date).ToString('o')}
    $status|ConvertTo-Json|Set-Content -Encoding UTF8 (Join-Path $Base 'service_mode.json')
  }catch{}

  Log "Main + File Services OK. Main=127.0.0.1:$Port File=127.0.0.1:$FilePort"
  if(!$NoPrompt){
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Main + File Service Anti-Freeze Server Mode ready hai.`n`nAb PC LOCK hone, user sign-out hone, ya restart ke baad login se pehle bhi Main Service chal sakti hai.`n`nAC power par Main PC automatic sleep nahi karega.`nScreen lock kar sakte hain.",$Product,'OK','Information')|Out-Null
  }
  exit 0
}catch{
  Log ('Repair error: '+$_.Exception.ToString())
  if(!$NoPrompt){try{Add-Type -AssemblyName System.Windows.Forms;[System.Windows.Forms.MessageBox]::Show("Main Service repair error:`n`n$($_.Exception.Message)",$Product,'OK','Error')|Out-Null}catch{}}
  exit 4
}
