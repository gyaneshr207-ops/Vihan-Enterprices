param([int]$Port=17868)
$ErrorActionPreference='Stop'
trap {try{$errorRoot=Join-Path $env:ProgramData 'Vihan Enterprices';New-Item -ItemType Directory -Force -Path $errorRoot|Out-Null;Set-Content -LiteralPath (Join-Path $errorRoot 'file_service_error.txt') -Value $_.Exception.ToString() -Encoding UTF8}catch{};exit 4}
$Product='Vihan Enterprices';$AppVersion='1.0.37'
$InstallRoot=Split-Path $PSScriptRoot -Parent
$Base=Join-Path $env:ProgramData $Product
$DBase='D:\Vihan Enterprices';$DataDir=Join-Path $DBase 'Data';$BlobDir=Join-Path $DataDir 'Blobs'
$PreferredBackupDir=Join-Path $DBase 'Backups';$FallbackBackupDir=Join-Path $Base 'Backups'
$ConfigFile=Join-Path $Base 'server.json';$DbFile=Join-Path $DataDir 'VihanEnterprices.db';$PidFile=Join-Path $Base 'file_service.pid';$UpdateDir=Join-Path $DBase 'Updates';$UpdatePkgDir=Join-Path $UpdateDir 'Packages';$UpdateStateFile=Join-Path $UpdateDir 'latest.json';$UpdateClientsFile=Join-Path $UpdateDir 'clients.json'
if(!(Test-Path 'D:\')){exit 5}
New-Item -ItemType Directory -Force -Path $Base,$UpdateDir,$UpdatePkgDir|Out-Null
if(!(Test-Path $ConfigFile)){exit 2}
$config=Get-Content $ConfigFile -Raw|ConvertFrom-Json;$Token=[string]$config.token;if($config.filePort){$Port=[int]$config.filePort}
. (Join-Path $PSScriptRoot 'StoragePaths.ps1')
. (Join-Path $PSScriptRoot 'ArchiveSafety.ps1')
$paths=Get-VihanStoragePaths $config
$DataDir=$paths.Data;$BlobDir=$paths.Blobs;$DbFile=$paths.Database;$BackupDir=$paths.Backup
if([string]::IsNullOrWhiteSpace($Token)){throw 'Main service token is missing'}
# Main Service alone initializes a new database. File Service must never create one.
for($i=0;$i -lt 30 -and !(Test-Path -LiteralPath $DbFile);$i++){Start-Sleep -Milliseconds 500}
if(!(Test-Path -LiteralPath $DbFile)){throw 'Configured SQLite database is missing; File Service will not create an empty replacement.'}
New-Item -ItemType Directory -Force -Path $BlobDir,$BackupDir|Out-Null
$created=$false;$mutex=New-Object System.Threading.Mutex($true,'Global\VihanEnterpricesFileService',[ref]$created);if(!$created){exit 0}
Set-Content -Path $PidFile -Value $PID -Encoding ASCII
try{$bridge=Join-Path $PSScriptRoot 'VihanSqlite.cs';if(-not ('VihanSqliteDb' -as [type])){Add-Type -Path $bridge};$db=New-Object -TypeName VihanSqliteDb -ArgumentList $DbFile}catch{try{$mutex.ReleaseMutex();$mutex.Dispose()}catch{};Remove-Item $PidFile -Force -ErrorAction SilentlyContinue;exit 4}
function Q([object]$s){if($null -eq $s){return 'NULL'};return [VihanSqliteDb]::Quote([string]$s)}
$db.Exec("CREATE TABLE IF NOT EXISTS blob_meta(blob_key TEXT PRIMARY KEY,db_name TEXT NOT NULL,store_name TEXT NOT NULL,item_id TEXT NOT NULL,record_json TEXT NOT NULL,blob_file TEXT,blob_type TEXT,updated_at TEXT);CREATE INDEX IF NOT EXISTS idx_blob_store ON blob_meta(db_name,store_name);CREATE INDEX IF NOT EXISTS idx_blob_store_updated ON blob_meta(db_name,store_name,updated_at);")
function Set-Cors($ctx){$o=[string]$ctx.Request.Headers['Origin'];if($o){$ctx.Response.Headers['Access-Control-Allow-Origin']=$o;$ctx.Response.Headers['Vary']='Origin';$ctx.Response.Headers['Access-Control-Allow-Credentials']='true'};$ctx.Response.Headers['Access-Control-Allow-Methods']='GET, POST, OPTIONS';$ctx.Response.Headers['Access-Control-Allow-Headers']='Content-Type, Cache-Control, X-Vihan-Admin, X-Vihan-Restore-Key, X-Vihan-Token, X-Vihan-PC, X-Vihan-Version';$ctx.Response.Headers['Cache-Control']='no-store'}
function Send-Bytes($ctx,[byte[]]$bytes,$type='application/octet-stream',$status=200){Set-Cors $ctx;$ctx.Response.StatusCode=$status;$ctx.Response.ContentType=$type;$ctx.Response.ContentLength64=$bytes.Length;$ctx.Response.OutputStream.Write($bytes,0,$bytes.Length);$ctx.Response.OutputStream.Close()}
function Send-Text($ctx,$text,$type='text/plain; charset=utf-8',$status=200){$b=[Text.Encoding]::UTF8.GetBytes([string]$text);Send-Bytes $ctx $b $type $status}
function Send-Json($ctx,$obj,$status=200){$json=$obj|ConvertTo-Json -Depth 100 -Compress;Send-Text $ctx $json 'application/json; charset=utf-8' $status}
function Read-Body($ctx){$r=New-Object IO.StreamReader($ctx.Request.InputStream,$ctx.Request.ContentEncoding);$s=$r.ReadToEnd();$r.Close();if([string]::IsNullOrWhiteSpace($s)){return $null};return $s|ConvertFrom-Json}
function Read-ExactBytes([IO.Stream]$stream,[int]$count){if($count -lt 0 -or $count -gt 8388608){throw 'Invalid binary header length.'};$buf=New-Object byte[] $count;$off=0;while($off -lt $count){$n=$stream.Read($buf,$off,$count-$off);if($n -le 0){throw 'Binary request incomplete.'};$off+=$n};return $buf}
function Save-StreamToFile([IO.Stream]$stream,[string]$path){$dir=[IO.Path]::GetDirectoryName($path);if($dir){New-Item -ItemType Directory -Force -Path $dir|Out-Null};$fs=[IO.File]::Open($path,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$buf=New-Object byte[] 1048576;while(($n=$stream.Read($buf,0,$buf.Length)) -gt 0){$fs.Write($buf,0,$n)};$fs.Flush($true)}finally{$fs.Dispose()}}
function Send-FileStream($ctx,[string]$path,[string]$type='application/octet-stream'){if(!(Test-Path $path)){Send-Json $ctx ([pscustomobject]@{error='File not found'}) 404;return};Set-Cors $ctx;$fi=Get-Item -LiteralPath $path;$ctx.Response.StatusCode=200;$ctx.Response.ContentType=if([string]::IsNullOrWhiteSpace($type)){'application/octet-stream'}else{$type};$ctx.Response.ContentLength64=$fi.Length;$ctx.Response.SendChunked=$false;$fs=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite);try{$buf=New-Object byte[] 1048576;while(($n=$fs.Read($buf,0,$buf.Length)) -gt 0){$ctx.Response.OutputStream.Write($buf,0,$n)}}finally{$fs.Dispose();$ctx.Response.OutputStream.Close()}}
function Authorized($ctx){$c=$ctx.Request.Cookies['VE_AUTH'];$h=[string]$ctx.Request.Headers['X-Vihan-Token'];return (($c -and $c.Value -eq $Token) -or ($h -eq $Token))}

function Compare-Version([string]$a,[string]$b){
  try{$va=[version]$a;$vb=[version]$b;return $va.CompareTo($vb)}catch{return [string]::Compare($a,$b,$true)}
}
function Read-UpdateState(){if(!(Test-Path $UpdateStateFile)){return [pscustomobject]@{available=$false;version=$AppVersion}};try{return Get-Content $UpdateStateFile -Raw|ConvertFrom-Json}catch{return [pscustomobject]@{available=$false;version=$AppVersion}}}
function Read-UpdateClients(){if(!(Test-Path $UpdateClientsFile)){return @()};try{$x=Get-Content $UpdateClientsFile -Raw|ConvertFrom-Json;return @($x.clients)}catch{return @()}}
function Save-UpdateClients($clients){[pscustomobject]@{clients=@($clients);updatedAt=(Get-Date).ToString('o')}|ConvertTo-Json -Depth 10|Set-Content -Encoding UTF8 $UpdateClientsFile}
function Register-UpdateClient($b){
  $name=[string]$b.pcName;if([string]::IsNullOrWhiteSpace($name)){return}
  $list=@(Read-UpdateClients);$now=(Get-Date).ToString('o');$hit=$list|Where-Object{[string]$_.pcName -eq $name}|Select-Object -First 1
  $row=[pscustomobject]@{pcName=$name;version=[string]$b.version;role=[string]$b.role;lastSeen=$now;status=[string]$b.status;offlineHasCache=($b.offlineHasCache -eq $true);offlineSavedAt=[string]$b.offlineSavedAt;offlineKeys=[int]$b.offlineKeys;offlineError=[string]$b.offlineError;offlineAllowed=[string]$b.offlineAllowed}
  $out=@();foreach($x in $list){if([string]$x.pcName -ne $name){$out+=,$x}};$out+=,$row
  Save-UpdateClients $out
}
function Validate-UpdatePackage([string]$path){
  $stage=Join-Path $env:TEMP ('VihanUpdateValidate_'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $stage|Out-Null
  try{
    Expand-VihanArchive $path $stage
    $mf=Join-Path $stage 'manifest.json';if(!(Test-Path $mf)){throw 'Update manifest missing'}
    $m=Get-Content $mf -Raw|ConvertFrom-Json
    if([string]$m.product -ne $Product){throw 'Ye Vihan Enterprices update package nahi hai'}
    if([string]::IsNullOrWhiteSpace([string]$m.appVersion)){throw 'Update version missing'}
    $parsedVersion=$null;if(![version]::TryParse([string]$m.appVersion,[ref]$parsedVersion)){throw 'Invalid numeric update version'}
    $m.appVersion=$parsedVersion.ToString()
    if(!(Test-Path (Join-Path $stage 'app')) -or !(Test-Path (Join-Path $stage 'runtime'))){throw 'Update app/runtime files missing'}
    if((Compare-Version ([string]$m.appVersion) $AppVersion) -le 0){throw ('Update version '+[string]$m.appVersion+' current server '+$AppVersion+' se naya nahi hai')}
    return $m
  }finally{Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue}
}
function Start-MainAutoUpdate([string]$package,[string]$version){
  $updater=Join-Path $PSScriptRoot 'AutoUpdater.ps1';if(!(Test-Path $updater)){return}
  try{
    $ps="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $tempUpdater=Join-Path $env:TEMP ('VihanMainAutoUpdater_'+[guid]::NewGuid().ToString('N')+'.ps1');Copy-Item -LiteralPath $updater -Destination $tempUpdater -Force
    $desktopExe=Join-Path $InstallRoot 'desktop-runtime\Vihan Enterprices.exe'
    Start-Process $ps -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$tempUpdater+'"'),'-PackagePath',('"'+$package+'"'),'-InstallRoot',('"'+$InstallRoot+'"'),'-RelaunchExe',('"'+$desktopExe+'"'),'-MainPc','-DelaySeconds','3') | Out-Null
  }catch{}
}

function Hash-Key($s){$sha=[Security.Cryptography.SHA256]::Create();try{$b=[Text.Encoding]::UTF8.GetBytes($s);return -join ($sha.ComputeHash($b)|ForEach-Object{$_.ToString('x2')})}finally{$sha.Dispose()}}
function Blob-Key($dbName,$store,$id){return ([string]$dbName)+'|'+([string]$store)+'|'+([string]$id)}

# ---- v1.0.35 Offline copy permission (read-only here; MainService writes offline-clients.json) ----
$OfflineClientsFile=Join-Path $Base 'offline-clients.json'
function Test-OfflineAllowed([string]$pc){
  if([string]::IsNullOrWhiteSpace($pc)){return $false}
  if(!(Test-Path $OfflineClientsFile)){return $false}
  try{$x=Get-Content $OfflineClientsFile -Raw|ConvertFrom-Json}catch{return $false}
  foreach($c in @($x.clients)){if(([string]$c.pcName).ToLowerInvariant() -eq $pc.Trim().ToLowerInvariant()){return ($c.allowed -eq $true)}}
  return $false
}
function Make-Backup(){
  $stamp=(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss')+'_'+[guid]::NewGuid().ToString('N');$stage=Join-Path $env:TEMP ('VihanBackup_'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $stage|Out-Null
  try{
    $db.BackupTo((Join-Path $stage 'VihanEnterprices.db'))
    if(Test-Path $BlobDir){Copy-Item $BlobDir -Destination (Join-Path $stage 'Blobs') -Recurse -Force}
    [pscustomobject]@{product=$Product;appVersion=$AppVersion;createdAt=(Get-Date).ToString('o');server=$env:COMPUTERNAME;persistence='SQLite';database='VihanEnterprices.db'}|ConvertTo-Json -Depth 20|Set-Content -Encoding UTF8 (Join-Path $stage 'backup_manifest.json')
    Add-Type -AssemblyName System.IO.Compression.FileSystem;$zip=Join-Path $BackupDir ('Vihan_Enterprices_Backup_'+$stamp+'.zip');[IO.Compression.ZipFile]::CreateFromDirectory($stage,$zip,[IO.Compression.CompressionLevel]::Optimal,$false);Get-ChildItem $BackupDir -Filter '*.zip'|Sort-Object LastWriteTime -Descending|Select-Object -Skip 30|Remove-Item -Force -ErrorAction SilentlyContinue;return $zip
  }finally{Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue}
}
$ready=$false
foreach($candidate in @($Port,17868,18081,28081,8001)|Select-Object -Unique){
  $testListener=New-Object Net.HttpListener;$testListener.Prefixes.Add("http://+:$candidate/")
  try{$testListener.Start();$listener=$testListener;$Port=[int]$candidate;$ready=$true;break}catch{try{$testListener.Close()}catch{}}
}
if(!$ready){try{$db.Dispose()}catch{};exit 3}
try{$config=Update-VihanServerConfig $ConfigFile @{filePort=$Port}}catch{throw 'Could not persist File Service port; startup stopped'}

. (Join-Path $PSScriptRoot 'BlobStorage.ps1')
$dataIoMutex=New-Object Threading.Mutex($false,'Global\VihanEnterpricesDataIO')
$dataIoHeld=$false
while($listener.IsListening){
  try{
    $ctx=$listener.GetContext();$req=$ctx.Request;$path=$req.Url.AbsolutePath;$method=$req.HttpMethod.ToUpperInvariant()
    if(($method -eq 'POST' -and $path.StartsWith('/api/blob/')) -or $path.StartsWith('/api/backup')){
      try{$dataIoHeld=$dataIoMutex.WaitOne(30000)}catch [Threading.AbandonedMutexException]{$dataIoHeld=$true}
      if(!$dataIoHeld){throw 'Attachment/backup operation is busy; retry after the current operation finishes'}
    }
    if($method -eq 'OPTIONS'){Set-Cors $ctx;$ctx.Response.StatusCode=204;$ctx.Response.Close();continue}
    if($path -eq '/health'){Send-Json $ctx ([pscustomobject]@{ok=$true;product=$Product;version=$AppVersion;service='files';port=$Port});continue}
    if(!(Authorized $ctx)){Send-Json $ctx ([pscustomobject]@{error='Service authorization required'}) 401;continue}
    if($path -eq '/api/update/status'){$up=Read-UpdateState;$clients=Read-UpdateClients;Send-Json $ctx ([pscustomobject]@{ok=$true;serverVersion=$AppVersion;latest=$up;clients=$clients;updatePath=$UpdateDir});continue}
    if($path -eq '/api/update/heartbeat' -and $method -eq 'POST'){$b=Read-Body $ctx;Register-UpdateClient $b;Send-Json $ctx ([pscustomobject]@{ok=$true});continue}
    if($path -eq '/api/update/package' -and $method -eq 'GET'){$up=Read-UpdateState;$fp=[string]$up.packagePath;if([string]::IsNullOrWhiteSpace($fp) -or !(Test-Path $fp)){Send-Json $ctx ([pscustomobject]@{error='Update package not found'}) 404;continue};Send-FileStream $ctx $fp 'application/octet-stream';continue}
    if($path -eq '/api/update/publish' -and $method -eq 'POST'){
      if(!(Test-VihanAdminKey ([string]$req.Headers['X-Vihan-Restore-Key']) (Join-Path $Base 'restore-admin.key'))){Send-Json $ctx ([pscustomobject]@{error='Admin authorization required'}) 403;continue}
      $tmp=Join-Path $UpdatePkgDir ('incoming_'+[guid]::NewGuid().ToString('N')+'.zip')
      try{
        Save-StreamToFile $req.InputStream $tmp
        $m=Validate-UpdatePackage $tmp;$ver=[string]$m.appVersion
        $final=Join-Path $UpdatePkgDir ('Vihan_Enterprices_Update_v'+$ver+'.veupdate')
        Move-Item -LiteralPath $tmp -Destination $final -Force
        $fi=Get-Item -LiteralPath $final;$sha=(Get-FileHash -Algorithm SHA256 -LiteralPath $final).Hash.ToUpperInvariant()
        $state=[pscustomobject]@{available=$true;version=$ver;package=[IO.Path]::GetFileName($final);packagePath=$final;size=[int64]$fi.Length;sha256=$sha;publishedAt=(Get-Date).ToString('o');publishedFrom=[string]$req.Headers['X-Vihan-PC'];product=$Product}
        $state|ConvertTo-Json -Depth 10|Set-Content -Encoding UTF8 $UpdateStateFile
        Send-Json $ctx ([pscustomobject]@{ok=$true;latest=$state;message='Update publish ho gaya. Main PC aur Clients auto-update karenge.'})
        Start-MainAutoUpdate $final $ver
      }catch{Remove-Item $tmp -Force -ErrorAction SilentlyContinue;throw}
      continue
    }
    if($path -eq '/api/blob/list'){$dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$arr=@();$sql='SELECT record_json FROM blob_meta WHERE db_name='+(Q $dbn)+' AND store_name='+(Q $store)+' ORDER BY updated_at';foreach($r in $db.Query($sql)){try{$arr+=,([string]$r['record_json']|ConvertFrom-Json)}catch{}};Send-Json $ctx ([pscustomobject]@{items=$arr});continue}
    if($path -eq '/api/blob/meta'){$dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$id=[string]$req.QueryString['id'];$k=Blob-Key $dbn $store $id;$rows=$db.Query('SELECT record_json,blob_file,blob_type FROM blob_meta WHERE blob_key='+(Q $k)+' LIMIT 1');if($rows.Count -eq 0){Send-Json $ctx ([pscustomobject]@{error='Not found'}) 404;continue};$x=$rows[0];$rec=$null;try{$rec=[string]$x['record_json']|ConvertFrom-Json}catch{};$bf=[string]$x['blob_file'];$has=$false;if($bf){$has=Test-Path (Join-Path $BlobDir $bf)};Send-Json $ctx ([pscustomobject]@{record=$rec;hasBlob=$has;blobType=[string]$x['blob_type']});continue}
    if($path -eq '/api/blob/file'){$dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$id=[string]$req.QueryString['id'];$k=Blob-Key $dbn $store $id;$rows=$db.Query('SELECT blob_file,blob_type FROM blob_meta WHERE blob_key='+(Q $k)+' LIMIT 1');if($rows.Count -eq 0){Send-Json $ctx ([pscustomobject]@{error='Not found'}) 404;continue};$bf=[string]$rows[0]['blob_file'];if([string]::IsNullOrWhiteSpace($bf)){Send-Json $ctx ([pscustomobject]@{error='No file'}) 404;continue};Send-FileStream $ctx (Join-Path $BlobDir $bf) ([string]$rows[0]['blob_type']);continue}
    if($path -eq '/api/offline/blob'){
      $pc=[string]$req.QueryString['pc']
      if(!(Test-OfflineAllowed $pc)){Send-Json $ctx ([pscustomobject]@{error='Offline copy is not allowed for this PC'}) 403;continue}
      $dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$id=[string]$req.QueryString['id'];$k=Blob-Key $dbn $store $id
      $rows=$db.Query('SELECT blob_file,blob_type FROM blob_meta WHERE blob_key='+(Q $k)+' LIMIT 1')
      if($rows.Count -eq 0){Send-Json $ctx ([pscustomobject]@{error='Not found'}) 404;continue}
      $bf=[string]$rows[0]['blob_file'];if([string]::IsNullOrWhiteSpace($bf)){Send-Json $ctx ([pscustomobject]@{error='No file'}) 404;continue}
      Send-FileStream $ctx (Join-Path $BlobDir $bf) ([string]$rows[0]['blob_type']);continue
    }
    if($path -eq '/api/blob/put-binary' -and $method -eq 'POST'){
      $head=Read-ExactBytes $req.InputStream 4;$metaLength=[BitConverter]::ToInt32($head,0)
      if($metaLength -le 0 -or $metaLength -gt 4194304){throw 'Invalid attachment metadata length'}
      $metadata=Read-ExactBytes $req.InputStream $metaLength
      $record=([Text.Encoding]::UTF8.GetString($metadata))|ConvertFrom-Json
      $expected=if($req.ContentLength64 -ge 0){$req.ContentLength64-4-$metaLength}else{-1}
      Save-VihanBlob $record $req.InputStream $expected
      Send-Json $ctx ([pscustomobject]@{ok=$true;mode='raw-binary'});continue
    }
    if($path -eq '/api/blob/get'){$dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$id=[string]$req.QueryString['id'];$k=Blob-Key $dbn $store $id;$rows=$db.Query('SELECT record_json,blob_file,blob_type FROM blob_meta WHERE blob_key='+(Q $k)+' LIMIT 1');if($rows.Count -eq 0){Send-Json $ctx ([pscustomobject]@{error='Not found'}) 404;continue};$x=$rows[0];$b64='';$bf=[string]$x['blob_file'];if($bf){$fp=Join-Path $BlobDir $bf;if(Test-Path $fp){$b64=[Convert]::ToBase64String([IO.File]::ReadAllBytes($fp))}};$rec=$null;try{$rec=[string]$x['record_json']|ConvertFrom-Json}catch{};Send-Json $ctx ([pscustomobject]@{record=$rec;blobBase64=$b64;blobType=[string]$x['blob_type']});continue}
    if($path -eq '/api/blob/put' -and $method -eq 'POST'){$b=Read-Body $ctx;Save-VihanBlob $b;Send-Json $ctx ([pscustomobject]@{ok=$true});continue}
    if($path -eq '/api/blob/delete' -and $method -eq 'POST'){$b=Read-Body $ctx;Remove-VihanBlob $b;Send-Json $ctx ([pscustomobject]@{ok=$true});continue}
    if($path -eq '/api/backup' -and $method -eq 'POST'){$zip=Make-Backup;Send-Json $ctx ([pscustomobject]@{ok=$true;file=[IO.Path]::GetFileName($zip);path=$zip;backupPath=$BackupDir;service='files'});continue}
    Send-Json $ctx ([pscustomobject]@{error='Not Found'}) 404
  }catch{try{Send-Json $ctx ([pscustomobject]@{error=$_.Exception.Message}) 500}catch{}}finally{if($dataIoHeld){$dataIoMutex.ReleaseMutex();$dataIoHeld=$false}}
}
try{$dataIoMutex.Dispose()}catch{};try{$db.Dispose()}catch{};try{$listener.Stop();$listener.Close()}catch{};try{$mutex.ReleaseMutex();$mutex.Dispose()}catch{};Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
