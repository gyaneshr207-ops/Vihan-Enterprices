v1.0.38: Offline behavior changed for security. Read reports/security/WINDOWS_STORAGE_AND_ACTIVATION_HI.md first. New copies require a live authenticated user + enrolled PC, OS-protected storage and a 24-hour grant. Legacy company-wide credential copies are retained but refused for serving. The following older notes are historical where they conflict.

VIHAN ENTERPRICES v1.0.36 - OFFLINE READ-ONLY COPY
===================================================

KYA HAI
- Main PC band hone par chune hue Client PC par ASLI app ke pages (Inquiry, Day Book, Bank Book,
  Ledger, Documents ...) sirf dekhne ke liye (Read-Only) khulte hain. Alag naya viewer nahi hai.
- Offline me koi entry/edit/delete/upload save NAHI hota aur Main PC ko kabhi wapas nahi jata.
- Offline page par "OFFLINE - Read-Only - Data: <date/time>" likha aata hai.
- Data copy sirf un PC par banti hai jinhe Main PC par ON kiya gaya ho (default: sab OFF).

SYNC KAB HOTA HAI (sirf ON wale Client PC par)
- Roz raat 8 baje ek baar (har PC ko 0-10 minute ki alag deri). Poora na ho to har 30 minute me dobara.
- PC 8 baje band tha to app khulte hi (Main PC mile to) catch-up sync.
- ON karne ke baad pehli sync 2 minute ke andar shuru (app khuli ho aur Main PC chalu ho).
- Din me ek baar se zyada poora sync nahi hota. Offline data zyada se zyada lagbhag 1 din purana.
- Pehli baar poora data + attachments aate hain (der lag sakti hai). Baad me sirf badla hua data.
- 200 MB se badi attachment offline copy me nahi aati.
- Nayi copy poori verify hone par hi purani ki jagah leti hai. Main PC khali/kam data bheje to purani copy bachi rehti hai.

PC KO ON / OFF KAISE KAREIN (Main PC ke app me)
1. Settings -> "Offline Client Management" -> "Offline PC Access - Manage Clients"
   (ya neeche daayein kone ka status badge -> "Offline PC Access").
2. List me Client PC ke aage "ON karo" / "OFF karo". Koi Admin Key ya Windows permission nahi chahiye.
3. "Copy ki halat" me dikhta hai: "Copy tayyar - Data: <date> (x ghante purana)" ya "Abhi sync nahi hui".
4. OFF karne par us PC se offline data hata diya jaata hai.
- Ye window sirf Main PC ke app se kaam karti hai. Client PC se koi ON/OFF nahi kar sakta.
- Setting file (Main PC): C:\ProgramData\Vihan Enterprices\offline-clients.json

INSTALL
1. Pehle Main PC ka backup: D:\Vihan Enterprices\Data (SQLite DB + Blobs ki poori copy).
2. Inno Setup se Vihan_Enterprices_v1.0.36_Inno_Setup.iss compile karke Setup banayein, ya purane tareeke se
   installer\Install.ps1 chalayein (jaise pehle ke versions me kiya).
3. Pehle Main PC par lagayein, phir Client PC par. Ya Main PC par pehle se v1.0.35 chal raha ho to
   "Central Software Update" se bhi update ho sakta hai.
4. Client PC par offline folder: D:\Vihan Enterprices\OfflineCopy (D: na ho to C:, phir app data).
   Usme offline-sync.log banta hai (sync ka record).

WINDOWS PAR YE JAANCH ZAROOR KAREIN
 [ ] Main PC par app normal chalti hai (save, attachments, backup pehle jaisa).
 [ ] "Offline PC Access" khulta hai aur Client PC ki list dikhti hai (koi key nahi maangi jati).
 [ ] Client ko ON karein -> 2-3 minute me list me "Copy tayyar" aata hai.
 [ ] Main PC band karke Client app kholein -> asli pages khulte hain, banner dikhta hai.
 [ ] Offline me entry/edit/upload par "Read-Only" chetawani aati hai aur kuch save nahi hota.
 [ ] Offline me PDF/photo attachments khulte hain.
 [ ] Main PC wapas chalu hone par (30 sec me) app live mode me aa jaati hai.
 [ ] OFF kiye PC par offline copy nahi banti; Main PC band hone par saaf message aata hai.
 [ ] Inquiry, Day Book, Bank Book, Ledger, Documents pages ek-ek karke offline check karein.

SEEMAYEN (SACH)
- Node me nakli Main PC + nakli Electron se logic test hua hai (tests/ folder:
  node --test --test-force-exit tests/*.test.js). Windows par asli PowerShell/Electron me nahi chalaya gaya.
- Offline me Main PC se kuch karwane wale buttons (save, upload, backup, restore, update) band rehte hain.
  Print / search / filter local hi chalte hain.
- Offline me kuch type/badle to screen par dikh sakta hai par page reload par hat jata hai.
- Ye setting sirf OFFLINE COPY ke liye hai. Online chalte waqt har PC ka app pehle ki tarah apna kaam karne ke
  liye data apne browser storage me rakhta hai (app ke design ka hissa).
- Offline sync tabhi chalta hai jab Client PC chalu ho aur Main PC mil raha ho.

BADLAV v1.0.35 -> v1.0.36
- Offline PC Access ab app ke andar hi khulta hai: Admin Key / UAC / alag PowerShell script nahi.
  Permission badlav sirf Main PC se aayi request par (Main Service jaanchti hai).
- Har Client ki offline copy ki halat Main PC ki window me dikhti hai.
- ON karne ke baad Client 2 minute me sync shuru karta hai.
- runtime\OfflineClientManager.ps1 aur FIX_MAIN_OFFLINE_BUTTON.cmd ki ab zarurat nahi.
