#define MyAppName "Vihan Enterprices"
#define MyAppVersion "1.0.39"
#define MyAppPublisher "Vihan Enterprices"
[Setup]
AppId={{0F915C66-5EB7-46E0-8236-B4D816FE55E1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\VihanEnterpricesInstallerSource
DefaultGroupName={#MyAppName}
OutputDir=Output
OutputBaseFilename=Vihan_Enterprices_v1.0.39_Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
WizardStyle=modern
ArchitecturesAllowed=x64compatible
UninstallDisplayName=Vihan Enterprices
[Files]
Source: "app\*"; DestDir: "{app}\app"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "runtime\*"; DestDir: "{app}\runtime"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "installer\*"; DestDir: "{app}\installer"; Flags: ignoreversion recursesubdirs createallsubdirs
[Tasks]
Name: "main"; Description: "Main PC / Server"; GroupDescription: "Choose this PC role:"; Flags: exclusive
Name: "client"; Description: "Client PC"; GroupDescription: "Choose this PC role:"; Flags: exclusive unchecked
[Code]
procedure CurStepChanged(CurStep: TSetupStep);
var
  ExitCode: Integer;
  Args: String;
begin
  if CurStep <> ssPostInstall then Exit;
  Args := '-NoProfile -ExecutionPolicy Bypass -File "' + ExpandConstant('{app}\installer\Install.ps1') + '"';
  if WizardSilent then
    Args := Args + ' -Mode Auto -NonInteractive -NoLaunch'
  else if WizardIsTaskSelected('main') then
    Args := Args + ' -Mode Main'
  else
    Args := Args + ' -Mode Client';
  if not Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'), Args, '', SW_HIDE, ewWaitUntilTerminated, ExitCode) then
    RaiseException('Cannot launch Windows installation worker.');
  if ExitCode <> 0 then
    RaiseException('Vihan installation worker failed; installation was not confirmed. See install.log.');
end;

function InitializeUninstall(): Boolean;
var
  ExitCode: Integer;
  Args: String;
begin
  Args := '-NoProfile -ExecutionPolicy Bypass -File "' + ExpandConstant('{app}\installer\EasyUninstall.ps1') + '"';
  if UninstallSilent then Args := Args + ' -Unattended -KeepData';
  Result := Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
    Args,
    '', SW_SHOWNORMAL, ewWaitUntilTerminated, ExitCode);
  if Result then
    Result := ExitCode = 0;
  if not Result then
    MsgBox('Uninstall cancelled or failed. Application/data removal was not confirmed.', mbInformation, MB_OK);
end;
