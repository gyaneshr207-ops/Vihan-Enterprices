(function(){
'use strict';
const secure=sessionStorage.getItem('__vihan_security_v1')==='1'&&!window.__VIHAN_OFFLINE__;
window.vihanSecurityEnabled=secure||!window.__VIHAN_OFFLINE__;
if(!secure&&!window.__VIHAN_OFFLINE__){window.vihanUserReady=false;window.vihanDraftReady=false;window.vihanCryptoReady=new Promise(()=>{});location.replace('/');return}
let draftKey=null;const sameOwner=(a,b)=>{try{return JSON.stringify(JSON.parse(a))===JSON.stringify(JSON.parse(b))}catch{return false}};
window.vihanUserReady=!secure;window.vihanDraftReady=!secure;
window.vihanAuthFetch=async function(path,body){const r=await fetch(path,{method:body===undefined?'GET':'POST',credentials:'same-origin',cache:'no-store',headers:body===undefined?{}:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});let d;try{d=await r.json()}catch{d={}}if(!r.ok){if(r.status===401&&window.vihanUserReady)window.vihanSessionExpired();const e=new Error(d.error||('HTTP '+r.status));e.status=r.status;throw e}return d};
async function prepareDraftKey(){draftKey=await window.vihanAuthFetch('/api/auth/draft-key');window.vihanDraftReady=true}
window.vihanDraftSeal=(body,owner)=>{if(!draftKey||!sameOwner(draftKey.owner,owner))throw new Error('Private draft account key is not ready or owner does not match');return VihanDraftCipher.seal(draftKey.key,JSON.stringify(body),owner,draftKey.kid)};
window.vihanDraftOpen=envelope=>{if(!draftKey||draftKey.kid!==envelope.kid)throw new Error('Private draft needs its original account key or Admin recovery');return JSON.parse(VihanDraftCipher.open(draftKey.key,envelope))};
window.vihanCryptoReady=secure&&sessionStorage.getItem('__vihan_user_ready')==='1'?prepareDraftKey().then(()=>{window.vihanUserReady=true}):Promise.resolve();
window.vihanCryptoReady.catch(()=>{});
window.vihanSessionExpired=function(){if(!window.vihanUserReady)return;window.vihanUserReady=false;sessionStorage.removeItem('__vihan_user_ready');window.vihanClearSecureView?.();draftKey=null;window.vihanDraftReady=false;sessionStorage.removeItem('mcSession');location.href='/'};
window.vihanSecureLogin=async function(input){
 const d=await window.vihanAuthFetch('/api/auth/login',input);
 window.vihanClearSecureView?.();draftKey=null;window.vihanDraftReady=false;
 await prepareDraftKey();const snapshot=await window.vihanAuthFetch('/api/snapshot');
 window.vihanApplySecureSnapshot(snapshot,d.session);window.vihanUserReady=true;sessionStorage.setItem('__vihan_user_ready','1');return d.session;
};
window.vihanSecureCommitRoot=async function(value){
 const meta=JSON.parse(sessionStorage.getItem('__vihan_sync_meta')||'{}');
 const d=await window.vihanAuthFetch('/api/auth/root',{value:JSON.stringify(value),expectedRev:Number(meta.keyRevs?.multiCompanyAdminV2)||0});
 window.vihanApplySecureSnapshot(d.snapshot,JSON.parse(sessionStorage.getItem('mcSession')||'null'),true);return true;
};
window.vihanOfflineLogout=async function(){await window.vihanAuthFetch('/api/auth/logout',{});sessionStorage.removeItem('mcSession');location.href='/'};
window.vihanSecureLogout=async function(){
 if(!await window.vihanWaitForSaved()){if(!confirm('कुछ changes Main पर save नहीं हुए हैं। Logout पर वे इसी account की encrypted pending copy में रहेंगे। Logout करें?'))return false}
 await window.vihanAuthFetch('/api/auth/logout',{});window.vihanClearSecureView();
 draftKey=null;window.vihanDraftReady=false;sessionStorage.removeItem('__vihan_user_ready');window.vihanUserReady=false;sessionStorage.removeItem('mcSession');location.href='/';return true;
};
function downloadPrivateJson(name,body){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([body],{type:'application/json'}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
window.vihanExportPrivateDrafts=function(){
 const principal=JSON.parse(sessionStorage.getItem('mcSession')||'null'),owner=JSON.stringify([principal?.type,principal?.companyId,principal?.username]),drafts=[];
 for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k==='__vihan_pending_ops_v110'||k==='__vihan_legacy_drafts_review'||k.startsWith('__vihan_drafts_')){try{const e=JSON.parse(localStorage.getItem(k));if(e.version===1&&(sameOwner(e.owner,owner)||principal?.type==='admin')&&!drafts.some(x=>x.kid===e.kid&&x.box===e.box))drafts.push(e)}catch{}}}
 if(!drafts.length)return alert('इस account के लिए कोई encrypted pending/recovery copy नहीं मिली।');
 downloadPrivateJson('Vihan_Private_Drafts_Encrypted_'+Date.now()+'.json',JSON.stringify({format:'VihanPrivateDraftBundleV1',drafts},null,2));
};
window.vihanRecoverPrivateDraft=function(){
 const input=document.createElement('input');input.type='file';input.accept='.json';input.onchange=async()=>{try{const content=JSON.parse(await input.files[0].text()),envelopes=content.format==='VihanPrivateDraftBundleV1'?content.drafts:[content],recovered=[];if(!Array.isArray(envelopes)||!envelopes.length)throw new Error('No encrypted drafts found');
 for(const e of envelopes){const d=await window.vihanAuthFetch('/api/auth/draft-key?kid='+encodeURIComponent(e.kid));if(!sameOwner(e.owner,d.owner))throw new Error('Draft owner metadata does not match its Main key');recovered.push({owner:JSON.parse(d.owner),pending:JSON.parse(VihanDraftCipher.open(d.key,e))})}
 downloadPrivateJson('Vihan_Private_Draft_Reviewed_'+Date.now()+'.json',JSON.stringify({recovered},null,2));alert('Recovery copy downloaded. Owner/company और current Main records देखकर ही changes reconcile करें; automatic import नहीं किया गया।')
 }catch(e){alert('Private draft recovery failed: '+e.message)}};input.click();
};
})();
