(function(){
'use strict';
const PRODUCT='Vihan Enterprices', APP_VERSION='1.0.39';
// v1.0.35 OFFLINE READ-ONLY: when the Main PC is off, the desktop app serves this same page from a local copy.
// In that mode (window.__VIHAN_OFFLINE__ is injected by the local offline server) NOTHING is queued or sent to the Main PC.
const OFFLINE=!!window.__VIHAN_OFFLINE__, OFFLINE_INFO=window.__VIHAN_OFFLINE_INFO__||{};
const PAGE_BOOT_AT=Date.now();let lastOfflineNotice=0;
function offlineWriteNotice(msg){
  if(!OFFLINE)return;const now=Date.now();
  if(now-PAGE_BOOT_AT<4000||now-lastOfflineNotice<12000)return; // ignore the page's own start-up writes
  lastOfflineNotice=now;try{showToast(msg||'Offline Read-Only: ye change save NAHI hoga. Main PC chalu hone par karein.','warn')}catch(_e){}
}
function offlineSavedLabel(){
  if(!OFFLINE_INFO.savedAt)return {text:'Data time pata nahi',old:true};
  const t=new Date(OFFLINE_INFO.savedAt),h=Math.max(0,Math.round((Date.now()-t.getTime())/3600000));
  const when=t.toLocaleString('en-IN',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:true});
  return {text:when+(h>=1?' ('+(h>=48?Math.floor(h/24)+' din':h+' ghante')+' purana)':''),old:h>36};
}
function ensureOfflineBanner(){
  if(!OFFLINE||document.getElementById('vihanOfflineBanner'))return;
  const lab=offlineSavedLabel();
  const st=document.createElement('style');
  st.textContent='#vihanOfflineBar{position:fixed;left:0;right:0;top:0;height:4px;z-index:2147483600;background:'+(lab.old?'#dc2626':'#f59e0b')+';pointer-events:none}#vihanOfflineBanner{position:fixed;left:50%;bottom:12px;transform:translateX(-50%);z-index:2147483600;max-width:min(760px,calc(100vw - 260px));background:'+(lab.old?'#fee2e2':'#fff7e0')+';color:'+(lab.old?'#7f1d1d':'#7a4a00')+';border:2px solid '+(lab.old?'#dc2626':'#f59e0b')+';border-radius:12px;padding:7px 14px;font:600 12.5px "Segoe UI",Arial,sans-serif;box-shadow:0 6px 24px #0003;pointer-events:none;text-align:center}';
  document.head.appendChild(st);
  const bar=document.createElement('div');bar.id='vihanOfflineBar';document.body.appendChild(bar);
  const b=document.createElement('div');b.id='vihanOfflineBanner';
  b.textContent='OFFLINE • SIRF DEKHNE KE LIYE (Read-Only) • Main PC se connection nahi • Data: '+lab.text+' • Entry / edit / upload save NAHI honge';
  document.body.appendChild(b);
}

// v1.0.34 STABLE CLIENT RECOVERY: throttle all later-created MutationObservers to at most once per frame.
// The app contains many legacy observers; batching their callbacks prevents repeated full-page scans
// during large table renders without changing their visible behavior.
(function installVihanMutationThrottle(){
  const NativeMO=window.MutationObserver;
  if(!NativeMO||window.__vihanMutationThrottleInstalled)return;
  window.__vihanMutationThrottleInstalled=true;
  class VihanMutationObserver{
    constructor(cb){
      this._cb=cb;this._records=[];this._queued=false;
      this._native=new NativeMO((records,obs)=>{
        if(records&&records.length)this._records.push(...records);
        if(this._queued)return;this._queued=true;
        const run=()=>{this._queued=false;const batch=this._records.splice(0);if(!batch.length)return;try{this._cb(batch,this)}catch(e){setTimeout(()=>{throw e},0)}};
        if(document.hidden)setTimeout(run,40);else requestAnimationFrame(run);
      });
    }
    observe(){return this._native.observe(...arguments)}
    disconnect(){this._records.length=0;this._queued=false;return this._native.disconnect()}
    takeRecords(){const a=this._records.splice(0);try{a.push(...this._native.takeRecords())}catch(_e){}return a}
  }
  window.MutationObserver=VihanMutationObserver;
})();

// Keep the v1.0.10 pending key so any unsent data from the previous build survives this update.
const PENDING_KEY='__vihan_pending_ops_v110', META_PERSIST_KEY='__vihan_persisted_sync_meta_v122';
const clientId=sessionStorage.getItem('__vihan_client_id')||('PC'+Date.now().toString(36)+Math.random().toString(36).slice(2,8));
sessionStorage.setItem('__vihan_client_id',clientId);
let meta={revision:0,keyRevs:{}};
try{meta=JSON.parse(sessionStorage.getItem('__vihan_sync_meta')||localStorage.getItem(META_PERSIST_KEY)||'null')||meta}catch(_e){}
let globalRev=Number(meta.revision)||0, keyRevs=meta.keyRevs||{}, online=false, lastSync=0;
let consecutiveFailures=0, lastRemoteToast=0, lastSaveToast=0;
let flushTimer=null, flushPromise=null, flushing=false, flushAgain=false, saveSeq=0, saving=false;
const nativeGet=Storage.prototype.getItem, nativeSet=Storage.prototype.setItem, nativeRemove=Storage.prototype.removeItem, nativeClear=Storage.prototype.clear;
const LAST_SAVED_KEY='__vihan_last_saved_at_v126';
let lastServerSaveAt=0;try{lastServerSaveAt=Number(nativeGet.call(localStorage,LAST_SAVED_KEY)||0)||0}catch(_e){}
function markSavedNow(){lastServerSaveAt=Date.now();try{nativeSet.call(localStorage,LAST_SAVED_KEY,String(lastServerSaveAt))}catch(_e){}updateBadge()}
function appKey(k){k=String(k);if(window.vihanSecurityEnabled&&(k==='company1_auto_backup_v57'||k==='db609_company_function_registry'||k==='db593_auto_permission_registry'||/(_done|_once)$/.test(k)||k==='company2_daybook_current_account_date_v575'))return false;return !k.startsWith('__vihan_')}
function saveMeta(){try{const v=JSON.stringify({revision:globalRev,keyRevs});sessionStorage.setItem('__vihan_sync_meta',v);nativeSet.call(localStorage,META_PERSIST_KEY,v)}catch(_e){}}
function loadPending(){if(window.vihanSecurityEnabled)return {};try{const x=JSON.parse(localStorage.getItem(PENDING_KEY)||'{}');return x&&typeof x==='object'?x:{}}catch(_e){return {}}}
let pending=loadPending();
for(const r of Object.values(pending)){saveSeq=Math.max(saveSeq,Number(r?.seq)||0)}
function savePending(preserveShadow=false){try{
 if(window.vihanSecurityEnabled){
   if(!window.vihanDraftReady)return;
   const owner=nativeGet.call(localStorage,'__vihan_pending_owner')||'';
   if(pendingCount()){nativeSet.call(localStorage,PENDING_KEY,JSON.stringify(window.vihanDraftSeal(pending,owner)))}
   else{nativeRemove.call(localStorage,PENDING_KEY);if(!preserveShadow&&!window.vihanPrivateDraftRecoveryNeeded&&owner)nativeRemove.call(localStorage,'__vihan_drafts_'+encodeURIComponent(owner))}
 }else nativeSet.call(localStorage,PENDING_KEY,JSON.stringify(pending))
 }catch(e){showToast('Private pending copy save नहीं हुई: '+e.message+' — app खुला रखें और Main पर save करें।','warn');throw e}}

function pendingCount(){return Object.keys(pending).length}
function nextSeq(){saveSeq=(saveSeq+1)%9007199254740000;return saveSeq}
function putPending(key,rec){
  if(OFFLINE){offlineWriteNotice();return}
  if(window.vihanSecurityEnabled&&!window.vihanUserReady)return;
  key=String(key);const prev=pending[key];
  pending[key]={...rec,key,expectedRev:Number(prev?.expectedRev??rec.expectedRev??keyRevs[key]??0),seq:nextSeq(),savedAt:Date.now(),...(prev?.conflict?{conflict:prev.conflict}:{})};
  savePending();updateBadge();
  // Fast UI path: save pending copy locally immediately, then coalesce rapid app writes for a few ms before network commit.
  // This keeps form/button clicks instant while still sending the change to Main PC almost immediately.
  if(flushing)flushAgain=true;else scheduleFlush(25);
}
function clearPendingIfSame(key,seq){const cur=pending[String(key)];if(cur&&Number(cur.seq)===Number(seq)){delete pending[String(key)];savePending();updateBadge();return true}return false}
function markOnline(){consecutiveFailures=0;online=true;lastSync=Date.now();updateBadge()}
function markFailure(){consecutiveFailures++;if(consecutiveFailures>=3)online=false;updateBadge()}
function announceRemote(msg){const now=Date.now();if(now-lastRemoteToast>2500){lastRemoteToast=now;showToast(msg||'Dusre PC se naya data sync hua. Current page open rahega.','ok')}}
function announceSaved(msg){const now=Date.now();if(now-lastSaveToast>1800){lastSaveToast=now;showToast(msg||'Data Main PC par save ho gaya.','ok')}}
function notifyRemote(detail){try{window.dispatchEvent(new CustomEvent('vihan:remote-data',{detail:detail||{revision:globalRev}}))}catch(_e){}}
function api(path,opts={}){opts.credentials='same-origin';opts.cache='no-store';return fetch(path,opts).then(async r=>{let data=null;try{data=await r.json()}catch(_e){}if(!r.ok){if(r.status===401&&window.vihanSecurityEnabled)window.vihanSessionExpired?.();let e=new Error(data?.error||('HTTP '+r.status));e.status=r.status;e.data=data;throw e}return data})}

// v1.0.34: large files, backups and central update packages use the dedicated Main-PC File Service (main port + 1).
// This keeps text saves/search/buttons responsive while a PDF/photo/software file is moving.
const MAIN_PORT=Number(location.port)||17867;
let FILE_PORT=MAIN_PORT+1;
let FILE_ORIGIN=OFFLINE?location.origin:location.protocol+'//'+location.hostname+':'+FILE_PORT;
let heavyIoCount=0,fileServiceFailures=0;
function heavyIoStart(){heavyIoCount++;schedulePoll(8000)}
function heavyIoEnd(){heavyIoCount=Math.max(0,heavyIoCount-1);if(!heavyIoCount)schedulePoll(900)}
function fileUrl(path){return FILE_ORIGIN+(String(path||'').startsWith('/')?'':'/')+String(path||'')}
let filePortCheckedAt=0,filePortCheck=null;
async function refreshFileServicePort(){
  if(OFFLINE||Date.now()-filePortCheckedAt<15000)return;
  if(filePortCheck)return filePortCheck;
  filePortCheck=(async()=>{try{const d=await api('/api/status');const n=Number(d?.fileServicePort);if(Number.isInteger(n)&&n>0&&n<=65535){FILE_PORT=n;FILE_ORIGIN=location.protocol+'//'+location.hostname+':'+n}}catch(_e){}finally{filePortCheckedAt=Date.now();filePortCheck=null}})();
  return filePortCheck;
}
async function fileJson(path,opts={}){
  await refreshFileServicePort();
  const o={...opts,credentials:'include',cache:'no-store'};
  try{
    const r=await fetch(fileUrl(path),o);let data=null;try{data=await r.json()}catch(_e){}
    if(!r.ok){const e=new Error(data?.error||('HTTP '+r.status));e.status=r.status;e.data=data;throw e}
    fileServiceFailures=0;return data;
  }catch(e){
    fileServiceFailures++;
    // Safe compatibility fallback: if the dedicated service is not ready, use the original Main Service.
    return api(path,opts);
  }
}
window.vihanFileServiceRequest=fileJson;


function vihanEscapeText(value){return String(value??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]))}
function vihanIsGlobalAdmin(){try{const x=JSON.parse(sessionStorage.getItem('mcSession')||'null');return !!(x&&String(x.type||'').toLowerCase()==='admin')}catch{return false}}
function vihanFmtBytes(n){n=Number(n)||0;if(n>=1073741824)return (n/1073741824).toFixed(1)+' GB';if(n>=1048576)return (n/1048576).toFixed(1)+' MB';if(n>=1024)return Math.round(n/1024)+' KB';return n+' B'}
window.vihanRefreshCentralUpdateStatus=async function(){
  const msg=document.getElementById('ve125UpdateMessage'),pub=document.getElementById('ve125PublishedVersion'),pcs=document.getElementById('ve125PcStatus');
  try{const d=await fileJson('/api/update/status');const latest=d?.latest||{};if(pub)pub.textContent=latest.available?('v'+(latest.version||'-')+' • '+vihanFmtBytes(latest.size||0)):'No update published';const rows=Array.isArray(d?.clients)?d.clients:[];if(pcs)pcs.innerHTML=rows.length?rows.sort((a,b)=>String(a.pcName).localeCompare(String(b.pcName))).map(x=>`<div style="display:flex;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:1px solid #edf1f7"><span><b>${String(x.pcName||'-').replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]))}</b> — ${vihanEscapeText(x.role||'PC')}</span><span>v${vihanEscapeText(x.version||'-')} • ${vihanEscapeText(x.status||'')}</span></div>`).join(''):'Abhi koi PC heartbeat nahi mila.';if(msg)msg.textContent='Central Auto Update active hai. Future update ek authorized Admin PC se publish karna hai.';return d}catch(e){if(msg)msg.textContent='Update status nahi mila: '+e.message;throw e}
};
window.vihanPublishCentralUpdate=function(){
  if(!vihanIsGlobalAdmin()){alert('Sirf Admin central software update publish kar sakta hai.');return}
  const inp=document.getElementById('ve125UpdateFile'),file=inp?.files?.[0];if(!file){alert('Pehle .veupdate ya .zip update file select karein.');return}
  if(!/\.(veupdate|zip)$/i.test(file.name)){alert('Sirf Vihan .veupdate ya .zip package select karein.');return}
  const adminKey=prompt('Central update publish करने के लिए Main PC की protected restore-admin.key दर्ज करें।');if(!adminKey)return;
  const msg=document.getElementById('ve125UpdateMessage'),btn=document.getElementById('ve125PublishBtn');if(btn)btn.disabled=true;const pid=progressBegin('file','Software Update Publish',file.name+' • Main PC ko bheja ja raha hai…');heavyIoStart();
  const sendTo=(url)=>new Promise((resolve,reject)=>{const x=new XMLHttpRequest();x.open('POST',url,true);x.withCredentials=true;x.timeout=300000;x.setRequestHeader('Content-Type','application/octet-stream');x.setRequestHeader('Cache-Control','no-store');x.setRequestHeader('X-Vihan-Admin','1');x.setRequestHeader('X-Vihan-Restore-Key',adminKey.trim());x.setRequestHeader('X-Vihan-PC','Admin App');x.upload.onprogress=e=>{if(e.lengthComputable)progressUpdate(pid,Math.min(94,5+Math.round((e.loaded/e.total)*88)),'Update package Main PC par upload ho raha hai…')};x.onload=()=>{let d=null;try{d=JSON.parse(x.responseText||'{}')}catch{};if(x.status>=200&&x.status<300)resolve(d||{});else reject(new Error(d?.error||('HTTP '+x.status)))};x.onerror=()=>reject(new Error('Update upload connection failed'));x.ontimeout=()=>reject(new Error('Update upload timeout'));x.send(file)});
  (async()=>{try{await refreshFileServicePort();let d;try{d=await sendTo(fileUrl('/api/update/publish'))}catch(e){d=await sendTo('/api/update/publish')}progressUpdate(pid,98,'Update publish ho gaya. Main PC aur clients auto-update karenge…');await new Promise(r=>requestAnimationFrame(r));progressFinish(pid,true,'✓ Central Update Published — All PCs Auto Update');if(msg)msg.textContent='Update publish ho gaya. Main PC background me update hoga; running Client apps automatically restart/update hongi. Closed Client PC next open par update hoga.';setTimeout(()=>window.vihanRefreshCentralUpdateStatus().catch(()=>{}),2500)}catch(e){progressFinish(pid,false,'Update Publish Failed');if(msg)msg.textContent='Update publish nahi hua: '+e.message;alert('Update publish error: '+e.message)}finally{heavyIoEnd();if(btn)btn.disabled=false}})();
};



// v1.0.34: App-wide visible save/upload progress. File uploads use real browser upload bytes.
// Text/data saves use request-byte progress plus the final server/SQLite acknowledgement.
let progressSeq=0;const progressOps=new Map();let progressRenderQueued=false;
function clampPct(n){return Math.max(0,Math.min(100,Math.round(Number(n)||0)))}
function scheduleProgressRender(){if(progressRenderQueued)return;progressRenderQueued=true;requestAnimationFrame(()=>{progressRenderQueued=false;renderProgress()})}
function progressBegin(kind,label,detail=''){const id='p'+(++progressSeq);progressOps.set(id,{id,kind,label,detail,pct:0,state:'active',at:Date.now()});scheduleProgressRender();return id}
function progressUpdate(id,pct,detail){const x=progressOps.get(id);if(!x)return;const next=clampPct(pct);if(next===x.pct&&detail===undefined)return;x.pct=next;if(detail!==undefined)x.detail=String(detail||'');x.state='active';x.at=Date.now();scheduleProgressRender()}
function progressFinish(id,ok=true,detail=''){const x=progressOps.get(id);if(!x)return;x.pct=ok?100:Math.max(1,x.pct);x.state=ok?'done':'error';if(detail)x.detail=String(detail);x.at=Date.now();scheduleProgressRender();setTimeout(()=>{const cur=progressOps.get(id);if(cur&&cur.state!=='active'){progressOps.delete(id);scheduleProgressRender()}},ok?1200:3500)}
function currentProgress(){const a=[...progressOps.values()];if(!a.length)return null;const active=a.filter(x=>x.state==='active');const pool=active.length?active:a;pool.sort((x,y)=>{const px=x.kind==='file'?2:x.kind==='text'?1:0,py=y.kind==='file'?2:y.kind==='text'?1:0;return py-px||y.at-x.at});return pool[0]}
function renderProgress(){const el=document.getElementById('vihanSaveProgress');if(!el)return;const x=currentProgress();if(!x){el.style.display='none';updateBadge();return}el.style.display='block';el.classList.toggle('error',x.state==='error');el.classList.toggle('done',x.state==='done');const title=x.kind==='file'?'File Upload':x.kind==='text'?'Text / Data Save':'Saving';const extra=[...progressOps.values()].filter(y=>y.state==='active'&&y.id!==x.id).length;el.querySelector('.vihanProgressTitle').textContent=title+(extra?` (+${extra} aur)`:``);el.querySelector('.vihanProgressDetail').textContent=x.detail||x.label||'';el.querySelector('.vihanProgressPct').textContent=x.state==='error'?'Pending':(x.pct+'%');el.querySelector('.vihanProgressBarFill').style.width=x.pct+'%';updateBadge()}
function xhrJsonPost(path,payload,onUpload){return new Promise((resolve,reject)=>{let body;try{body=JSON.stringify(payload)}catch(e){reject(e);return}const x=new XMLHttpRequest();x.open('POST',path,true);x.withCredentials=true;x.setRequestHeader('Content-Type','application/json');x.setRequestHeader('Cache-Control','no-store');x.upload.onprogress=e=>{if(typeof onUpload==='function'&&e.lengthComputable)onUpload(e.total?e.loaded/e.total:0)};x.upload.onload=()=>{if(typeof onUpload==='function')onUpload(1)};x.onload=()=>{let data=null;try{data=JSON.parse(x.responseText||'null')}catch(_e){}if(x.status>=200&&x.status<300){resolve(data)}else{const e=new Error(data?.error||('HTTP '+x.status));e.status=x.status;e.data=data;if(x.status===401&&window.vihanSecurityEnabled)window.vihanSessionExpired?.();reject(e)}};x.onerror=()=>{const e=new Error('Main Service connection failed');e.status=0;reject(e)};x.ontimeout=()=>{const e=new Error('Save timeout');e.status=0;reject(e)};x.send(body)})}
function scheduleFlush(ms=35){if(flushTimer)clearTimeout(flushTimer);flushTimer=setTimeout(()=>{flushTimer=null;flushPending().catch(()=>{})},ms)}
function queueSet(key,value){key=String(key);value=String(value);putPending(key,{op:'set',value,expectedRev:Number(keyRevs[key]||0)})}
function queueRemove(key){key=String(key);putPending(key,{op:'remove',expectedRev:Number(keyRevs[key]||0)})}
Storage.prototype.setItem=function(key,value){key=String(key);value=String(value);if(window.vihanSecurityEnabled&&this===localStorage&&key==='multiCompanyAdminV2'){const data=JSON.parse(value);if((data.companies||[]).some(c=>(c.users||[]).some(u=>u.password||u.passwordHash)))throw new Error('Credential-bearing data must use protected User Management; nothing was stored in browser storage.')}if(this===localStorage&&appKey(key)){let old=null;try{old=nativeGet.call(this,key)}catch(_e){}if(old===value)return;nativeSet.call(this,key,value);queueSet(key,value);return}nativeSet.call(this,key,value)};
Storage.prototype.removeItem=function(key){key=String(key);if(this===localStorage&&appKey(key)){let old=null;try{old=nativeGet.call(this,key)}catch(_e){}if(old===null)return;nativeRemove.call(this,key);queueRemove(key);return}nativeRemove.call(this,key)};
Storage.prototype.clear=function(){const keys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(appKey(k))keys.push(k)};for(const k of keys)this.removeItem(k)};

async function sendBatch(snapshot){
  const ops=snapshot.map(({key,rec})=>({key,op:rec.op==='remove'?'remove':'set',value:rec.op==='remove'?undefined:String(rec.value??localStorage.getItem(key)??''),expectedRev:Number(rec.expectedRev??keyRevs[key]??0),seq:Number(rec.seq)||0}));
  const pid=progressBegin('text','Data Save',ops.length===1?'1 change Main PC par save ho raha hai':(ops.length+' changes Main PC par save ho rahe hain'));
  try{
    progressUpdate(pid,5,'Data prepare ho raha hai…');
    const d=await xhrJsonPost('/api/storage/batch',{ops,knownRevision:globalRev,clientId},r=>{const pct=10+Math.round(Math.max(0,Math.min(1,r))*78);progressUpdate(pid,pct,r<1?'Main PC ko data bheja ja raha hai…':'Main PC SQLite me commit ho raha hai…')});
    const hasConflict=(d?.results||[]).some(x=>!x?.ok);
    progressFinish(pid,!hasConflict,hasConflict?'Kuch change retry hoga.':'✓ Text / Data Saved');
    return d;
  }catch(e){
    // Backward compatibility if a Client gets updated before the Main PC.
    if(e?.status!==404){progressFinish(pid,false,'Save Pending — Main Service ka wait.');throw e}
    const results=[];
    for(let i=0;i<ops.length;i++){const op=ops[i];try{
      const path=op.op==='remove'?'/api/storage/remove':'/api/storage/set';
      const body={key:op.key,expectedRev:op.expectedRev,knownRevision:globalRev,clientId};if(op.op!=='remove')body.value=op.value;
      const d=await api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      results.push({key:op.key,seq:op.seq,ok:true,keyRev:Number(d.keyRev)||0,revision:Number(d.revision)||0});
      progressUpdate(pid,15+Math.round(((i+1)/Math.max(1,ops.length))*75),'Purane service mode me data save ho raha hai…');
    }catch(x){if(x?.status===409)results.push({key:op.key,seq:op.seq,ok:false,conflict:true,current:x.data?.current||null,revision:Number(x.data?.revision)||0});else{progressFinish(pid,false,'Save Pending — retry hoga.');throw x}}}
    const out={ok:true,revision:Math.max(globalRev,...results.map(x=>Number(x.revision)||0)),results};
    const bad=results.some(x=>!x.ok);progressFinish(pid,!bad,bad?'Kuch change retry hoga.':'✓ Text / Data Saved');return out;
  }
}

async function flushPending(){
  if(OFFLINE)return true;
  if(window.vihanSecurityEnabled&&!window.vihanUserReady)return false;
  if(flushing){flushAgain=true;return flushPromise||false}
  const keys=Object.keys(pending).filter(k=>!pending[k]?.conflict&&!pending[k]?.blocked);if(!keys.length){saving=false;updateBadge();return pendingCount()===0}
  flushing=true;saving=true;updateBadge();
  const snapshot=keys.map(key=>({key,rec:{...pending[key]}})).filter(x=>x.rec);
  flushPromise=(async()=>{
    let allOk=true;
    try{
      const d=await sendBatch(snapshot);markOnline();globalRev=Math.max(globalRev,Number(d.revision)||0);
      const byKey=new Map((d.results||[]).map(x=>[String(x.key),x]));
      for(const sent of snapshot){
        const key=sent.key, rec=sent.rec, r=byKey.get(key);
        if(!r){allOk=false;continue}
        if(r.ok){
          const kr=Number(r.keyRev)||Number(keyRevs[key]||0);keyRevs[key]=kr;globalRev=Math.max(globalRev,Number(r.revision)||0);
          if(!clearPendingIfSame(key,rec.seq)){
            // A newer local edit happened while this request was in flight. Keep it and advance its expected revision.
            const cur=pending[key];if(cur){cur.expectedRev=kr;savePending()}
          }
        }else if(r.conflict){
          allOk=false;const cur=r.current;keyRevs[key]=Number(cur?.keyRev)||Number(keyRevs[key]||0);globalRev=Math.max(globalRev,Number(r.revision)||0);
          const now=pending[key];if(now){now.conflict={keyRev:keyRevs[key],detectedAt:Date.now()};savePending();showToast('Save conflict: दूसरे PC के बदलाव मिले। Resolve Save Conflicts से समीक्षा करें; कोई बदलाव overwrite नहीं किया गया।','warn')}
        }else allOk=false;
      }
      saveMeta();
      if(pendingCount()===0){markSavedNow();announceSaved('✓ Data Main PC par save ho gaya.');}
    }catch(e){allOk=false;markFailure();if(e.status===403){for(const sent of snapshot){if(pending[sent.key]?.seq===sent.rec.seq)pending[sent.key].blocked=true}savePending();showToast('Save denied: '+e.message+' — pending copy रखी गई है।','warn')}}
    finally{flushing=false;saving=false;flushPromise=null;updateBadge()}
    if(Object.values(pending).some(r=>!r.conflict&&!r.blocked)){const delay=online?70:900;scheduleFlush(delay)}
    if(flushAgain){flushAgain=false;scheduleFlush(20)}
    return allOk&&pendingCount()===0;
  })();
  return flushPromise;
}

let pollBusy=false,pollTimer=null;
async function poll(){if(OFFLINE||pollBusy||(window.vihanSecurityEnabled&&!window.vihanUserReady))return;pollBusy=true;try{
  if(pendingCount())await flushPending();
  let d=await api('/api/storage/changes?since='+encodeURIComponent(globalRev));if(Number(d?.revision||0)<globalRev){const snap=await api('/api/snapshot');d={full:true,revision:Number(snap.revision)||0,items:snap.items||{}};keyRevs=snap.keyRevs||{}}markOnline();let remote=false,changedKeys=[];
  if(d.full){
    const remoteItems=d.items||{};
    if(window.vihanSecurityEnabled){for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(appKey(k)&&!remoteItems[k]){nativeRemove.call(localStorage,k);delete pending[k]}}savePending()}
    for(const [k,rec] of Object.entries(remoteItems)){if(pending[k])continue;if(rec.deleted)nativeRemove.call(localStorage,k);else nativeSet.call(localStorage,k,String(rec.value??''));keyRevs[k]=Number(rec.keyRev)||0;changedKeys.push(k)}
    globalRev=Number(d.revision)||globalRev;remote=true;
  }else{
    for(const ch of (d.changes||[])){if(pending[ch.key])continue;if(ch.deleted)nativeRemove.call(localStorage,ch.key);else nativeSet.call(localStorage,ch.key,String(ch.value??''));keyRevs[ch.key]=Number(ch.keyRev)||0;globalRev=Math.max(globalRev,Number(ch.revision)||0);changedKeys.push(ch.key);if(ch.clientId!==clientId)remote=true}
  }
  globalRev=Math.max(globalRev,Number(d.revision)||0);saveMeta();if(remote){announceRemote('Dusre PC se naya data sync hua. Current company/page open rahega.');notifyRemote({type:'remote',keys:changedKeys,revision:globalRev})}
}catch(e){markFailure()}finally{pollBusy=false}}
function nextPollDelay(){
  if(document.hidden)return 12000;
  if(heavyIoCount>0)return 9000;
  if(pendingCount()||saving)return 1200;
  return 4000;
}
function schedulePoll(delay){if(OFFLINE)return;if(pollTimer)clearTimeout(pollTimer);pollTimer=setTimeout(async()=>{await poll();schedulePoll(nextPollDelay())},Math.max(150,delay||nextPollDelay()))}
document.addEventListener('visibilitychange',()=>schedulePoll(document.hidden?8000:500));if(!OFFLINE){schedulePoll(500);if(pendingCount())scheduleFlush(20)}

function restorePrivateOwner(owner){
 const raw=nativeGet.call(localStorage,PENDING_KEY)||nativeGet.call(localStorage,'__vihan_drafts_'+encodeURIComponent(owner));if(!raw)return;
 try{const envelope=JSON.parse(raw);if(envelope.owner===owner){pending=window.vihanDraftOpen(envelope);window.vihanPrivateDraftRecoveryNeeded=false;for(const r of Object.values(pending))saveSeq=Math.max(saveSeq,Number(r.seq)||0)}}catch(e){window.vihanPrivateDraftRecoveryNeeded=true;nativeSet.call(localStorage,'__vihan_drafts_'+encodeURIComponent(owner),raw);(document.readyState==='loading'?document.addEventListener('DOMContentLoaded',()=>showToast('Encrypted draft सुरक्षित है; original account key या Admin recovery चाहिए।','warn'),{once:true}):showToast('Encrypted draft सुरक्षित है; original account key या Admin recovery चाहिए।','warn'))}
}
window.vihanRestorePrivateDrafts=function(){
 const principal=JSON.parse(sessionStorage.getItem('mcSession')||'null');if(!principal)return;const owner=JSON.stringify([principal.type,principal.companyId,principal.username]);const legacy=nativeGet.call(localStorage,'__vihan_legacy_drafts_review');if(principal.type==='admin'&&legacy){try{const v=JSON.parse(legacy);if(v.version!==1)nativeSet.call(localStorage,'__vihan_legacy_drafts_review',JSON.stringify(window.vihanDraftSeal(v,owner)))}catch{}}restorePrivateOwner(owner);nativeSet.call(localStorage,'__vihan_pending_owner',owner);
 for(const [k,r] of Object.entries(pending)){if(r.op==='remove')nativeRemove.call(localStorage,k);else nativeSet.call(localStorage,k,String(r.value||''))}
 savePending();if(pendingCount())scheduleFlush(25);schedulePoll(500);
};
window.vihanClearSecureView=function(){
 if(flushTimer)clearTimeout(flushTimer);if(pollTimer)clearTimeout(pollTimer);
 const owner=nativeGet.call(localStorage,'__vihan_pending_owner');if(owner&&pendingCount()&&window.vihanDraftReady)nativeSet.call(localStorage,'__vihan_drafts_'+encodeURIComponent(owner),JSON.stringify(window.vihanDraftSeal(pending,owner)));
 pending={};savePending(true);
 const keys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(appKey(k)||k==='company1_auto_backup_v57')keys.push(k)}for(const k of keys)nativeRemove.call(localStorage,k);
};
window.vihanApplySecureSnapshot=function(snapshot,principal,keepDrafts=false){
 const owner=JSON.stringify([principal?.type,principal?.companyId,principal?.username]);
 const oldOwner=nativeGet.call(localStorage,'__vihan_pending_owner');
 if(!keepDrafts){window.vihanClearSecureView();pending={};restorePrivateOwner(owner)}
 const legacy=nativeGet.call(localStorage,'__vihan_legacy_drafts_review');if(principal?.type==='admin'&&legacy){try{const v=JSON.parse(legacy);if(v.version!==1)nativeSet.call(localStorage,'__vihan_legacy_drafts_review',JSON.stringify(window.vihanDraftSeal(v,owner)))}catch{}}
 nativeSet.call(localStorage,'__vihan_pending_owner',owner);
 globalRev=Number(snapshot.revision)||0;keyRevs=snapshot.keyRevs||{};
 for(const [k,r] of Object.entries(snapshot.items||{})){if(r.deleted)nativeRemove.call(localStorage,k);else nativeSet.call(localStorage,k,String(r.value||''))}
 // Restore only this authenticated user's pending visible keys. Denied namespaces never reappear.
 for(const [k,r] of Object.entries(pending)){if(snapshot.items?.[k]&&!r.conflict){if(r.op==='remove')nativeRemove.call(localStorage,k);else nativeSet.call(localStorage,k,String(r.value||''))}}
 saveMeta();savePending();schedulePoll(500);if(pendingCount())scheduleFlush(25);
};
window.vihanStartupRestored=false;window.vihanSecureStartupReady=(window.vihanCryptoReady||Promise.resolve()).then(()=>{if(window.vihanSecurityEnabled&&sessionStorage.getItem('__vihan_user_ready')==='1')window.vihanRestorePrivateDrafts();window.vihanStartupRestored=true});window.vihanSecureStartupReady.catch(()=>{});
window.vihanConflicts=()=>Object.entries(pending).filter(([,r])=>r.conflict).map(([key,r])=>({key,keyRev:r.conflict.keyRev}));
window.vihanResolveConflicts=async function(){
  const conflicts=window.vihanConflicts();if(!conflicts.length)return true;
  let snapshot;try{snapshot=await api('/api/snapshot')}catch(e){showToast('Main PC से latest data नहीं मिला। Conflict सुरक्षित रखा गया।','warn');return false}
  const keepLocal=confirm('दूसरे PC के बदलाव Main PC पर मौजूद हैं। इस PC के अधूरे बदलाव रखकर उन्हें बदलना है? Cancel दबाने पर Main PC की copy रखने का विकल्प मिलेगा।');
  if(!keepLocal&&!confirm('Main PC की copy रखें और इस PC के conflicting अधूरे बदलाव छोड़ दें? खुले forms में पुराने values रह सकते हैं; उन्हें Clear करके data दोबारा खोलें। Cancel दबाने पर दोनों copies सुरक्षित रहेंगी।'))return false;
  for(const {key} of conflicts){
    const now=pending[key];if(!now?.conflict)continue;const current=snapshot.items?.[key];keyRevs[key]=Number(current?.keyRev)||0;
    if(keepLocal){now.expectedRev=keyRevs[key];delete now.conflict}
    else{if(!current||current.deleted)nativeRemove.call(localStorage,key);else nativeSet.call(localStorage,key,String(current.value??''));delete pending[key]}
  }
  savePending();saveMeta();updateBadge();if(keepLocal)return flushPending();notifyRemote({type:'conflict-resolved',revision:globalRev});showToast('Main PC की copy रखी गई। खुले पुराने form को Clear करके नया data खोलें।','ok');return true;
};
window.vihanFlushPending=flushPending;
window.vihanWaitForSaved=async function(timeoutMs=4000){
  const end=Date.now()+Math.max(500,Number(timeoutMs)||4000);while(Date.now()<end){if(pendingCount()===0)return true;await flushPending();if(pendingCount()===0)return true;await new Promise(r=>setTimeout(r,120))}return pendingCount()===0;
};
window.vihanBeforeAppClose=async function(){
  try{await Promise.race([window.vihanWaitForSaved(4500),new Promise(r=>setTimeout(()=>r(false),4800))])}catch(_e){}
  return {pending:pendingCount()};
};
window.addEventListener('pagehide',()=>{try{flushPending()}catch(_e){}});

function blobFromB64(s,type){const bin=atob(s||''),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return new Blob([a],{type:type||'application/octet-stream'})}
// v1.0.27 PERFORMANCE MODE: raw binary file streaming + short metadata cache.
// This removes Base64 CPU/RAM overhead and keeps folder/file actions responsive.
const remoteBlobRefs=new WeakSet(),blobListCache=new Map();
const BLOB_CACHE_TTL=1800;
function blobCacheKey(db,store){return String(db)+'\u0001'+String(store)}
function blobCacheGet(db,store){const x=blobListCache.get(blobCacheKey(db,store));return x&&Date.now()-x.at<BLOB_CACHE_TTL?x.items:null}
function blobCacheSet(db,store,items){blobListCache.set(blobCacheKey(db,store),{at:Date.now(),items:Array.isArray(items)?items:[]})}
function blobCacheUpsert(db,store,record){const k=blobCacheKey(db,store),x=blobListCache.get(k);if(!x||!Array.isArray(x.items))return;const id=String(record?.id??record?.key??''),i=x.items.findIndex(y=>String(y?.id??y?.key??'')===id);if(i>=0)x.items[i]=record;else x.items.push(record);x.at=Date.now()}
function blobCacheDelete(db,store,id){const k=blobCacheKey(db,store),x=blobListCache.get(k);if(!x||!Array.isArray(x.items))return;x.items=x.items.filter(y=>String(y?.id??y?.key??'')!==String(id));x.at=Date.now()}
function xhrBinaryPostTo(url,meta,blob,onUpload){return new Promise((resolve,reject)=>{let metaBytes;try{metaBytes=new TextEncoder().encode(JSON.stringify(meta))}catch(e){reject(e);return}const head=new Uint8Array(4);new DataView(head.buffer).setUint32(0,metaBytes.length,true);const body=new Blob([head,metaBytes,blob],{type:'application/octet-stream'});const x=new XMLHttpRequest();x.open('POST',url,true);x.withCredentials=true;x.setRequestHeader('Content-Type','application/octet-stream');x.setRequestHeader('Cache-Control','no-store');x.upload.onprogress=e=>{if(typeof onUpload==='function'&&e.lengthComputable)onUpload(e.total?e.loaded/e.total:0)};x.onload=()=>{let data=null;try{data=JSON.parse(x.responseText||'null')}catch(_e){}if(x.status>=200&&x.status<300)resolve(data);else{const e=new Error(data?.error||('HTTP '+x.status));e.status=x.status;e.data=data;if(x.status===401&&window.vihanSecurityEnabled)window.vihanSessionExpired?.();reject(e)}};x.onerror=()=>{const e=new Error('File Service connection failed');e.status=0;reject(e)};x.ontimeout=()=>{const e=new Error('Upload timeout');e.status=0;reject(e)};x.timeout=120000;x.send(body)})}
async function xhrBinaryPost(path,meta,blob,onUpload){
  heavyIoStart();
  try{
    await refreshFileServicePort();
    try{return await xhrBinaryPostTo(fileUrl(path),meta,blob,onUpload)}
    catch(e){return await xhrBinaryPostTo(path,meta,blob,onUpload)}
  }finally{heavyIoEnd()}
}
window.vihanBlobList=async function(db,store,force=false){const hit=!force&&blobCacheGet(db,store);if(hit)return hit.slice();const d=await fileJson('/api/blob/list?db='+encodeURIComponent(db)+'&store='+encodeURIComponent(store));const items=Array.isArray(d.items)?d.items:[];blobCacheSet(db,store,items);return items.slice()};
window.vihanBlobGetMeta=async function(db,store,id){const a=await window.vihanBlobList(db,store);return a.find(x=>String(x?.id??x?.key??'')===String(id))||null};
window.vihanBlobGet=async function(db,store,id){try{const d=await fileJson('/api/blob/meta?db='+encodeURIComponent(db)+'&store='+encodeURIComponent(store)+'&id='+encodeURIComponent(id));if(!d||!d.record)return null;const r=d.record;if(d.hasBlob){heavyIoStart();let resp;try{try{resp=await fetch(fileUrl('/api/blob/file?db='+encodeURIComponent(db)+'&store='+encodeURIComponent(store)+'&id='+encodeURIComponent(id)),{credentials:'include',cache:'no-store'});if(!resp.ok&&(resp.status===401||resp.status>=500))throw new Error('Dedicated file service HTTP '+resp.status)}catch(_e){resp=await fetch('/api/blob/file?db='+encodeURIComponent(db)+'&store='+encodeURIComponent(store)+'&id='+encodeURIComponent(id),{credentials:'same-origin',cache:'no-store'})}if(!resp.ok)throw new Error('File load HTTP '+resp.status);var b=await resp.blob()}finally{heavyIoEnd()};remoteBlobRefs.add(b);r.blob=b}return r}catch(e){if(e?.status!==404)throw e;const d=await fileJson('/api/blob/get?db='+encodeURIComponent(db)+'&store='+encodeURIComponent(store)+'&id='+encodeURIComponent(id));if(!d||!d.record)return null;const r=d.record;if(d.blobBase64){const b=blobFromB64(d.blobBase64,d.blobType);remoteBlobRefs.add(b);r.blob=b}return r}};
window.vihanBlobPut=async function(db,store,obj){if(OFFLINE){offlineWriteNotice('Offline Read-Only: file / photo save nahi ho sakta.');throw new Error('Offline Read-Only: Main PC band hai, file save nahi ho sakti.')}const r={...obj};let blob=null,unchangedRemoteBlob=false;if(r.blob instanceof Blob){blob=r.blob;delete r.blob;if(remoteBlobRefs.has(blob)){unchangedRemoteBlob=true;blob=null}}const id=String(r.id??r.key??'');if(!id)throw new Error('Storage ID missing');const fileName=String(blob?.name||r.name||r.fileName||'Record');const size=Number(blob?.size)||0;const sizeText=size>=1048576?(size/1048576).toFixed(1)+' MB':size>=1024?(size/1024).toFixed(0)+' KB':'';const isFileUpload=!!blob;const pid=progressBegin(isFileUpload?'file':'text',isFileUpload?'File Upload':'Record Save',isFileUpload?(fileName+(sizeText?' • '+sizeText:'')):(unchangedRemoteBlob?'Sirf details save ho rahi hain — file dobara upload nahi hogi.':'Record Main PC par save ho raha hai…'));try{if(blob){progressUpdate(pid,3,'Raw file stream prepare ho rahi hai: '+fileName);const meta={db,store,id,record:r,clientId,blobType:blob.type||r.type||'application/octet-stream'};try{await xhrBinaryPost('/api/blob/put-binary',meta,blob,q=>{const pct=5+Math.round(Math.max(0,Math.min(1,q))*88);progressUpdate(pid,pct,q<1?('Direct upload ho raha hai: '+fileName):'Upload complete — D: drive commit ka wait…')})}catch(e){if(e?.status!==404)throw e;const payload={db,store,id,record:r,clientId,blobType:meta.blobType};progressUpdate(pid,8,'Compatibility upload mode…');const ab=await blob.arrayBuffer();let binary='';const bytes=new Uint8Array(ab),chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));payload.blobBase64=btoa(binary);await fileJson('/api/blob/put',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})}}else{const payload={db,store,id,record:r,clientId};progressUpdate(pid,40,unchangedRemoteBlob?'File same hai — details update ho rahi hain…':'Record prepare ho raha hai…');progressUpdate(pid,65,'Details dedicated File Service ko bheji ja rahi hain…');await fileJson('/api/blob/put',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});progressUpdate(pid,90,'SQLite metadata commit complete…')}blobCacheUpsert(db,store,r);markSavedNow();progressUpdate(pid,98,'Main PC ne save confirm kar diya — screen ready ho rahi hai…');await new Promise(res=>requestAnimationFrame(res));progressFinish(pid,true,isFileUpload?('✓ '+fileName+' Saved — Ready'):'✓ Details Saved — Ready');return obj}catch(e){progressFinish(pid,false,isFileUpload?('Upload Pending/Failed: '+fileName):'Record Save Pending/Failed');throw e}};
window.vihanBlobDelete=async function(db,store,id){if(OFFLINE){offlineWriteNotice('Offline Read-Only: file delete nahi ho sakta.');throw new Error('Offline Read-Only: Main PC band hai, file delete nahi ho sakti.')}await fileJson('/api/blob/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({db,store,id,clientId})});blobCacheDelete(db,store,id);markSavedNow();return true};
function ensureUi(){if(document.getElementById('vihanServiceBadge'))return;const style=document.createElement('style');style.textContent=`#vihanServiceBadge{position:fixed;right:14px;bottom:12px;z-index:2147483000;border:1px solid #b9c8df;border-radius:999px;padding:7px 11px;background:#fff;color:#334155;font:600 12px "Segoe UI",Arial,sans-serif;box-shadow:0 4px 20px #0002;cursor:pointer}#vihanServiceBadge.ok{border-color:#a7dec0;color:#146c3a;background:#f0fff6}#vihanServiceBadge.off{border-color:#efb8b8;color:#a11f1f;background:#fff4f4}#vihanServiceBadge.pending{border-color:#f2c46d;color:#8a5200;background:#fff9e8}#vihanSysModal{position:fixed;inset:0;z-index:2147483001;background:#0008;display:none;align-items:center;justify-content:center;padding:18px}#vihanSysModal.open{display:flex}#vihanSysCard{width:min(560px,96vw);background:#fff;border-radius:16px;padding:20px;font:14px "Segoe UI",Arial,sans-serif;color:#0f172a;box-shadow:0 20px 70px #0005}#vihanSysCard h2{margin:0 0 6px}#vihanSysCard .grid{display:grid;grid-template-columns:150px 1fr;gap:8px;margin:14px 0}#vihanSysCard button{border:0;border-radius:8px;padding:9px 12px;cursor:pointer;margin:4px;background:#e9f0fb}#vihanSysCard button.primary{background:#315bea;color:#fff}#vihanSaveProgress{position:fixed;right:14px;bottom:52px;width:min(410px,calc(100vw - 28px));z-index:2147483003;background:#fff;border:1px solid #b9c8df;border-radius:12px;padding:10px 12px;box-shadow:0 10px 30px #0002;font:13px "Segoe UI",Arial,sans-serif;color:#172033;display:none}#vihanSaveProgress.done{border-color:#9ed8b8}#vihanSaveProgress.error{border-color:#efb8b8;background:#fff8f8}.vihanProgressTop{display:flex;align-items:center;gap:10px}.vihanProgressTitle{font-weight:700;flex:1}.vihanProgressPct{font-weight:800;color:#2457d6;min-width:48px;text-align:right}.vihanSaveProgress.error .vihanProgressPct{color:#b42318}.vihanProgressDetail{margin-top:3px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.vihanProgressBar{height:8px;background:#e7edf6;border-radius:999px;overflow:hidden;margin-top:8px}.vihanProgressBarFill{height:100%;width:0;background:#315bea;border-radius:999px;transition:width .15s linear}#vihanSaveProgress.done .vihanProgressBarFill{background:#159447}#vihanSaveProgress.error .vihanProgressBarFill{background:#d92d20}.vihanToast{position:fixed;left:50%;bottom:55px;transform:translateX(-50%);z-index:2147483002;padding:9px 13px;border-radius:9px;background:#0f172a;color:white;font:600 12px "Segoe UI",Arial;box-shadow:0 6px 20px #0003}.vihanToast.warn{background:#92400e}.vihanToast.ok{background:#166534}`;document.head.appendChild(style);const b=document.createElement('button');b.id='vihanServiceBadge';b.type='button';b.onclick=openSystem;b.textContent='Main Service…';document.body.appendChild(b);const pg=document.createElement('div');pg.id='vihanSaveProgress';pg.innerHTML='<div class="vihanProgressTop"><div class="vihanProgressTitle">Saving</div><div class="vihanProgressPct">0%</div></div><div class="vihanProgressDetail"></div><div class="vihanProgressBar"><div class="vihanProgressBarFill"></div></div>';document.body.appendChild(pg);renderProgress();const m=document.createElement('div');m.id='vihanSysModal';m.innerHTML=`<div id="vihanSysCard"><h2>Vihan Enterprices</h2><div style="color:#64748b">Multi-PC Central Service</div><div class="grid"><b>App Version</b><span>${APP_VERSION}</span><b>Connection</b><span id="vihanConn">Checking…</span><b>Save Status</b><span id="vihanSaveState">Checking…</span><b>Unsaved / Pending</b><span id="vihanPending">0 — sab saved</span><b>Last Saved</b><span id="vihanLastSaved">-</span><b>Server</b><span id="vihanServer">-</span><b>Backup Location</b><span id="vihanBackupPath">Checking…</span><b>Last Sync</b><span id="vihanLast">-</span></div><div><button class="primary" id="vihanBackup">Backup Now</button><button id="vihanSaveNow">Save Pending Now</button><button id="vihanResolve" hidden>Resolve Save Conflicts</button><button id="vihanRefresh">Refresh Data</button><button id="vihanOfflineAdmin">Offline PC Access</button><button id="vihanPrivateExport">Export Private Draft</button><button id="vihanPrivateRecovery">Recover Private Draft</button><button id="vihanClose">Close</button></div><p style="margin:10px 0 0;color:#64748b;font-size:12px">v1.0.39: Offline copy last authorized user ki 24-hour Read-Only copy hai. Client par login aur Main-PC permission zaroori hai. Offline PC Access ke liye Main PC par Admin login karein. Company 2 sidebar ek hi stable direct router se chalta hai. Inquiry, Counter Account File, Day Book, Bank Book, Cash Main Counter, Data Entry, 4x6 Photo, All Documents aur All Software ek dusre par turant switch honge. "Unsaved / Pending = 0" ka matlab sab changes Main PC par save hain. Central SQLite data D:\Vihan Enterprices\Data me save hota hai.</p></div>`;m.onclick=e=>{if(e.target===m)m.classList.remove('open')};document.body.appendChild(m);document.getElementById('vihanPrivateExport').onclick=()=>window.vihanExportPrivateDrafts();document.getElementById('vihanPrivateRecovery').onclick=()=>window.vihanRecoverPrivateDraft();document.getElementById('vihanResolve').onclick=()=>window.vihanResolveConflicts();document.getElementById('vihanClose').onclick=()=>m.classList.remove('open');{const oa=document.getElementById('vihanOfflineAdmin');if(oa){if(OFFLINE)oa.style.display='none';else oa.onclick=()=>window.open('https://vihan-offline-admin.invalid/launch','_blank')}}document.getElementById('vihanRefresh').onclick=()=>location.href='/';document.getElementById('vihanSaveNow').onclick=async()=>{const ok=await flushPending();showToast(ok?'Pending data save ho gaya.':'Kuch data abhi pending hai.',''+(ok?'ok':'warn'))};document.getElementById('vihanBackup').onclick=async()=>{const btn=document.getElementById('vihanBackup');btn.disabled=true;btn.textContent='Backup…';try{const d=await fileJson('/api/backup',{method:'POST'});showToast('Backup ban gaya: '+(d.path||d.file||''),'ok')}catch(e){showToast('Backup nahi bana: '+e.message,'warn')}finally{btn.disabled=false;btn.textContent='Backup Now'}};updateBadge()}
async function openSystem(){document.getElementById('vihanSysModal')?.classList.add('open');try{const d=await api('/api/status');document.getElementById('vihanServer').textContent=(d.serverName||'-')+' • '+(d.serverIp||'');document.getElementById('vihanConn').textContent=OFFLINE?'Offline copy — Read Only':'Connected';const bp=document.getElementById('vihanBackupPath');if(bp)bp.textContent=d.backupPath||'-';online=true}catch(e){document.getElementById('vihanConn').textContent='Disconnected';const bp=document.getElementById('vihanBackupPath');if(bp)bp.textContent='-';online=false}updateBadge()}
function updateBadge(){const resolveButton=document.getElementById('vihanResolve');if(resolveButton)resolveButton.hidden=!Object.values(pending).some(r=>r.conflict);const b=document.getElementById('vihanServiceBadge');const pc=pendingCount();if(!b)return;
  if(OFFLINE){b.classList.remove('ok','pending');b.classList.add('off');b.textContent='● OFFLINE — Read Only';const set=(id,t)=>{const e=document.getElementById(id);if(e)e.textContent=t};set('vihanConn','Offline copy — Read Only');set('vihanSaveState','Read Only — kuch save nahi hoga');set('vihanPending','0');set('vihanLastSaved','-');set('vihanLast',offlineSavedLabel().text);const sb=document.getElementById('vihanSaveNow');if(sb)sb.disabled=true;return}
  const activeOps=(typeof progressOps!=='undefined')?[...progressOps.values()].filter(x=>x&&x.state==='active').length:0;const busy=saving||activeOps>0;b.classList.toggle('ok',online&&pc===0&&!busy);b.classList.toggle('off',!online);b.classList.toggle('pending',pc>0||busy);b.textContent=pc>0?(online?(saving?'● Saving… '+pc:'● '+pc+' Save Pending'):('● '+pc+' Save Pending')):(busy?'● Saving / Uploading…':(online?'● Main Service Connected ✓ Saved':'● Main Service Disconnected'));const l=document.getElementById('vihanLast');if(l)l.textContent=lastSync?new Date(lastSync).toLocaleTimeString('en-IN'):'-';const c=document.getElementById('vihanConn');if(c)c.textContent=online?'Connected':'Disconnected';const p=document.getElementById('vihanPending');if(p)p.textContent=pc===0?'0 — sab saved':String(pc)+' item';const st=document.getElementById('vihanSaveState');if(st)st.textContent=!online?(pc>0?'Disconnected — '+pc+' pending':'Disconnected'):(busy?(activeOps>0?'Saving / Uploading…':'Saving to Main PC…'):(pc>0?pc+' change pending':'All Saved ✓'));const ls=document.getElementById('vihanLastSaved');if(ls)ls.textContent=lastServerSaveAt?new Date(lastServerSaveAt).toLocaleString('en-IN'):'Is session me abhi save nahi hua';const sb=document.getElementById('vihanSaveNow');if(sb){sb.disabled=(pc===0&&!saving);sb.textContent=pc>0?('Save Pending Now ('+pc+')'):(saving?'Saving…':'No Pending Save')}}
function showToast(msg,kind=''){if(!document.body)return;let x=document.createElement('div');x.className='vihanToast '+kind;x.textContent=msg;document.body.appendChild(x);setTimeout(()=>x.remove(),2600)}
window.vihanShowToast=showToast;
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{ensureUi();ensureOfflineBanner()});else{ensureUi();ensureOfflineBanner()}
})();
