param([int]$Port,[string]$Directory)
$ErrorActionPreference='Stop';$Root=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$source=[IO.File]::ReadAllText((Join-Path $Root 'runtime/VihanSqlite.cs'))
$shim=@'
public static class SecurityNativeResolver {public static void Setup(){if(!System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(System.Runtime.InteropServices.OSPlatform.Windows))System.Runtime.InteropServices.NativeLibrary.SetDllImportResolver(typeof(VihanSqliteDb).Assembly,(n,a,s)=>n=="winsqlite3.dll"?System.Runtime.InteropServices.NativeLibrary.Load("libsqlite3.so.0"):System.IntPtr.Zero);}}
'@
Add-Type -TypeDefinition ($source+"`n"+$shim);[SecurityNativeResolver]::Setup()
$db=New-Object VihanSqliteDb -ArgumentList (Join-Path $Directory 'isolated.db'),$true
$db.Exec('CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v TEXT);INSERT OR IGNORE INTO meta VALUES(''revision'',''0'');CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY,value TEXT,deleted INTEGER,key_rev INTEGER,revision INTEGER,updated_at TEXT,client_id TEXT);CREATE TABLE IF NOT EXISTS changes(revision INTEGER PRIMARY KEY,key TEXT,value TEXT,deleted INTEGER,key_rev INTEGER,updated_at TEXT,client_id TEXT);CREATE TABLE IF NOT EXISTS blob_meta(blob_key TEXT PRIMARY KEY,db_name TEXT,store_name TEXT,item_id TEXT,record_json TEXT,blob_file TEXT,blob_type TEXT,updated_at TEXT);')
$t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'runtime/MainService.ps1'),[ref]$t,[ref]$e)
foreach($name in @('Q','B','Send-Bytes','Send-Text','Send-Json','Read-Body','Get-Revision','Row-Record','Get-CurrentRecord','Plan-Ops','Commit-Plan','Authorized','Hash-Key','Blob-Key','Save-StreamToFile')){$node=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true);Invoke-Expression $node.Extent.Text}
. (Join-Path $Root 'runtime/UserSecurity.ps1');Initialize-VihanSecurity
. (Join-Path $Root 'runtime/BlobStorage.ps1')
$BlobDir=Join-Path $Directory 'Blobs';New-Item -ItemType Directory -Path $BlobDir -Force|Out-Null
function Test-OfflineAllowed([string]$Pc){return $Pc -ceq 'ENROLLED-PC'}
if(!$db.ScalarLong('SELECT COUNT(*) FROM kv',0)){
 $seed=Get-Content (Join-Path $Directory 'seed.json') -Raw|ConvertFrom-Json
 foreach($p in $seed.PSObject.Properties){$op=[pscustomobject]@{key=$p.Name;value=(ConvertTo-Json -InputObject $p.Value -Depth 100 -Compress);op='set';expectedRev=0;seq=0};Commit-Plan (Plan-Ops @($op) 'seed')}
}
$config=[pscustomobject]@{port=$Port;filePort=($Port+1)};$listener=New-Object Net.HttpListener;$listener.Prefixes.Add("http://127.0.0.1:$Port/");$listener.Start();Write-Output 'READY'
try{while($listener.IsListening){$ctx=$listener.GetContext();try{
 $Token='fixture-device-only';$req=$ctx.Request;$path=$req.Url.AbsolutePath
 if($path -eq '/connect' -and $req.QueryString['token'] -ceq $Token){$ctx.Response.AppendHeader('Set-Cookie','VE_AUTH=fixture-device-only; Path=/; HttpOnly');$ctx.Response.StatusCode=302;$ctx.Response.RedirectLocation='/';$ctx.Response.Close();continue}
 if(!(Authorized $ctx)){Send-Json $ctx @{error='Service authorization required'} 401;continue}
 if($path -eq '/' -or $path.StartsWith('/app/')){$rel=if($path -eq '/'){'bootstrap.html'}else{$path.Substring(5)};$f=[IO.Path]::GetFullPath((Join-Path (Join-Path $Root 'app') $rel));if(!$f.StartsWith((Join-Path $Root 'app')+[IO.Path]::DirectorySeparatorChar) -or !(Test-Path -LiteralPath $f)){Send-Text $ctx 'Not found' 'text/plain' 404;continue};$type=if($f.EndsWith('.js')){'application/javascript'}else{'text/html'};Send-Bytes $ctx ([IO.File]::ReadAllBytes($f)) $type;continue}
 if(!(Invoke-VihanSecurityGate $ctx)){continue}
 if($path -eq '/api/status'){Send-Json $ctx @{ok=$true;product='Vihan Enterprices';securityVersion=1;fileServicePort=$Port};continue}
 if($path -eq '/__test/expire'){$db.Exec('UPDATE auth_sessions SET expires=0 WHERE token_hash='+(Q $script:RequestIdentity.tokenHash));Send-Json $ctx @{ok=$true};continue}
 $path=$ctx.Request.Url.AbsolutePath
 if($path -eq '/api/blob/list'){$arr=@();foreach($row in $db.Query('SELECT record_json FROM blob_meta WHERE db_name='+(Q ([string]$req.QueryString['db']))+' AND store_name='+(Q ([string]$req.QueryString['store'])))){$arr+=,([string]$row['record_json']|ConvertFrom-Json)};Send-Json $ctx @{items=$arr};continue}
 if($path -eq '/api/blob/file'){$key=Blob-Key ([string]$req.QueryString['db']) ([string]$req.QueryString['store']) ([string]$req.QueryString['id']);$rows=$db.Query('SELECT blob_file FROM blob_meta WHERE blob_key='+(Q $key));if(!$rows.Count){Send-Json $ctx @{error='Not found'} 404;continue};Send-Bytes $ctx ([IO.File]::ReadAllBytes((Join-Path $BlobDir ([string]$rows[0]['blob_file']))));continue}
 if($path -eq '/api/blob/delete'){$b=Read-Body $ctx;Remove-VihanBlob $b;Send-Json $ctx @{ok=$true};continue}
 if($path -eq '/api/blob/put'){$b=Read-Body $ctx;Save-VihanBlob $b;Send-Json $ctx @{ok=$true};continue}
 Send-Json $ctx @{ok=$true;identity=$script:RequestIdentity.username}
 }catch{Send-Json $ctx @{error=$_.Exception.Message} 403}}}finally{$listener.Close();$db.Dispose()}
