$ErrorActionPreference='Stop'
$Root=Split-Path $PSScriptRoot -Parent
$source=[IO.File]::ReadAllText((Join-Path $Root 'runtime/VihanSqlite.cs'))
$shim=@'
public static class AuditNativeResolver {
 public static void Setup(){if(!System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(System.Runtime.InteropServices.OSPlatform.Windows))System.Runtime.InteropServices.NativeLibrary.SetDllImportResolver(typeof(VihanSqliteDb).Assembly,(name,a,s)=>name=="winsqlite3.dll"?System.Runtime.InteropServices.NativeLibrary.Load("libsqlite3.so.0"):System.IntPtr.Zero);}
}
'@
Add-Type -TypeDefinition ($source+"`n"+$shim);[AuditNativeResolver]::Setup()
function Assert($Condition,[string]$Name){if(!$Condition){throw $Name};Write-Output ('PASS '+$Name)}
# Extract actual service functions without starting services or touching D:.
$tokens=$null;$parseErrors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'runtime/MainService.ps1'),[ref]$tokens,[ref]$parseErrors)
foreach($name in @('Q','B','Get-Revision','Row-Record','Get-CurrentRecord','Plan-Ops','Commit-Plan','Get-Snapshot','Get-ChangesSince','Hash-Key','Blob-Key','Save-StreamToFile')){
  $node=$ast.Find({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$true)
  if(!$node){throw ('Missing service function '+$name)};Invoke-Expression $node.Extent.Text
}
. (Join-Path $Root 'runtime/StoragePaths.ps1')
. (Join-Path $Root 'runtime/BlobStorage.ps1')
$temp=Join-Path ([IO.Path]::GetTempPath()) ('VihanBackendAudit_'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temp|Out-Null
$BlobDir=Join-Path $temp 'Blobs';New-Item -ItemType Directory -Path $BlobDir|Out-Null
$db=New-Object VihanSqliteDb -ArgumentList (Join-Path $temp 'test.db'),$true
try{
  $schema=@'
CREATE TABLE meta(k TEXT PRIMARY KEY,v TEXT NOT NULL);INSERT INTO meta VALUES('revision','0');
CREATE TABLE kv(key TEXT PRIMARY KEY,value TEXT NOT NULL,deleted INTEGER,key_rev INTEGER,revision INTEGER,updated_at TEXT,client_id TEXT);
CREATE TABLE changes(revision INTEGER PRIMARY KEY,key TEXT,value TEXT,deleted INTEGER,key_rev INTEGER,updated_at TEXT,client_id TEXT);
CREATE TABLE blob_meta(blob_key TEXT PRIMARY KEY,db_name TEXT,store_name TEXT,item_id TEXT,record_json TEXT,blob_file TEXT,blob_type TEXT,updated_at TEXT);
'@
  $db.Exec($schema)
  $plan=Plan-Ops @([pscustomobject]@{key='company';value='Main saved';op='set';expectedRev=0;seq=1}) 'main';Commit-Plan $plan
  Assert ((Get-CurrentRecord 'company').value -eq 'Main saved') 'Actual service plan/commit saves text to SQLite'
  $conflict=Plan-Ops @([pscustomobject]@{key='company';value='stale client';op='set';expectedRev=0;seq=2}) 'client'
  Assert ($conflict.results[0].conflict -and $conflict.planned.Count -eq 0) 'Stale client revision is rejected without overwrite'
  $duplicate=Plan-Ops @([pscustomobject]@{key='dupe';value='one';op='set';expectedRev=0;seq=1},[pscustomobject]@{key='dupe';value='two';op='set';expectedRev=0;seq=2}) 'client'
  Assert ($duplicate.planned.Count -eq 1 -and $duplicate.results[1].conflict) 'Duplicate same-key batch cannot bypass expected revision'
  Commit-Plan $duplicate
  Assert ((Get-Snapshot).items.company.value -eq 'Main saved' -and (Get-ChangesSince 0).revision -eq 2) 'Snapshot and changes include committed revisions'
  $record=[pscustomobject]@{db='docs';store='files';id='one';record=[pscustomobject]@{name='first.txt'};blobType='text/plain';blobBase64=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('original bytes'))}
  Save-VihanBlob $record
  $before=$db.Query("SELECT blob_file FROM blob_meta WHERE item_id='one'")[0]['blob_file']
  Assert ([IO.File]::ReadAllText((Join-Path $BlobDir $before)) -eq 'original bytes') 'Attachment bytes and metadata commit together'
  $replacement=[pscustomobject]@{db='docs';store='files';id='one';record=[pscustomobject]@{name='new.txt'};blobType='text/plain'}
  $stream=New-Object IO.MemoryStream -ArgumentList (,([Text.Encoding]::UTF8.GetBytes('cut')))
  $failed=$false;try{Save-VihanBlob $replacement $stream 100}catch{$failed=$true}finally{$stream.Dispose()}
  Assert ($failed -and [IO.File]::ReadAllText((Join-Path $BlobDir $before)) -eq 'original bytes') 'Interrupted upload retains the existing file'
  $db.Exec("CREATE TRIGGER refuse_replace BEFORE INSERT ON blob_meta WHEN NEW.item_id='one' BEGIN SELECT RAISE(ABORT,'injected disk/SQL failure');END;")
  $record.blobBase64=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('new bytes'))
  $failed=$false;try{Save-VihanBlob $record}catch{$failed=$true}
  Assert ($failed -and [IO.File]::ReadAllText((Join-Path $BlobDir $before)) -eq 'original bytes' -and (Get-ChildItem $BlobDir).Count -eq 1) 'SQL failure retains original attachment and cleans new upload'
  $db.Exec('DROP TRIGGER refuse_replace;');Save-VihanBlob $record
  $after=$db.Query("SELECT blob_file FROM blob_meta WHERE item_id='one'")[0]['blob_file']
  Assert ($after -ne $before -and !(Test-Path (Join-Path $BlobDir $before))) 'Successful replacement switches metadata before removing old bytes'
  Remove-VihanBlob $record
  Assert ($db.ScalarLong('SELECT COUNT(*) FROM blob_meta',-1) -eq 0 -and (Get-ChildItem $BlobDir).Count -eq 0) 'Attachment delete removes metadata and bytes'
  $missing=Join-Path $temp 'missing.db';$blocked=$false
  try{Assert-VihanDatabaseStart ([pscustomobject]@{token='test';initializeDatabase=$false}) $missing $null}catch{$blocked=$true}
  Assert $blocked 'Missing initialized database is blocked'
  Assert (Assert-VihanDatabaseStart ([pscustomobject]@{token='test';initializeDatabase=$true}) $missing $null) 'Only explicit fresh initialization is allowed'
  $legacy=Join-Path $temp 'storage.json';Set-Content $legacy '{}';$blocked=$false
  try{Assert-VihanDatabaseStart ([pscustomobject]@{token='test';initializeDatabase=$true}) $missing $temp}catch{$blocked=$true}
  Assert $blocked 'Legacy data prevents automatic creation/migration'
  Assert ((Assert-VihanAbsolutePath 'D:\Custom Data\' 'Data' -DDrive) -eq 'D:\Custom Data') 'Absolute D-drive paths with spaces are retained and normalized'
  $blocked=$false;try{Assert-VihanAbsolutePath 'C:\Other\Data' 'Data' -DDrive}catch{$blocked=$true};Assert $blocked 'Wrong-drive configuration is rejected, never silently migrated'
  $blocked=$false;try{Assert-VihanAbsolutePath 'D:\Data\..\Other' 'Data' -DDrive}catch{$blocked=$true};Assert $blocked 'Parent traversal cannot redirect the configured data path'
  $updaterTokens=$null;$updaterErrors=$null;$updaterAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'runtime/AutoUpdater.ps1'),[ref]$updaterTokens,[ref]$updaterErrors)
  foreach($name in @('Backup-Current','Restore-Current')){$node=$updaterAst.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true);Invoke-Expression $node.Extent.Text}
  function Log([string]$Message){}
  $InstallRoot=Join-Path $temp 'Software';$saved=Join-Path $temp 'Rollback'
  New-Item -ItemType Directory -Path (Join-Path $InstallRoot 'app'),(Join-Path $InstallRoot 'runtime'),(Join-Path $InstallRoot 'desktop-runtime/resources/app') -Force|Out-Null
  Set-Content (Join-Path $InstallRoot 'app/index.html') 'old application';Set-Content (Join-Path $InstallRoot 'runtime/worker.ps1') 'old runtime';Set-Content (Join-Path $InstallRoot 'desktop-runtime/resources/app/main.js') 'old desktop host';Set-Content (Join-Path $InstallRoot 'installed_version.json') '{"version":"old"}'
  Backup-Current $saved
  Set-Content (Join-Path $InstallRoot 'app/index.html') 'broken update';Set-Content (Join-Path $InstallRoot 'installed_version.json') '{"version":"new"}'
  Restore-Current $saved
  Assert ((Get-Content (Join-Path $InstallRoot 'app/index.html') -Raw).Trim() -eq 'old application' -and (Get-Content (Join-Path $InstallRoot 'desktop-runtime/resources/app/main.js') -Raw).Trim() -eq 'old desktop host') 'Actual updater backup/rollback restores application and desktop host'
  Assert ((Get-Content (Join-Path $InstallRoot 'installed_version.json') -Raw|ConvertFrom-Json).version -eq 'old') 'Failed update rollback restores installed version metadata'
  $keyFile=Join-Path $temp 'test-admin.key';Set-Content $keyFile 'Fixture-Key-Only'
  Assert ((Test-VihanAdminKey 'Fixture-Key-Only' $keyFile) -and !(Test-VihanAdminKey 'fixture-key-only' $keyFile) -and !(Test-VihanAdminKey '' $keyFile) -and !(Test-VihanAdminKey '1' $keyFile)) 'Privileged update authorization requires the real case-sensitive key, not a boolean header'
  $config=Join-Path $temp 'server.json';Set-Content $config '{"token":"test-identity","dataDir":"D:\\Custom Data","port":17867}'
  $updated=Update-VihanServerConfig $config @{filePort=18081}
  Assert ($updated.port -eq 17867 -and $updated.filePort -eq 18081 -and $updated.token -eq 'test-identity' -and $updated.dataDir -eq 'D:\Custom Data') 'Port updates preserve identity, other service port and configured data path'
}finally{$db.Dispose();Remove-Item -LiteralPath $temp -Recurse -Force}
