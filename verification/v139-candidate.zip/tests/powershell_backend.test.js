'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),cp=require('node:child_process'),path=require('node:path');
const executable=process.env.PWSH_PATH||'pwsh';
for(const [file,min] of [['sqlite_bridge.integration.ps1',15],['backend_safety.integration.ps1',15],['powershell_syntax.integration.ps1',1],['archive_safety.integration.ps1',6],['security_core.integration.ps1',10]])test('PowerShell/SQLite integration: '+file,{skip:!process.env.PWSH_PATH&&cp.spawnSync(executable,['--version']).error?'PowerShell 7 is not installed':false},()=>{
 const run=cp.spawnSync(executable,['-NoLogo','-NoProfile','-File',path.join(__dirname,file)],{encoding:'utf8',timeout:60000});assert.equal(run.status,0,run.stdout+'\n'+run.stderr);const lines=run.stdout.trim().split('\n').filter(Boolean);assert.ok(lines.length>=min,run.stdout);console.log(lines.join('\n'));
});
