param([string]$Root=(Split-Path $PSScriptRoot -Parent))
$ErrorActionPreference='Stop'
$source=[IO.File]::ReadAllText((Join-Path $Root 'runtime/VihanSqlite.cs'))
$harness=@'
public static class SqliteAuditTests {
  static System.Collections.Generic.List<string> passed = new System.Collections.Generic.List<string>();
  static void Check(bool ok,string name){if(!ok)throw new System.Exception(name);passed.Add(name);}
  public static string Run(string dir){
    if(!System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(System.Runtime.InteropServices.OSPlatform.Windows))
      System.Runtime.InteropServices.NativeLibrary.SetDllImportResolver(typeof(VihanSqliteDb).Assembly,(name,assembly,search)=>name=="winsqlite3.dll"?System.Runtime.InteropServices.NativeLibrary.Load("libsqlite3.so.0"):System.IntPtr.Zero);
    string file=System.IO.Path.Combine(dir,"Hindi space परीक्षण.db");
    bool blocked=false;try{using(var unexpected=new VihanSqliteDb(file)){} }catch(System.IO.FileNotFoundException){blocked=true;}
    Check(blocked&&!System.IO.File.Exists(file),"Missing configured database cannot silently become an empty database");
    using(var db=new VihanSqliteDb(file,true)){
      db.Exec("CREATE TABLE entries(id INTEGER PRIMARY KEY,name TEXT);CREATE TABLE counters(id INTEGER PRIMARY KEY,n INTEGER);INSERT INTO counters VALUES(1,0),(2,0);");
      db.Exec("INSERT INTO entries VALUES(1,"+VihanSqliteDb.Quote("नाम O'Brien")+");");
      Check(db.ScalarText("SELECT name FROM entries WHERE id=1","")=="नाम O'Brien","Unicode, spaces and quoted data save/read");
      bool failed=false;try{db.Exec("BEGIN IMMEDIATE;INSERT INTO entries VALUES(2,'must rollback');INSERT INTO missing_table VALUES(1);COMMIT;");}catch{failed=true;}
      Check(failed&&db.ScalarLong("SELECT COUNT(*) FROM entries WHERE id=2",-1)==0,"Failed group commit rolls back all partial writes");
      db.Exec("BEGIN IMMEDIATE;INSERT INTO entries VALUES(3,'after failure');COMMIT;");
      Check(db.ScalarLong("SELECT COUNT(*) FROM entries",0)==2,"Connection can save after a failed transaction");
      var writer=System.Threading.Tasks.Task.Run(()=>{using(var other=new VihanSqliteDb(file)){for(int i=0;i<60;i++)other.Exec("BEGIN IMMEDIATE;UPDATE counters SET n=n+1 WHERE id=1;UPDATE counters SET n=n+1 WHERE id=2;COMMIT;");}});
      for(int i=0;i<4;i++){
        string backup=System.IO.Path.Combine(dir,"snapshot_"+i+".db");db.BackupTo(backup);
        using(var snapshot=new VihanSqliteDb(backup)){
          Check(snapshot.ScalarText("PRAGMA quick_check","")=="ok","SQLite snapshot integrity "+i);
          Check(snapshot.ScalarLong("SELECT n FROM counters WHERE id=1",-1)==snapshot.ScalarLong("SELECT n FROM counters WHERE id=2",-2),"Backup is transaction-consistent during another connection's writes "+i);
        }
      }
      writer.GetAwaiter().GetResult();
      Check(db.ScalarLong("SELECT n FROM counters WHERE id=1",0)==60,"Concurrent writer commits survive");
      bool overwrite=false;try{db.BackupTo(System.IO.Path.Combine(dir,"snapshot_0.db"));}catch(System.ArgumentException){overwrite=true;}
      Check(overwrite,"Backup refuses an existing destination");
    }
    using(var reopened=new VihanSqliteDb(file))Check(reopened.ScalarLong("SELECT COUNT(*) FROM entries",0)==2&&reopened.ScalarLong("SELECT n FROM counters WHERE id=1",0)==60,"Database save/reopen persistence");
    return string.Join("\n",passed);
  }
}
'@
Add-Type -TypeDefinition ($source+"`n"+$harness)
$temp=Join-Path ([IO.Path]::GetTempPath()) ('VihanSqliteAudit_'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temp|Out-Null
try{[SqliteAuditTests]::Run($temp)}finally{Remove-Item -LiteralPath $temp -Recurse -Force}
