﻿# Must be executed on Windows. Creates only the supplied NEW isolated D: directory.
param([Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
if($env:OS -ne 'Windows_NT'){throw 'NOT RUN: native Windows required'}
if($OutputDirectory -notmatch '^[Dd]:\\' -or (Test-Path -LiteralPath $OutputDirectory)){throw 'Supply a new absolute D: test directory; existing paths are refused'}
$root=Split-Path $PSScriptRoot -Parent;New-Item -ItemType Directory -Path $OutputDirectory|Out-Null
$results=New-Object Collections.ArrayList;$db=$null;$snap=$null
try{
 Add-Type -Path (Join-Path $root 'runtime/VihanSqlite.cs');Add-Type -Path (Join-Path $root 'runtime/VihanAuthCrypto.cs')
 $file=Join-Path $OutputDirectory 'Native परीक्षण space.db'
 $db=New-Object VihanSqliteDb -ArgumentList $file,$true
 $db.Exec('CREATE TABLE test(id INTEGER PRIMARY KEY,value TEXT);INSERT INTO test VALUES(1,''native Windows save'');')
 if($db.ScalarText('SELECT value FROM test WHERE id=1','') -ne 'native Windows save'){throw 'Native save/read mismatch'}
 [void]$results.Add('PASS native winsqlite3 save/read in D path with spaces and Unicode')
 $backup=Join-Path $OutputDirectory 'snapshot.db';$db.BackupTo($backup);$db.Dispose();$db=$null
 $db=New-Object VihanSqliteDb -ArgumentList $file;$snap=New-Object VihanSqliteDb -ArgumentList $backup
 if($db.ScalarText('PRAGMA integrity_check','') -ne 'ok' -or $snap.ScalarText('PRAGMA integrity_check','') -ne 'ok'){throw 'Integrity failure'}
 [void]$results.Add('PASS native reopen persistence and online-backup integrity')
 $hash=[VihanAuthCrypto]::HashPassword('Isolated-smoke-fixture!');if(![VihanAuthCrypto]::Verify('Isolated-smoke-fixture!',$hash)){throw 'Hash verification failed'}
 [void]$results.Add('PASS native Framework PBKDF2-SHA256 support')
 [void]$results.Add('PENDING: Main/File service lifecycle, SYSTEM/Task Scheduler/UAC, installer, ACL failures, two-PC LAN, camera and printing require separate isolated Windows execution')
}finally{if($snap){$snap.Dispose()};if($db){$db.Dispose()};$results|Set-Content -LiteralPath (Join-Path $OutputDirectory 'native-smoke-results.txt') -Encoding UTF8}
$results
