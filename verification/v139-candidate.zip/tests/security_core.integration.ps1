$ErrorActionPreference='Stop';$Root=Split-Path $PSScriptRoot -Parent
$source=[IO.File]::ReadAllText((Join-Path $Root 'runtime/VihanSqlite.cs'))
$shim=@'
public static class CoreNativeResolver {public static void Setup(){if(!System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(System.Runtime.InteropServices.OSPlatform.Windows))System.Runtime.InteropServices.NativeLibrary.SetDllImportResolver(typeof(VihanSqliteDb).Assembly,(n,a,s)=>n=="winsqlite3.dll"?System.Runtime.InteropServices.NativeLibrary.Load("libsqlite3.so.0"):System.IntPtr.Zero);}}
'@
Add-Type -TypeDefinition ($source+"`n"+$shim);[CoreNativeResolver]::Setup()
Add-Type -Path (Join-Path $Root 'runtime/VihanAuthCrypto.cs')
function Assert($Ok,$Message){if(!$Ok){throw $Message};Write-Output ('PASS '+$Message)}
$a=[VihanAuthCrypto]::HashPassword('Fixture-password-only!');$b=[VihanAuthCrypto]::HashPassword('Fixture-password-only!')
Assert ($a -cne $b -and [VihanAuthCrypto]::Verify('Fixture-password-only!',$a) -and ![VihanAuthCrypto]::Verify('wrong',$a)) 'Unique salts, actual PBKDF2 verification and wrong-password rejection'
Assert (![VihanAuthCrypto]::Verify('x','pbkdf2-sha256$1$bad$bad')) 'Malformed and weakened hash formats rejected'
. (Join-Path $Root 'runtime/UserSecurity.ps1')
foreach($json in @('[]','[{"id":"one","users":[{"password":"must-strip","passwordHash":"must-strip"}]}]','{"nested":{"users":[{"password":"must-strip","name":"keep"}]}}')){
 $v=Get-VihanProjectedValue ([pscustomobject]@{type='admin'}) 'example' $json
 Assert (!$v.Contains('must-strip') -and (!$json.StartsWith('[') -or $v.StartsWith('['))) 'Projection preserves JSON collection shape and removes credential fields'
}
Assert ((Get-VihanProjectedValue ([pscustomobject]@{type='admin'}) 'business' '{"pin":123456,"token":"customer-reference"}').Contains('123456')) 'Business postal PIN/reference fields are preserved; account credential filtering is scoped'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('Vihan security migration '+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $temp|Out-Null
$db=$null;$copy=$null;$safety=$null
try{
 $file=Join-Path $temp 'original.db';$db=New-Object VihanSqliteDb -ArgumentList $file,$true
 $db.Exec('CREATE TABLE meta(k TEXT PRIMARY KEY,v TEXT);INSERT INTO meta VALUES(''revision'',''3'');CREATE TABLE kv(key TEXT PRIMARY KEY,value TEXT,deleted INTEGER,key_rev INTEGER,revision INTEGER,updated_at TEXT,client_id TEXT);CREATE TABLE changes(revision INTEGER PRIMARY KEY,key TEXT,value TEXT,deleted INTEGER,key_rev INTEGER,updated_at TEXT,client_id TEXT);')
 $fixtureRootJson='{"companies":[{"id":"one","active":true,"users":[{"username":"boss","password":"Fixture-password-only!","role":"Admin","active":true}],"students":[{"id":"preserve","name":"Record preserved"}]}]}'
 $db.Exec('CREATE TABLE auth_sessions(token_hash TEXT PRIMARY KEY);INSERT INTO auth_sessions VALUES(''fixture-hash'');')
 Clear-VihanRestoredSessions $db
 Assert ($db.ScalarLong('SELECT COUNT(*) FROM auth_sessions',-1) -eq 0) 'Restore invalidates old session grants before exposing restored data'
 $db.Exec("INSERT INTO kv VALUES('multiCompanyAdminV2',"+[VihanSqliteDb]::Quote($fixtureRootJson)+",0,1,3,'now','fixture');INSERT INTO changes VALUES(3,'multiCompanyAdminV2',"+[VihanSqliteDb]::Quote($fixtureRootJson)+",0,1,'now','fixture');")
 $out=Join-Path $temp 'candidate';$plan=Join-Path $temp 'plan-only'
 & (Join-Path $Root 'runtime/CredentialMigration.ps1') -SourceDatabase $file -OutputDirectory $plan
 Assert (!(Test-Path -LiteralPath $plan)) 'Migration default plan creates no files and opens no database'
 & (Join-Path $Root 'runtime/CredentialMigration.ps1') -SourceDatabase $file -OutputDirectory $out -PrepareCopy
 Assert ($db.ScalarText("SELECT value FROM kv WHERE key='multiCompanyAdminV2'",'') -ceq $fixtureRootJson) 'Original database credential and business records unchanged'
 $copy=New-Object VihanSqliteDb -ArgumentList (Join-Path $out 'VihanEnterprices.db');$v=$copy.ScalarText("SELECT value FROM kv WHERE key='multiCompanyAdminV2'",'')|ConvertFrom-Json
 Assert (!$v.companies[0].users[0].password -and [VihanAuthCrypto]::Verify('Fixture-password-only!',[string]$v.companies[0].users[0].passwordHash)) 'Prepared copy converts credentials without account lockout'
 Assert ($v.companies[0].students[0].id -eq 'preserve' -and $copy.ScalarText('PRAGMA integrity_check','') -eq 'ok') 'Candidate SQLite integrity and business record preserved'
 Assert ($copy.ScalarLong('SELECT COUNT(*) FROM changes',-1) -eq 0) 'Credential-bearing legacy change history removed from candidate'
 $safety=New-Object VihanSqliteDb -ArgumentList (Join-Path $out 'before-credentials.db')
 Assert ($safety.ScalarText("SELECT value FROM kv WHERE key='multiCompanyAdminV2'",'') -ceq $fixtureRootJson) 'Separate original safety copy supports rollback'
 $blocked=$false;try{& (Join-Path $Root 'runtime/CredentialMigration.ps1') -SourceDatabase $file -OutputDirectory $out -PrepareCopy}catch{$blocked=$true};Assert $blocked 'Migration refuses existing output directory overwrite'
}finally{if($safety){$safety.Dispose()};if($copy){$copy.Dispose()};if($db){$db.Dispose()};Remove-Item -LiteralPath $temp -Recurse -Force}
