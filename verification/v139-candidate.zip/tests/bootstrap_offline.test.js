'use strict';
// Runs the REAL app/bootstrap.html script against the local offline server (fake browser, real HTTP).
const test = require('node:test'), assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http'), vm = require('vm');
const protection=require('./helpers/test-protection');
const { createOfflineManager } = require('../runtime/electron-app/offline.js');

function httpGet(url, cookie) { return new Promise((res, rej) => http.get(url, { headers: { Cookie: cookie } }, r => { const c = []; r.on('data', d => c.push(d)); r.on('end', () => res({ status: r.statusCode, body: Buffer.concat(c).toString() })); }).on('error', rej)); }

test('bootstrap.html fills localStorage from the offline copy and opens /app/index.html', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vihan-bs-'));
  const appDir = path.join(__dirname, '..', 'app');
  const om = createOfflineManager({ hostname: 'PC', dataDir: () => path.join(dir, 'data'), appDir: () => appDir,encrypt:protection.encrypt,decrypt:protection.decrypt });
  fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'data', 'offline-data.json'), protection.encodedData({ schemaVersion: 3, savedAt: new Date().toISOString(), revision: 42, items: { company_1_daybook: { value: '[{"a":1}]', keyRev: 9 }, mcSession_settings: { value: 'x', keyRev: 1 } } }));
  const info = await om.startServer();
  const cookie = (await new Promise(r => http.get(info.url, x => { x.resume(); r(x.headers['set-cookie'][0].split(';')[0]); }))).toString();
  const html = (await httpGet(info.origin + '/', cookie)).body;
  const script = /<script>([\s\S]*)<\/script>/.exec(html)[1];

  class Storage { constructor() { this.m = new Map(); } getItem(k) { return this.m.has(k) ? this.m.get(k) : null; } setItem(k, v) { this.m.set(k, String(v)); } removeItem(k) { this.m.delete(k); } key(i) { return [...this.m.keys()][i] ?? null; } get length() { return this.m.size; } }
  const sb = { Storage, localStorage: new Storage(), sessionStorage: new Storage(), console, JSON, Number, Object, Error, Date, Promise, Set, String };
  // a stale key that no longer exists in the offline copy must disappear
  sb.localStorage.setItem('old_stale_key', 'zzz');
  let redirected = null; const els = {};
  sb.document = { getElementById: (id) => els[id] || (els[id] = { style: {}, textContent: '' }) };
  sb.location = { replace: (u) => { redirected = u; } };
  sb.fetch = async (u) => { const r = await httpGet(info.origin + u, cookie); return { ok: r.status === 200, json: async () => JSON.parse(r.body) }; };
  vm.createContext(sb);
  await vm.runInContext('(' + 'async()=>{' + script.trim().replace(/^\(async\(\)=>\{/, '').replace(/\}\)\(\);\s*$/, '') + '})()', sb);
  assert.strictEqual(redirected, '/app/index.html?v=1.0.38');
  assert.strictEqual(sb.localStorage.getItem('company_1_daybook'), '[{"a":1}]');
  assert.strictEqual(sb.localStorage.getItem('old_stale_key'), null);
  assert.strictEqual(sb.localStorage.getItem('__vihan_pending_ops_v110'), null, 'nothing queued for the Main PC');
  assert.strictEqual(JSON.parse(sb.localStorage.getItem('__vihan_persisted_sync_meta_v122')).revision, 42);
  om.stopServer();
});
