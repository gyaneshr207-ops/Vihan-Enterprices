'use strict';
const test = require('node:test'), assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path'), http = require('http'), vm = require('vm');
const { spawn } = require('child_process');
const TOKEN = 'tok123';

// ---------- the Offline PC Access window (app/offline-admin.html) in a fake browser ----------
function adminPage(responder) {
  const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'offline-admin.html'), 'utf8');
  const script = /<script>([\s\S]*)<\/script>/.exec(html)[1];
  const els = {}; const el = (id) => els[id] || (els[id] = { id, style: {}, className: '', textContent: '', innerHTML: '', listeners: {}, addEventListener(n, f) { this.listeners[n] = f; } });
  const calls = [];
  const sb = { document: { getElementById: el, hidden: false }, console, JSON, Date, Math, Promise, Error, String, Number, Array, Object, isNaN, setInterval: () => 0,
    fetch: async (u, o) => { calls.push({ u, method: (o && o.method) || 'GET', body: o && o.body }); const r = await responder(calls[calls.length - 1]); return { ok: r.status === 200, status: r.status, json: async () => r.body }; } };
  vm.createContext(sb); vm.runInContext(script, sb);
  return { el, calls, sb };
}
const tick = () => new Promise(r => setTimeout(r, 20));
const clients = [
  { pcName: 'MAIN-PC', role: 'Main PC', lastSeen: '2026-10-19T10:00:00Z', allowed: false },
  { pcName: 'COUNTER-1', role: 'Client PC', lastSeen: '2026-10-19T10:00:00Z', allowed: true, offlineHasCache: true, offlineSavedAt: new Date(Date.now() - 5 * 3600e3).toISOString(), offlineKeys: 321 },
  { pcName: 'COUNTER-2', role: 'Client PC', lastSeen: '2026-10-19T10:00:00Z', allowed: true, offlineHasCache: false, offlineSavedAt: '' },
  { pcName: 'FRONT-DESK', role: 'Client PC', lastSeen: '', allowed: false }
];
test('admin page: opens with NO key prompt, lists only Client PCs with clear copy status', async () => {
  const a = adminPage(async () => ({ status: 200, body: { ok: true, clients } }));
  await tick();
  assert.strictEqual(a.calls[0].method, 'GET'); assert.strictEqual(a.calls[0].u, '/api/offline/clients');
  const rows = a.el('rows').innerHTML;
  assert.ok(!rows.includes('MAIN-PC'), 'Main PC is not offered');
  assert.match(rows, /COUNTER-1/); assert.match(rows, /Copy tayyar/); assert.match(rows, /321 data items/);
  assert.match(rows, /COUNTER-2[\s\S]*Abhi sync nahi hui/);
  assert.match(rows, /FRONT-DESK/);
  assert.strictEqual(a.el('listCard').style.display, 'block');
  assert.ok(!/password|Admin Key/i.test(fs.readFileSync(path.join(__dirname, '..', 'app', 'offline-admin.html'), 'utf8').replace(/<div class="note">[\s\S]*?<\/div>/, '')), 'no key field');
});
test('admin page: ON / OFF button sends the right request and refreshes', async () => {
  const a = adminPage(async (c) => c.method === 'POST' ? { status: 200, body: { ok: true, clients: clients.map(x => x.pcName === 'FRONT-DESK' ? { ...x, allowed: true } : x) } } : { status: 200, body: { ok: true, clients } });
  await tick();
  const btn = { dataset: { pc: 'FRONT-DESK', to: '1' }, disabled: false };
  await a.el('rows').listeners.click({ target: { closest: () => btn } });
  const post = a.calls.find(c => c.method === 'POST');
  assert.deepStrictEqual(JSON.parse(post.body), { pcName: 'FRONT-DESK', allowed: true });
  assert.match(a.el('msg').textContent, /FRONT-DESK par offline copy ON/); assert.match(a.el('msg').className, /ok/);
});
test('admin page: clear messages for LAN client (403), old Main service (404), no connection', async () => {
  let a = adminPage(async () => ({ status: 403, body: { error: 'x', mainOnly: true } })); await tick();
  assert.match(a.el('msg').textContent, /sirf Main PC par/); assert.strictEqual(a.el('listCard').style.display, 'none');
  a = adminPage(async () => ({ status: 404, body: null })); await tick();
  assert.match(a.el('msg').textContent, /service purani/);
  a = adminPage(async () => { throw new Error('net'); }); await tick();
  assert.match(a.el('msg').textContent, /connection nahi/);
});

// ---------- main.js: the button, and the heartbeat that reports the offline copy ----------
function freePair() { return new Promise((resolve) => { const tryOne = () => { const p = 21000 + Math.floor(Math.random() * 20000); const a = http.createServer(), b = http.createServer(); a.listen(p, '127.0.0.1', () => b.listen(p + 1, '127.0.0.1', () => resolve({ p, a, b })).on('error', () => { a.close(); tryOne(); })).on('error', tryOne); }; tryOne(); }); }
function setup(port, withCache) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'vihan-adm-')), appdata = path.join(root, 'appdata'), userData = path.join(root, 'userdata');
  fs.mkdirSync(path.join(appdata, 'Vihan Enterprices'), { recursive: true }); fs.mkdirSync(userData, { recursive: true });
  fs.writeFileSync(path.join(appdata, 'Vihan Enterprices', 'connection.json'), JSON.stringify({ product: 'Vihan Enterprices', port, token: TOKEN, serverIpUrl: 'http://127.0.0.1:' + port, serverUrl: 'http://127.0.0.1:' + port }));
  if (withCache) { const d = path.join(userData, 'OfflineCopy'); fs.mkdirSync(d, { recursive: true }); fs.writeFileSync(path.join(d, 'offline-data.json'), JSON.stringify({ schemaVersion: 3, savedAt: '2026-10-18T14:35:00.000Z', revision: 5, items: { k1: { value: '1', keyRev: 1 } } })); }
  return { root, appdata, userData };
}
function runMain(e, ms, press) {
  return new Promise((resolve, reject) => {
    const p = spawn(process.execPath, [path.join(__dirname, 'helpers', 'run_main_harness.js'), String(ms)], { env: { ...process.env, APPDATA: e.appdata, HARNESS_USERDATA: e.userData, ProgramData: path.join(e.root, 'none'), ...(press ? { HARNESS_PRESS: '1' } : {}) } });
    let out = ''; p.stdout.on('data', d => out += d); p.stderr.on('data', d => out += d);
    p.on('close', () => { try { resolve(JSON.parse(out.trim().split('\n').pop())); } catch { reject(new Error('bad output: ' + out)); } });
  });
}
const jsonRes = (res, o, s = 200) => { const b = Buffer.from(JSON.stringify(o)); res.writeHead(s, { 'Content-Type': 'application/json', 'Content-Length': b.length }); res.end(b); };

test('main.js: Offline PC Access button opens the in-app admin window (no PowerShell, no UAC)', async () => {
  const { p, a, b } = await freePair();
  a.on('request', (q, r) => jsonRes(r, { ok: true, product: 'Vihan Enterprices', serverName: 'MAIN' }));
  b.on('request', (q, r) => jsonRes(r, { latest: { version: '1.0.36' }, clients: [] }));
  const r = await runMain(setup(p, false), 2500, true);
  a.close(); b.close();
  assert.ok(!r.crash, r.crash);
  assert.deepStrictEqual(r.pressed, { action: 'deny' }, 'the fake link is never opened as a web page');
  assert.strictEqual(r.childWindows.length, 1, JSON.stringify(r));
  assert.deepStrictEqual(r.childWindows[0].loaded, ['http://127.0.0.1:' + p + '/app/offline-admin.html']);
  assert.deepStrictEqual(r.errorBoxes, []);
});
test('main.js: button while the Main PC is unreachable shows a clear message instead of a broken window', async () => {
  const e = setup(1, true);   // nothing listens on port 1 -> app shows the offline copy
  const r = await runMain(e, 2500, true);
  assert.ok(!r.crash, r.crash);
  assert.strictEqual(r.childWindows.length, 0);
  assert.match(r.errorBoxes[0] || '', /Main PC se connection nahi/);
});
test('main.js: heartbeat tells the Main PC whether this Client has an offline copy', async () => {
  const { p, a, b } = await freePair(); const beats = [];
  a.on('request', (q, r) => jsonRes(r, { ok: true, product: 'Vihan Enterprices', serverName: 'MAIN' }));
  b.on('request', (q, r) => { if (q.url.startsWith('/api/update/heartbeat')) { let d = ''; q.on('data', x => d += x); q.on('end', () => { beats.push(JSON.parse(d)); jsonRes(r, { ok: true }); }); } else jsonRes(r, { latest: { version: '1.0.36' }, clients: [] }); });
  await runMain(setup(p, true), 3000, false);
  a.close(); b.close();
  assert.ok(beats.length >= 1, 'heartbeat sent');
  const h = beats[0];
  assert.strictEqual(h.role, 'Client PC'); assert.strictEqual(h.offlineHasCache, true);
  assert.strictEqual(h.offlineSavedAt, '2026-10-18T14:35:00.000Z'); assert.strictEqual(h.offlineKeys, 1);
});
