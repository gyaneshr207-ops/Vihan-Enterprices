$ErrorActionPreference='Stop'
$Root=Split-Path $PSScriptRoot -Parent
$count=0
Get-ChildItem $Root -Recurse -Filter *.ps1|ForEach-Object{
  $tokens=$null;$errors=$null
  $ast=[Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$tokens,[ref]$errors)
  if($errors.Count){throw ($_.Name+': '+($errors.Message -join '; '))}
  $bad=$ast.FindAll({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -match '^(PID|Host|HOME|PSVersionTable|PSScriptRoot|PSCommandPath)$'},$true)
  if($bad.Count){throw ($_.Name+': assignment to a reserved PowerShell variable')}
  $count++
}
Write-Output ('PASS '+$count+' PowerShell files parse; no reserved-variable assignments')
