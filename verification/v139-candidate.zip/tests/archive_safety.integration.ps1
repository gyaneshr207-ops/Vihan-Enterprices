$ErrorActionPreference='Stop';$Root=Split-Path $PSScriptRoot -Parent
. (Join-Path $Root 'runtime/ArchiveSafety.ps1')
$temp=Join-Path ([IO.Path]::GetTempPath()) ('VihanArchiveAudit_'+[guid]::NewGuid().ToString('N'));[IO.Directory]::CreateDirectory($temp)|Out-Null
function Make-Archive([string]$Name,[string[]]$Entries){$file=Join-Path $temp $Name;$zip=[IO.Compression.ZipFile]::Open($file,[IO.Compression.ZipArchiveMode]::Create);try{foreach($entryName in $Entries){$entry=$zip.CreateEntry($entryName);$writer=New-Object IO.StreamWriter($entry.Open());try{$writer.Write('fixture')}finally{$writer.Dispose()}}}finally{$zip.Dispose()};return $file}
try{
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $valid=Make-Archive 'valid.zip' @('app/index.html','runtime/test file.ps1');$dest=Join-Path $temp 'valid';Expand-VihanArchive $valid $dest
  if([IO.File]::ReadAllText((Join-Path $dest 'app/index.html')) -ne 'fixture'){throw 'Valid archive failed'};'PASS Valid archive with nested paths and spaces extracts'
  $cases=@(@('../outside.txt'),@('app\..\..\outside.txt'),@('D:\outside.txt'),@('app/file.txt','APP/FILE.TXT'),@('app/NUL.txt'))
  $index=0
  foreach($names in $cases){$file=Make-Archive ('bad'+$index+'.zip') $names;$dest=Join-Path $temp ('bad'+$index);$rejected=$false;try{Expand-VihanArchive $file $dest}catch{$rejected=$true};if(!$rejected){throw 'Unsafe archive was accepted'};if(Test-Path $dest){throw 'Validation wrote destination files before rejection'};'PASS Unsafe archive rejected before extraction '+$index;$index++}
}finally{Remove-Item -LiteralPath $temp -Recurse -Force}
