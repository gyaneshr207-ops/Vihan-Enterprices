'use strict';
// Test stand-in for Electron's Windows OS protection API; never shipped as a production key.
const crypto=require('node:crypto'),key=crypto.createHash('sha256').update('isolated OS-protection test fixture only').digest();
const principal={type:'user',companyId:'fixture-company',username:'fixture-user',role:'User'};
function encrypt(text){const iv=crypto.randomBytes(12),c=crypto.createCipheriv('aes-256-gcm',key,iv),body=Buffer.concat([c.update(text),c.final()]);return Buffer.concat([iv,c.getAuthTag(),body])}
function decrypt(bytes){const d=crypto.createDecipheriv('aes-256-gcm',key,bytes.subarray(0,12));d.setAuthTag(bytes.subarray(12,28));return Buffer.concat([d.update(bytes.subarray(28)),d.final()]).toString()}
const grant=()=>({securityVersion:1,principal,offlineExpiresAt:Math.floor(Date.now()/1000)+86400});
const encodedData=data=>JSON.stringify({secureVersion:1,ciphertext:encrypt(JSON.stringify({...data,...grant()})).toString('base64')});
module.exports={encrypt,decrypt,grant,encodedData,principal};
