'use strict';
// Linux browser integration fixture. This emulates the HTTP API contract;
// it does not replace or claim to exercise Windows MainService/SQLite.
const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'../..');
async function startFixture(options={}){
 const vm=require('node:vm'),source=fs.readFileSync(path.join(root,'app/index.html'),'utf8'),initialText=/const initial=([\s\S]*?\n\]});/.exec(source)[1];let fixtureId=0;const initial=vm.runInNewContext('('+initialText+')',{id:()=> 'fixture-c'+(++fixtureId)});initial.studentCompanyId=initial.companies[0].id;initial.company2ModuleId=initial.companies[1].id;
 const storage=new Map([['multiCompanyAdminV2',{key:'multiCompanyAdminV2',value:JSON.stringify(initial),keyRev:1,revision:0,deleted:false}]]),blobs=new Map(),changes=[],requests=[];let revision=0,listDelay=0;
 const blobKey=(db,store,id)=>JSON.stringify([db,store,String(id)]);
 const draftKeys=new Map(),sessions=new Map(),clean=x=>JSON.parse(JSON.stringify(x,(k,v)=>['password','passwordHash'].includes(k)?undefined:v)),snapshot=()=>({revision,items:Object.fromEntries([...storage].map(([k,v])=>[k,{...v,value:(()=>{try{return JSON.stringify(clean(JSON.parse(v.value)))}catch{return v.value}})()}])),keyRevs:Object.fromEntries([...storage].map(([k,v])=>[k,v.keyRev]))});
 const handler=async(req,res)=>{
  const u=new URL(req.url,'http://fixture'),p=u.pathname;requests.push({method:req.method,path:p,port:req.socket.localPort});
  res.setHeader('Access-Control-Allow-Origin',req.headers.origin||'*');res.setHeader('Access-Control-Allow-Credentials','true');res.setHeader('Access-Control-Allow-Headers','Content-Type, Cache-Control');
  if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}
  const json=(d,status=200)=>{res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(d))};
  const chunks=[];for await(const c of req)chunks.push(c);const raw=Buffer.concat(chunks);let body={};
  if(raw.length&&p!=='/api/blob/put-binary')try{body=JSON.parse(raw.toString())}catch{}
  if(p==='/api/auth/info')return json({securityVersion:1,companies:JSON.parse(storage.get('multiCompanyAdminV2').value).companies.map(c=>({id:c.id,name:c.name,active:c.active,users:[],records:[]}))});
  if(p==='/api/auth/login'){
   const d=JSON.parse(storage.get('multiCompanyAdminV2').value);let principal;
   for(const c of d.companies){if(body.type==='user'&&c.id!==body.companyId)continue;const u=c.users.find(u=>u.username===body.username&&u.password===body.password&&u.active!==false&&(body.type!=='admin'||u.role==='Admin'));if(u){principal={type:body.type,username:u.username,companyId:c.id,role:u.role};break}}
   if(!principal)return json({error:'Invalid login'},401);const token=Math.random().toString(36);sessions.set(token,principal);res.setHeader('Set-Cookie','VE_SESSION='+token+'; Path=/; HttpOnly');return json({session:principal});
  }
  const sid=/VE_SESSION=([^;]+)/.exec(req.headers.cookie||'')?.[1],principal=sessions.get(sid);
  if(p==='/api/auth/session')return principal?json({session:principal}):json({error:'Login required'},401);
  if(p==='/api/auth/draft-key'){if(!principal)return json({error:'Login required'},401);const owner=JSON.stringify([principal.type,principal.companyId,principal.username]);if(!draftKeys.has(owner))draftKeys.set(owner,{kid:require('crypto').randomBytes(16).toString('hex'),key:require('crypto').randomBytes(32).toString('base64url'),owner});const own=draftKeys.get(owner),kid=u.searchParams.get('kid');if(kid&&kid!==own.kid){if(principal.type!=='admin')return json({error:'Draft key denied'},403);return json([...draftKeys.values()].find(k=>k.kid===kid)||{},200)}return json(own)}
  if(p==='/api/auth/logout'){sessions.delete(sid);return json({ok:true})}
  if(p==='/api/auth/root'){
   const current=storage.get('multiCompanyAdminV2'),v=JSON.parse(body.value),old=JSON.parse(current.value);
   for(const c of v.companies)for(const u of c.users){const previous=old.companies.find(x=>x.id===c.id)?.users.find(x=>x.username===u.username);if(!u.password&&previous?.password)u.password=previous.password}
   const rec={...current,value:JSON.stringify(v),keyRev:current.keyRev+1,revision:++revision};storage.set('multiCompanyAdminV2',rec);changes.push(rec);return json({ok:true,snapshot:snapshot()});
  }
  if(p==='/api/storage/batch'){
   const results=body.ops.map(op=>{const current=storage.get(op.key);if(Number(op.expectedRev||0)!==Number(current?.keyRev||0))return{key:op.key,seq:op.seq,ok:false,conflict:true,current:current||null,revision};let value=op.value;if(op.key==='multiCompanyAdminV2'&&op.op!=='remove'){const next=JSON.parse(value),prev=JSON.parse(current?.value||'{"companies":[]}');for(const c of next.companies)for(const u of c.users){const old=prev.companies.find(x=>x.id===c.id)?.users.find(x=>x.username===u.username);if(!u.password&&old?.password)u.password=old.password}value=JSON.stringify(next)}const rec={key:op.key,value,deleted:op.op==='remove',keyRev:(storage.get(op.key)?.keyRev||0)+1,revision:++revision,clientId:body.clientId};storage.set(op.key,rec);changes.push(rec);return{key:op.key,seq:op.seq,ok:true,keyRev:rec.keyRev,revision}});return json({ok:true,results,revision});
  }
  if(p==='/api/snapshot')return json(snapshot());
  if(p==='/api/storage/changes')return json({revision,changes:changes.filter(x=>x.revision>Number(u.searchParams.get('since')||0)).map(r=>({...r,value:(()=>{try{return JSON.stringify(clean(JSON.parse(r.value)))}catch{return r.value}})()}))});
  if(p==='/api/blob/list'){
   const items=[...blobs.values()].filter(x=>x.db===u.searchParams.get('db')&&x.store===u.searchParams.get('store')).map(x=>x.record);
   if(listDelay)await new Promise(r=>setTimeout(r,listDelay));return json({items});
  }
  if(p==='/api/blob/put-binary'){
   const len=raw.readUInt32LE(0),meta=JSON.parse(raw.subarray(4,4+len));blobs.set(blobKey(meta.db,meta.store,meta.id),{...meta,bytes:raw.subarray(4+len)});return json({ok:true});
  }
  if(p==='/api/blob/put'){const key=blobKey(body.db,body.store,body.id),old=blobs.get(key);blobs.set(key,{...old,...body,bytes:body.blobBase64?Buffer.from(body.blobBase64,'base64'):old?.bytes});return json({ok:true})}
  if(p==='/api/blob/delete'){blobs.delete(blobKey(body.db,body.store,body.id));return json({ok:true})}
  if(p==='/api/blob/meta'||p==='/api/blob/file'){
   const b=blobs.get(blobKey(u.searchParams.get('db'),u.searchParams.get('store'),u.searchParams.get('id')));if(!b)return json({error:'not found'},404);
   if(p.endsWith('/meta'))return json({record:b.record,hasBlob:!!b.bytes});res.setHeader('Content-Type',b.blobType||'application/octet-stream');return res.end(b.bytes);
  }
  if(p==='/api/status')return json({ok:true,serverName:'TEST FIXTURE',persistence:'HTTP contract fixture (not SQLite)',fileServicePort:file.address().port});
  if(p==='/health')return json({ok:true,product:'Vihan Enterprices'});
  if(p==='/api/update/status')return json({latest:{available:false},clients:[]});
  if(p.startsWith('/api/'))return json({error:'Unimplemented fixture API: '+p},404);
  let relative=p==='/'?'app/index.html':p.replace(/^\//,'');const staticFile=path.resolve(root,relative);
  if(!staticFile.startsWith(root+path.sep)||!fs.existsSync(staticFile)||!fs.statSync(staticFile).isFile()){res.writeHead(404);return res.end('not found')}
  res.setHeader('Content-Type',staticFile.endsWith('.js')?'text/javascript':'text/html');res.end(fs.readFileSync(staticFile));
 };
 const main=http.createServer((req,res)=>handler(req,res).catch(e=>{res.statusCode=500;res.end(e.message)}));
 await new Promise(r=>main.listen(0,'127.0.0.1',r));const port=main.address().port;
 const file=http.createServer((req,res)=>handler(req,res).catch(e=>{res.statusCode=500;res.end(e.message)}));
 await new Promise((r,j)=>{file.once('error',j);file.listen(options.nonAdjacentFilePort?0:port+1,'127.0.0.1',r)});
 return{url:'http://127.0.0.1:'+port,filePort:file.address().port,storage,blobs,requests,setListDelay:n=>listDelay=n,close:async()=>{main.closeAllConnections();file.closeAllConnections();await Promise.all([new Promise(r=>main.close(r)),new Promise(r=>file.close(r))])}};
}
async function openCompany2(browser,fixture,type='admin'){
 const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
 const page=await context.newPage(),errors=[];page.setDefaultTimeout(8000);
 page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
 await page.goto(fixture.url+'/app/bootstrap.html');await page.waitForURL('**/app/index.html*');
 // Use the existing login UI, with the ZIP's fresh-install demo accounts only.
 await page.locator('#loginType').selectOption(type);
 if(type==='user')await page.locator('#loginCompany').selectOption({label:'Company 2'});
 await page.locator('#loginUsername').fill(type==='admin'?'admin':'user');
 await page.locator('#loginPassword').fill(type==='admin'?'admin123':'user123');
 await page.locator('.login-btn').click();
 await page.waitForFunction(()=>document.getElementById('app').style.display==='block');
 if(type==='admin')await page.evaluate(()=>viewCompany(getData().companies.find(c=>c.name==='Company 2').id));
 await page.locator('#c2InquiryRuntimeV150').waitFor();await page.waitForTimeout(180);
 return{context,page,errors};
}
const labels=['Inquiry Form','Counter Account File','Day Book','Bank Book','Cash Main Counter','Data Entry','4×6 Photo','All Documents','All Software'];
const roots=['c2WorkspaceV184','c2WorkspaceV184','c2DayBookPageV226','c2WorkspaceV184','c2WorkspaceV184','c2WorkspaceV184','photo4x6PageV783','allDocumentsPageV819','allSoftwarePageV821'];
function button(page,label){return page.locator('#c2InquiryRuntimeV150 button.nav').filter({hasText:new RegExp('^'+label+'$')})}
module.exports={startFixture,openCompany2,labels,roots,button};
