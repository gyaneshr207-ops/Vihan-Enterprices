'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const {startFixture,openCompany2,labels,roots,button}=require('./helpers/company2-browser-harness');
let browser,fixture;
test.before(async()=>{fixture=await startFixture();browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']})});
test.after(async()=>{await browser?.close();await fixture?.close()});
async function state(page,label){return page.evaluate(({label,labels,roots})=>{
 const i=labels.indexOf(label),expected=roots[i],visible=e=>!!e&&e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true});
 const active=[...document.querySelectorAll('.page')].filter(visible).map(x=>x.id);
 const buttons=[...document.querySelectorAll('.sidebar .nav.active')];
 const panels=[...new Set(roots)].filter(id=>visible(document.getElementById(id)));
 return{active,panels,selected:buttons.map(x=>x.textContent.trim()),color:buttons[0]&&getComputedStyle(buttons[0]).backgroundColor,view:document.body.getAttribute('data-v843-view'),hasContent:!!document.getElementById(expected)?.querySelector('h2,h3,form,table'),blues:[...document.querySelectorAll('#c2InquiryRuntimeV150 .nav:not(.active)')].map(b=>getComputedStyle(b).backgroundColor)};
 },{label,labels,roots})}
async function check(page,label){await page.mouse.move(1420,10);try{await page.waitForFunction(()=>{const b=document.querySelector('#c2InquiryRuntimeV150 .nav.active');return b&&getComputedStyle(b).backgroundColor==='rgb(15, 159, 110)'&&Array.from(document.querySelectorAll('#c2InquiryRuntimeV150 .nav:not(.active)')).every(n=>getComputedStyle(n).backgroundColor==='rgb(53, 89, 219)')},{},{timeout:5000})}catch(e){console.error('Navigation state at failure',label,JSON.stringify(await state(page,label)));throw e}const s=await state(page,label);assert.deepEqual(s.selected,[label]);assert.deepEqual(s.panels,[roots[labels.indexOf(label)]]);assert.deepEqual(s.active,[labels.indexOf(label)>=6?roots[labels.indexOf(label)]:'companyHome']);assert.ok(s.hasContent);assert.equal(s.color,'rgb(15, 159, 110)');assert.ok(s.blues.every(x=>x==='rgb(53, 89, 219)'),'normal colors '+s.blues)}
for(let round=1;round<=Number(process.env.VIHAN_NAV_ROUNDS||10);round++)for(const role of ['admin','user'])test('all nine Company 2 modules: first click, all 81 transitions, rapid switching, '+role+', round '+round,async()=>{
 const {page,context,errors}=await openCompany2(browser,fixture,role);
 const fs=require('fs'),out=require('path').resolve(__dirname,'../reports/completion');
 const tracing=process.env.VIHAN_TRACE_NAV==='1';if(tracing)await context.tracing.start({screenshots:false,snapshots:true,sources:false});
 const cdp=tracing?await context.newCDPSession(page):null;if(cdp){await cdp.send('Profiler.enable');await cdp.send('Profiler.start')}
 await page.evaluate(()=>{window.__navTasks=[];new PerformanceObserver(list=>{for(const e of list.getEntries())window.__navTasks.push({start:e.startTime,duration:e.duration})}).observe({type:'longtask',buffered:true})});
 let failed=false;
 try{
  for(const label of labels){await button(page,label).click();await check(page,label)}
  for(const from of labels){await button(page,from).click();for(const to of labels){await button(page,to).click();await check(page,to);await button(page,from).click()}}
  await page.evaluate(labels=>{for(let round=0;round<3;round++)for(const label of labels){const b=[...document.querySelectorAll('#c2InquiryRuntimeV150 .nav')].find(b=>b.textContent.trim()===label);b.click()}},labels);
  await page.waitForTimeout(350);await check(page,'All Software');assert.deepEqual(errors,[]);
  await button(page,'Data Entry').click();await page.locator('#de673Form [name="name"]').fill('STRESS DRAFT '+role+' '+round);for(const l of labels){await button(page,l).click();await button(page,'Data Entry').click();assert.equal(await page.locator('#de673Form [name="name"]').inputValue(),'STRESS DRAFT '+role+' '+round)}
  if(role==='admin'){for(const l of labels){await button(page,l).click();await page.locator('.sidebar .nav').filter({hasText:'Admin Dashboard'}).click();assert.ok(await page.locator('#dashboard').isVisible());assert.equal(await page.locator('.sidebar .nav.active').count(),1);assert.equal(await page.locator('body').getAttribute('data-v843-view'),null);await page.evaluate(()=>viewCompany(getData().companies.find(c=>c.name==='Company 2').id));await button(page,l).waitFor()}}
 }catch(e){failed=true;throw e}finally{if(cdp){const {profile}=await cdp.send('Profiler.stop');fs.writeFileSync(out+'/profile-'+role+'-'+round+'.json',JSON.stringify(profile))}fs.writeFileSync(out+'/tasks-'+role+'-'+round+'.json',JSON.stringify(await page.evaluate(()=>({tasks:window.__navTasks,nodes:document.querySelectorAll('*').length,heap:performance.memory?.usedJSHeapSize}))));if(tracing)await context.tracing.stop(failed?{path:out+'/FAIL-'+role+'-'+round+'.zip'}:{});await context.close()}
});
