# Disposable GitHub-hosted Windows VM only. Refuses pre-existing Vihan identity/tasks.
param([Parameter(Mandatory=$true)][string]$OutputDirectory,[string]$InstallerPath,[string]$OldSource37,[string]$OldSource38)
$ErrorActionPreference='Stop'
if($env:OS -ne 'Windows_NT' -or $env:GITHUB_ACTIONS -ne 'true'){throw 'Only disposable GitHub Windows runner is supported by this unattended acceptance script'}
$Root=Split-Path $PSScriptRoot -Parent;$runtime=Join-Path $Root 'runtime'
$base=Join-Path $env:ProgramData 'Vihan Enterprices';$conn=Join-Path $env:APPDATA 'Vihan Enterprices\connection.json'
if((Test-Path $base) -or (Test-Path $conn) -or (Get-ScheduledTask -TaskName 'Vihan Enterprices*' -ErrorAction SilentlyContinue)){throw 'Existing installation detected: refusing unattended test'}
if(Test-Path $OutputDirectory){throw 'New report directory required'}
New-Item -ItemType Directory -Path $OutputDirectory|Out-Null
$results=New-Object Collections.ArrayList;$status='FAIL';$db=$null;$ca=$null;$cert=$null
function Pass([string]$Name){[void]$results.Add([pscustomobject]@{name=$Name;result='PASS'});Write-Output ('PASS '+$Name)}
function Check([bool]$Condition,[string]$Name){if(!$Condition){throw ('Acceptance assertion: '+$Name)};Pass $Name}
function Stop-TestServices(){foreach($t in @('Vihan Enterprices Main Service','Vihan Enterprices File Service')){Stop-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue};. (Join-Path $runtime 'StoragePaths.ps1');foreach($pair in @(@('service.pid','MainService.ps1'),@('file_service.pid','FileService.ps1'))){Stop-VihanTrackedService (Join-Path $base $pair[0]) (Join-Path $runtime $pair[1])}}
function Run-Worker([string]$Script){$child=Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$Script+'"'),'-Mode','Auto') -PassThru;if(!$child.WaitForExit(600000)){Stop-Process -Id $child.Id -Force;throw 'Installer worker exceeded ten minutes (possibly an interactive error)'};if($child.ExitCode -ne 0){throw 'Installer worker failed'};Get-Process -Name 'Vihan Enterprices' -ErrorAction SilentlyContinue|Stop-Process -Force}
function Run-Installer([string]$Exe,[string]$Directory){$child=Start-Process -FilePath $Exe -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART',('/DIR="'+$Directory+'"')) -PassThru;if(!$child.WaitForExit(600000)){Stop-Process -Id $child.Id -Force;throw 'Compiled installer exceeded ten minutes'};if($child.ExitCode -ne 0){throw ('Compiled installer failed exit '+$child.ExitCode)}}
function Repair(){& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $runtime 'RepairMainService.ps1') -NoPrompt;if($LASTEXITCODE -ne 0){throw 'Native Main/File repair/start failed'}}
function Request([string]$Url,[string]$Method='GET',$Body=$null,$Session=$null){$args=@{Uri=$Url;UseBasicParsing=$true;TimeoutSec=20;Method=$Method;Headers=@{'X-Vihan-Token'=$token}};if($Session){$args.WebSession=$Session};if($null -ne $Body){$args.Body=($Body|ConvertTo-Json -Depth 60 -Compress);$args.ContentType='application/json'};try{return Invoke-WebRequest @args}catch{$code=if($_.Exception.Response){[int]$_.Exception.Response.StatusCode}else{0};throw ('Native HTTP '+$Method+' '+([uri]$Url).AbsolutePath+' failed status '+$code)}}
function Login([string]$User,[string]$Type,[string]$Company){$session=New-Object Microsoft.PowerShell.Commands.WebRequestSession;[void](Request ($main+'/api/auth/login') 'POST' @{username=$User;password=$password;type=$Type;companyId=$Company} $session);return $session}
try{
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 & (Join-Path $PSScriptRoot 'WindowsNativeSmoke.ps1') -OutputDirectory ('D:\Vihan Native Smoke '+[guid]::NewGuid().ToString('N'))
 Pass 'Windows PowerShell 5.1, native winsqlite3 save/reopen/backup/Framework crypto'
 # The smoke script loads these native C# types in this process.
 $token=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N');$password=[guid]::NewGuid().ToString('N')+'!Aa'
 $testData='D:\Vihan Native Acceptance '+[guid]::NewGuid().ToString('N');$data=Join-Path $testData 'Data';$backup=Join-Path $testData 'Backups'
 New-Item -ItemType Directory -Force -Path $base,$data,$backup,(Split-Path $conn -Parent)|Out-Null
 $ip=Get-NetIPAddress -AddressFamily IPv4|Where-Object{$_.IPAddress -notmatch '^(127\.|169\.254\.)'}|Select-Object -First 1 -ExpandProperty IPAddress;if(!$ip){$ip='127.0.0.1'}
 $version=(Get-Content (Join-Path $Root 'manifest.json') -Raw|ConvertFrom-Json).appVersion
 $cfg=[pscustomobject]@{product='Vihan Enterprices';appVersion=$version;port=17867;filePort=17868;serverName=$env:COMPUTERNAME;serverIp=$ip;token=$token;dataDir=$data;backupDir=$backup;initializeDatabase=$true}
 $cfg|ConvertTo-Json|Set-Content (Join-Path $base 'server.json') -Encoding UTF8
 [pscustomobject]@{product=$cfg.product;appVersion=$version;port=17867;filePort=17868;serverName=$env:COMPUTERNAME;serverIp=$ip;token=$token;serverUrl='http://127.0.0.1:17867';serverIpUrl='http://127.0.0.1:17867'}|ConvertTo-Json|Set-Content $conn -Encoding UTF8
 Repair
 $cfg=Get-Content (Join-Path $base 'server.json') -Raw|ConvertFrom-Json;$main='http://127.0.0.1:'+ $cfg.port;$file='http://127.0.0.1:'+ $cfg.filePort
 Check (((Request ($main+'/health')).StatusCode -eq 200) -and ((Request ($file+'/health')).StatusCode -eq 200)) 'Actual native Main and File services started'
 foreach($taskName in @('Vihan Enterprices Main Service','Vihan Enterprices File Service')){$task=Get-ScheduledTask -TaskName $taskName;Check ($task.Principal.UserId -eq 'SYSTEM' -or $task.Principal.UserId -eq 'S-1-5-18') ('SYSTEM scheduled principal: '+$taskName)}
 $database=Join-Path $data 'VihanEnterprices.db';$db=New-Object VihanSqliteDb -ArgumentList $database
 $identity=@{studentCompanyId='c1';company2ModuleId='c2';companies=@(@{id='c1';name='Utopiya Library';active=$true;users=@(@{username='boss';password=$password;role='Admin';active=$true});records=@();students=@()},@{id='c2';name='Company 2';active=$true;users=@(@{username='clerk';password=$password;role='User';active=$true});records=@()})}
 $value=ConvertTo-Json -InputObject $identity -Depth 50 -Compress
 $db.Exec('INSERT INTO kv(key,value,key_rev,deleted) VALUES(''multiCompanyAdminV2'','+[VihanSqliteDb]::Quote($value)+',1,0);');$db.Dispose();$db=$null
 $a=Login 'clerk' 'user' 'c2';$b=Login 'clerk' 'user' 'c2';$admin=Login 'boss' 'admin' 'c1'
 $snap=(Request ($main+'/api/snapshot') 'GET' $null $a).Content|ConvertFrom-Json
 Check (!($snap|ConvertTo-Json -Depth 60 -Compress).Contains('password')) 'Native snapshots contain no account credential fields'
 $op=@{ops=@(@{key='company2_data_entry_v671';op='set';value='[{"id":"native-save","name":"Native client A save"}]';expectedRev=0;seq=1})}
 $save=(Request ($main+'/api/storage/batch') 'POST' $op $a).Content|ConvertFrom-Json;Check ($save.results[0].ok -eq $true) 'Client A committed save to native Main database'
 $view=(Request ($main+'/api/snapshot') 'GET' $null $b).Content|ConvertFrom-Json;Check ($view.items.company2_data_entry_v671.value.Contains('Native client A save')) 'Independent Client B session reload sees committed save'
 $op.ops[0].value=$view.items.company2_data_entry_v671.value.Replace('Native client A save','Native stale edit')
 $stale=(Request ($main+'/api/storage/batch') 'POST' $op $b).Content|ConvertFrom-Json;Check ($stale.results[0].conflict -eq $true) 'Stale concurrent client revision is rejected'
 [void](Request ($file+'/api/blob/put') 'POST' @{db='OfficeAllDocumentsV819';store='files';id='native-file';record=@{id='native-file';name='native.txt';type='text/plain'};blobBase64=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('Native attachment bytes'));blobType='text/plain'} $admin)
 $bytes=Request ($file+'/api/blob/file?db=OfficeAllDocumentsV819&store=files&id=native-file') 'GET' $null $a;Check ($bytes.Content -eq 'Native attachment bytes') 'Native dedicated File Service attachment upload/download'
 $bk=(Request ($file+'/api/backup') 'POST' @{} $admin).Content|ConvertFrom-Json
 Check ((Get-ChildItem $backup -Filter '*.zip').Count -gt 0) 'Actual native database and attachments backup created'
 if($InstallerPath -and $OldSource37 -and $OldSource38){
   Stop-TestServices
   foreach($entry in @(@($OldSource37,'1.0.37'),@($OldSource38,'1.0.38'))){
     Run-Worker (Join-Path $entry[0] 'installer\Install.ps1')
     $h=(Request ($main+'/health')).Content|ConvertFrom-Json;Check ($h.version -eq $entry[1]) ('Actual installed runtime '+$entry[1]+' starts')
     $read=New-Object VihanSqliteDb -ArgumentList $database
     try{Check ($read.ScalarText("SELECT value FROM kv WHERE key='company2_data_entry_v671'",'').Contains('Native client A save')) ('Installed '+$entry[1]+' retains existing business data')}finally{$read.Dispose()}
   }
   $wrapper='D:\Vihan Installer Wrapper '+[guid]::NewGuid().ToString('N')
   Run-Installer $InstallerPath $wrapper
   $installed=Get-Content 'D:\Vihan Enterprices\Software\installed_version.json' -Raw|ConvertFrom-Json
   Check ($installed.version -eq $version) 'Compiled installer upgrades existing installation to current version on intended D default'
   Run-Installer $InstallerPath $wrapper
   Pass 'Compiled installer reinstall completed with existing identity and paths'
   # Next native steps use the same code copied into D:\Software by the installer.
   $runtime='D:\Vihan Enterprices\Software\runtime'
 }
 Stop-TestServices;Repair
 $a=Login 'clerk' 'user' 'c2';$view=(Request ($main+'/api/snapshot') 'GET' $null $a).Content|ConvertFrom-Json
 Check ($view.items.company2_data_entry_v671.value.Contains('Native client A save')) 'Native services stop/restart preserves committed database'
 $san='2.5.29.17={text}DNS=localhost&DNS='+$env:COMPUTERNAME+'&IPAddress=127.0.0.1&IPAddress='+$ip
 $cert=New-SelfSignedCertificate -Type Custom -Subject 'CN=localhost' -KeyUsage DigitalSignature,KeyEncipherment -KeyExportPolicy NonExportable -CertStoreLocation 'Cert:\LocalMachine\My' -NotAfter (Get-Date).AddDays(30) -TextExtension @($san,'2.5.29.37={text}1.3.6.1.5.5.7.3.1','2.5.29.19={critical}{text}ca=0')
 $leafFile=Join-Path $testData 'test-trusted-leaf.cer';Export-Certificate -Cert $cert -FilePath $leafFile|Out-Null;Import-Certificate -FilePath $leafFile -CertStoreLocation 'Cert:\LocalMachine\Root'|Out-Null
 & (Join-Path $runtime 'ConfigureTls.ps1') -CertificateThumbprint $cert.Thumbprint -Apply
 $main='https://127.0.0.1:'+ $cfg.port;$file='https://127.0.0.1:'+ $cfg.filePort;$a=Login 'clerk' 'user' 'c2';$admin=Login 'boss' 'admin' 'c1'
 Check ($a.Cookies.GetCookies([uri]$main)['VE_SESSION'].Secure) 'Real HTTPS user-session cookie is Secure'
 $view=(Request ($main+'/api/snapshot') 'GET' $null $a).Content|ConvertFrom-Json;Check ($view.items.company2_data_entry_v671.value.Contains('Native client A save')) 'HTTPS native login and filtered snapshot with trusted CA'
 Check ((Request ($file+'/api/blob/file?db=OfficeAllDocumentsV819&store=files&id=native-file') 'GET' $null $a).Content -eq 'Native attachment bytes') 'HTTPS native File Service download with authenticated cookie'
 Check ((Request ($file+'/api/update/status') 'GET' $null $admin).StatusCode -eq 200) 'HTTPS native update-service status'
 $plaintextAccepted=$false;try{[void](Request ('http://127.0.0.1:'+$cfg.port+'/api/snapshot') 'GET' $null $a);$plaintextAccepted=$true}catch{};Check (!$plaintextAccepted) 'HTTP does not serve authenticated business data after TLS activation'
 Stop-TestServices
 $migration=Join-Path $testData 'Credential Candidate'
 & (Join-Path $runtime 'CredentialMigration.ps1') -SourceDatabase $database -OutputDirectory $migration -PrepareCopy
 $candidate=New-Object VihanSqliteDb -ArgumentList (Join-Path $migration 'VihanEnterprices.db');$safety=New-Object VihanSqliteDb -ArgumentList (Join-Path $migration 'before-credentials.db')
 try{$newRoot=$candidate.ScalarText("SELECT value FROM kv WHERE key='multiCompanyAdminV2'",'')|ConvertFrom-Json;$before=$safety.ScalarText("SELECT value FROM kv WHERE key='multiCompanyAdminV2'",'')|ConvertFrom-Json;foreach($c in $newRoot.companies){foreach($u in $c.users){Check ([VihanAuthCrypto]::Verify($password,[string]$u.passwordHash)) 'Migrated native fixture account login verification';Check (!$u.PSObject.Properties['password']) 'Migrated account has no plaintext password field'}};Check ($before.companies[0].users[0].password -eq $password) 'Restricted pre-migration safety copy supports credential rollback';Check ($candidate.ScalarText('PRAGMA integrity_check','') -eq 'ok') 'Migrated native database integrity'}finally{$candidate.Dispose();$safety.Dispose()}
 if($InstallerPath -and $wrapper){
   $uninstaller=Join-Path $wrapper 'unins000.exe'
   $child=Start-Process $uninstaller -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART') -PassThru
   if(!$child.WaitForExit(120000)){Stop-Process -Id $child.Id -Force;throw 'Uninstaller timeout'}
   Check ($child.ExitCode -eq 0 -and (Test-Path $database) -and (Test-Path (Join-Path $data 'Blobs'))) 'Actual compiled uninstall preserves database and attachments by default'
 }
 $status='PASS' 
}catch{[void]$results.Add([pscustomobject]@{name='Native acceptance execution';result='FAIL';error=($_.Exception.Message.Replace([string]$token,'[redacted]').Replace([string]$password,'[redacted]'))});Write-Output 'FAIL native acceptance; sanitized details in JSON report'}
finally{
 if($db){$db.Dispose()};try{Stop-TestServices}catch{}
 foreach($t in @('Vihan Enterprices Main Service','Vihan Enterprices File Service')){Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction SilentlyContinue}
 if($cert){Remove-Item ('Cert:\LocalMachine\Root\'+$cert.Thumbprint) -Force -ErrorAction SilentlyContinue;Remove-Item ('Cert:\LocalMachine\My\'+$cert.Thumbprint) -Force -ErrorAction SilentlyContinue};if($ca){Remove-Item ('Cert:\LocalMachine\My\'+$ca.Thumbprint) -Force -ErrorAction SilentlyContinue;Remove-Item ('Cert:\LocalMachine\Root\'+$ca.Thumbprint) -Force -ErrorAction SilentlyContinue}
 @{status=$status;os=[Environment]::OSVersion.VersionString;powerShell=$PSVersionTable.PSVersion.ToString();runner=$env:RUNNER_OS;runId=$env:GITHUB_RUN_ID;physicalTwoPc=$false;productionDataChanged=$false;results=@($results);notRun=@('Physical two-PC LAN','Interactive UAC/cancellation','Actual D-volume absent/read-only','Production activation')}|ConvertTo-Json -Depth 10|Set-Content (Join-Path $OutputDirectory 'windows-acceptance.json') -Encoding UTF8
}
if($status -ne 'PASS'){exit 1}
