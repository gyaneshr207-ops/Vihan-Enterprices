$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../runtime/Transport.ps1')
$c=[pscustomobject]@{port=17867;filePort=17868}
if((Get-VihanTransportScheme $c) -ne 'http'){throw 'Legacy compatibility changed'}
$c|Add-Member NoteProperty requireTls $true
try{Get-VihanTransportScheme $c;throw 'missing TLS accepted'}catch{if($_.Exception.Message -eq 'missing TLS accepted'){throw}}
$c|Add-Member NoteProperty tls ([pscustomobject]@{enabled=$true;certificateThumbprint=('A'*40)})
if((Get-VihanTransportScheme $c) -ne 'https'){throw 'TLS scheme'}
$ports=Get-VihanListenerPorts $c 17867 @(18080,8000);if($ports.Count -ne 1 -or $ports[0] -ne 17867){throw 'TLS port fallback forbidden'}
$c|Add-Member NoteProperty serverUrl 'http://localhost:17867'
try{Assert-VihanConnectionTransport $c;throw 'downgrade accepted'}catch{if($_.Exception.Message -eq 'downgrade accepted'){throw}}
$c.serverUrl='https://localhost:17867';Assert-VihanConnectionTransport $c
if((Get-VihanServiceOrigin $c '::1' 17867) -ne 'https://[::1]:17867'){throw 'IPv6 origin mismatch'}
$c.filePort=$c.port
try{Get-VihanTransportScheme $c;throw 'same TLS ports accepted'}catch{if($_.Exception.Message -eq 'same TLS ports accepted'){throw}}
Add-Type -Path (Join-Path $PSScriptRoot '../runtime/TlsCertificate.cs')
Write-Output 'PASS transport policy: legacy compatibility, fail-closed TLS, fixed ports, downgrade rejection, IPv6, native-compatible certificate parser compilation'
