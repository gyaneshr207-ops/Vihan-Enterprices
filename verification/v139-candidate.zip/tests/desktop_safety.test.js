'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../runtime/electron-app/main.js'),'utf8');
test('desktop refuses a wrong product, file service, offline server or failed health response',async()=>{
 const fragment=source.slice(source.indexOf('async function checkUrl('),source.indexOf('function isLocalMain('));let health;
 const sandbox={PRODUCT:'Vihan Enterprices',getHealth:async()=>health};vm.createContext(sandbox);vm.runInContext(fragment,sandbox);
 for(const response of [{ok:true,product:'Other App'},{ok:true,product:'Vihan Enterprices',service:'files'},{ok:true,product:'Vihan Enterprices',offline:true},null]){health=response;assert.equal(await sandbox.checkUrl('http://fixture'),false)}health={ok:true,product:'Vihan Enterprices'};assert.equal(await sandbox.checkUrl('http://fixture'),true);
});
for(const state of [{pending:2},null])test('auto update does not reload a client with '+(state?'pending saves':'unknown save state'),async()=>{
 const fragment=source.slice(source.indexOf('async function maybeAutoUpdate('),source.indexOf('function scheduleCentralUpdateChecks('));const events=[];
 const sandbox={autoUpdating:false,APP_VERSION:'1.0.37',localDiskVersion:()=> '1.0.37',versionCompare:(a,b)=>a.localeCompare(b),fileServiceBase:x=>x,tokenRequestJson:async()=>({latest:{version:'1.0.38',sha256:'0'.repeat(64)}}),isLocalMain:()=>false,heartbeatUpdateService:async(...args)=>events.push(args[2]),mainWindow:{isDestroyed:()=>false,webContents:{executeJavaScript:async()=>state},loadURL:async()=>{throw new Error('Must not reload')}},Promise,setTimeout:()=>0,console};vm.createContext(sandbox);vm.runInContext(fragment,sandbox);assert.equal(await sandbox.maybeAutoUpdate('http://fixture',{}),false);assert.equal(sandbox.autoUpdating,false);assert.ok(events.includes('update-waiting-for-pending-saves'));
});
