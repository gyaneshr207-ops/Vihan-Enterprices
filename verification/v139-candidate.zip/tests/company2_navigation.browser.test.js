'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const {startFixture,openCompany2,labels,roots,button}=require('./helpers/company2-browser-harness');
let browser,fixture;
test.before(async()=>{fixture=await startFixture();browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']})});
test.after(async()=>{await browser?.close();await fixture?.close()});
async function state(page,label){return page.evaluate(({label,labels,roots})=>{
 const i=labels.indexOf(label),expected=roots[i],visible=e=>!!e&&e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true});
 const active=[...document.querySelectorAll('.page')].filter(visible).map(x=>x.id);
 const buttons=[...document.querySelectorAll('.sidebar .nav.active')];
 const panels=[...new Set(roots)].filter(id=>visible(document.getElementById(id)));
 return{active,panels,selected:buttons.map(x=>x.textContent.trim()),color:buttons[0]&&getComputedStyle(buttons[0]).backgroundColor,view:document.body.getAttribute('data-v843-view'),hasContent:!!document.getElementById(expected)?.querySelector('h2,h3,form,table'),blues:[...document.querySelectorAll('#c2InquiryRuntimeV150 .nav:not(.active)')].map(b=>getComputedStyle(b).backgroundColor)};
 },{label,labels,roots})}
async function check(page,label){await page.mouse.move(1420,10);try{await page.waitForFunction(()=>{const b=document.querySelector('#c2InquiryRuntimeV150 .nav.active');return b&&getComputedStyle(b).backgroundColor==='rgb(15, 159, 110)'&&Array.from(document.querySelectorAll('#c2InquiryRuntimeV150 .nav:not(.active)')).every(n=>getComputedStyle(n).backgroundColor==='rgb(53, 89, 219)')},{},{timeout:5000})}catch(e){console.error('Navigation state at failure',label,JSON.stringify(await state(page,label)));throw e}const s=await state(page,label);assert.deepEqual(s.selected,[label]);assert.deepEqual(s.panels,[roots[labels.indexOf(label)]]);assert.deepEqual(s.active,[labels.indexOf(label)>=6?roots[labels.indexOf(label)]:'companyHome']);assert.ok(s.hasContent);assert.equal(s.color,'rgb(15, 159, 110)');assert.ok(s.blues.every(x=>x==='rgb(53, 89, 219)'),'normal colors '+s.blues)}
for(const role of ['admin','user'])test('all nine Company 2 modules: first click, all 81 transitions, rapid switching, '+role,async()=>{
 const {page,context,errors}=await openCompany2(browser,fixture,role);
 try{
  for(const label of labels){await button(page,label).click();await check(page,label)}
  for(const from of labels){await button(page,from).click();for(const to of labels){await button(page,to).click();await check(page,to);await button(page,from).click()}}
  await page.evaluate(labels=>{for(let round=0;round<3;round++)for(const label of labels){const b=[...document.querySelectorAll('#c2InquiryRuntimeV150 .nav')].find(b=>b.textContent.trim()===label);b.click()}},labels);
  await page.waitForTimeout(350);await check(page,'All Software');assert.deepEqual(errors,[]);
 }finally{await context.close()}
});
test('Admin Dashboard and Back to Admin from every Company 2 module clear isolation',async()=>{
 const {page,context,errors}=await openCompany2(browser,fixture);
 try{for(const label of labels){await button(page,label).click();await page.locator('.sidebar .nav').filter({hasText:'Admin Dashboard'}).click();assert.ok(await page.locator('#dashboard').isVisible());assert.equal(await page.locator('.sidebar .nav.active').count(),1);assert.equal(await page.locator('body').getAttribute('data-v843-view'),null);await page.evaluate(()=>viewCompany(getData().companies.find(c=>c.name==='Company 2').id));await button(page,label).waitFor()}
 await button(page,'All Documents').click();await page.locator('#backAdmin').click();assert.ok(await page.locator('#dashboard').isVisible());assert.deepEqual(errors,[]);
 }finally{await context.close()}
});
test('delayed Documents/Software loads cannot reopen an older page or override selection',async()=>{
 const {page,context,errors}=await openCompany2(browser,fixture);fixture.setListDelay(450);
 try{await page.evaluate(()=>{v1033Company2Navigate('All Documents');v1033Company2Navigate('Day Book');v1033Company2Navigate('All Software');v1033Company2Navigate('Inquiry Form')});await page.waitForTimeout(900);await check(page,'Inquiry Form');assert.deepEqual(errors,[])}finally{fixture.setListDelay(0);await context.close()}
});
test('a missing module or denied permission leaves previous page and selection usable',async()=>{
 const {page,context}=await openCompany2(browser,fixture);
 try{await button(page,'Inquiry Form').click();await page.evaluate(()=>{window.__originalPhoto=window.photo781Open;window.photo781Open=undefined});await button(page,'4×6 Photo').click();await check(page,'Inquiry Form');await page.evaluate(()=>window.photo781Open=window.__originalPhoto);
 }finally{await context.close()}
});

test('unsaved Data Entry survives Inquiry, Counter and dedicated pages without detaching the Inquiry report',async()=>{
 const {page,context,errors}=await openCompany2(browser,fixture);
 try{await button(page,'Data Entry').click();await page.locator('#de673Form [name="name"]').fill('Retained draft');
 for(const label of ['Inquiry Form','Counter Account File','All Documents','Inquiry Form','All Software']){await button(page,label).click();await button(page,'Data Entry').click();assert.equal(await page.locator('#de673Form [name="name"]').inputValue(),'Retained draft')}
 await button(page,'Inquiry Form').click();assert.ok(await page.locator('#c2InquiryListV154').isVisible());assert.equal(await page.locator('#c2InquiryListV154').count(),1);assert.deepEqual(errors,[]);
 }finally{await context.close()}
});
test('failed module open restores a parked draft and preserves the selected page',async()=>{
 const {page,context}=await openCompany2(browser,fixture);
 try{await button(page,'Data Entry').click();await page.locator('#de673Form [name="name"]').fill('Error-safe draft');await page.evaluate(()=>{window.__savedBank=c2ShowBankBookV626;window.c2ShowBankBookV626=()=>{throw new Error('Injected module failure')}});await button(page,'Bank Book').click();assert.equal(await page.locator('#de673Form [name="name"]').inputValue(),'Error-safe draft');await check(page,'Data Entry');await page.evaluate(()=>window.c2ShowBankBookV626=window.__savedBank);
 }finally{await context.close()}
});
test('saved user permissions cannot be bypassed by sidebar or programmatic navigation',async()=>{
 const {page,context,errors}=await openCompany2(browser,fixture,'user');
 try{await page.evaluate(()=>{localStorage.setItem('company2_user_role_permissions_v408',JSON.stringify({user:{c2InquiryAccess:true}}));db609ApplyCompany2MainModulePermissions();v1033Company2Navigate('Inquiry Form')});await check(page,'Inquiry Form');await page.evaluate(()=>v1033Company2Navigate('All Documents'));await check(page,'Inquiry Form');await button(page,'All Documents').evaluate(b=>b.click());await check(page,'Inquiry Form');assert.deepEqual(errors,[]);
 }finally{await context.close()}
});
test('independent Main/Client browser sessions share the fixture data and navigation behavior',async()=>{
 const main=await openCompany2(browser,fixture),client=await openCompany2(browser,fixture);
 try{await button(main.page,'Data Entry').click();await main.page.locator('#de673Form [name="name"]').fill('Main draft');for(const label of labels){await button(client.page,label).click();await check(client.page,label)}assert.equal(await main.page.locator('#de673Form [name="name"]').inputValue(),'Main draft');
 await main.page.evaluate(()=>c2SetInquiriesV154([{id:'MAIN-CLIENT-TEST',name:'Shared inquiry',status:'Pending',date:'2026-10-20'}]));
 assert.equal(await main.page.evaluate(()=>vihanWaitForSaved()),true);
 await client.page.waitForFunction(()=>c2GetInquiriesV154().some(x=>x.id==='MAIN-CLIENT-TEST'),null,{timeout:9000});
 await button(client.page,'Inquiry Form').click();assert.ok((await client.page.locator('#c2InquiryRowsV154').innerText()).includes('Shared inquiry'));
 await button(main.page,'All Software').click();await button(main.page,'Data Entry').click();assert.equal(await main.page.locator('#de673Form [name="name"]').inputValue(),'Main draft');assert.deepEqual(main.errors,[]);assert.deepEqual(client.errors,[]);
 }finally{await main.context.close();await client.context.close()}
});
