'use strict';
const tls=require('tls');
function requiresTls(config){return config?.requireTls===true||config?.tls?.enabled===true||[config?.serverUrl,config?.serverIpUrl].some(x=>typeof x==='string'&&x.startsWith('https:'))}
function scheme(config){return requiresTls(config)?'https':'http'}
function origin(config,host,port){if(!host||/[\s/@?#\\]/.test(String(host)))throw new Error('Invalid Main host');const h=String(host).includes(':')&&!String(host).startsWith('[')?'['+host+']':host;return `${scheme(config)}://${h}:${port}`}
function assertUrl(url,config){const u=new URL(url);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw new Error('Invalid service URL');if(requiresTls(config)&&u.protocol!=='https:')throw new Error('TLS required: refusing HTTP downgrade');return u}
function requestOptions(url,config={}){
 const u=assertUrl(url,config);if(u.protocol!=='https:')return {};
 // OS enterprise roots supplement Node's normal/extra roots. SAN, expiry and
 // chain validation remain the standard TLS verifier; no permissive callback.
 const ca=typeof tls.getCACertificates==='function'?[...new Set([...tls.getCACertificates('default'),...tls.getCACertificates('system')])]:undefined;
 return {minVersion:'TLSv1.2',rejectUnauthorized:true,...(ca?.length?{ca}:{})};
}
module.exports={requiresTls,scheme,origin,assertUrl,requestOptions};
