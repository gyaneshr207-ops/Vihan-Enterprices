$ErrorActionPreference='Stop'
$Product='Vihan Enterprices'
$server=Join-Path (Join-Path $env:ProgramData $Product) 'server.json'
if(Test-Path $server){
  # Main role and master identity must never be erased by a Client reset tool.
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'RepairMainService.ps1') -NoPrompt
  exit $LASTEXITCODE
}
# FirstSetup -ClientOnly replaces the connection only after a valid service file
# is selected. Cancel leaves the existing working connection intact.
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'FirstSetup.ps1') -ClientOnly
exit $LASTEXITCODE
