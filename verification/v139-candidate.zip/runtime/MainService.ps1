param([int]$Port=17867)
$ErrorActionPreference='Stop'
trap {try{$errorRoot=Join-Path $env:ProgramData 'Vihan Enterprices';New-Item -ItemType Directory -Force -Path $errorRoot|Out-Null;Set-Content -LiteralPath (Join-Path $errorRoot 'service_error.txt') -Value $_.Exception.ToString() -Encoding UTF8}catch{};exit 4}
$Product='Vihan Enterprices'; $AppVersion='1.0.39'
$InstallRoot=Split-Path $PSScriptRoot -Parent
$AppRoot=Join-Path $InstallRoot 'app'
$Base=Join-Path $env:ProgramData 'Vihan Enterprices'
$OldDataDir=Join-Path $Base 'Data'
$DBase='D:\Vihan Enterprices'
$DataDir=Join-Path $DBase 'Data'; $BlobDir=Join-Path $DataDir 'Blobs'
$FallbackBackupDir=Join-Path $Base 'Backups'; $PreferredBackupDir=Join-Path $DBase 'Backups'
$ConfigFile=Join-Path $Base 'server.json'; $DbFile=Join-Path $DataDir 'VihanEnterprices.db'; $LegacyStateFile=Join-Path $DataDir 'storage.json'; $LegacyWalFile=Join-Path $DataDir 'storage.wal'; $LegacyBlobMetaFile=Join-Path $DataDir 'blobmeta.json'; $PidFile=Join-Path $Base 'service.pid'; $UpdateDir=Join-Path $DBase 'Updates'; $UpdateStateFile=Join-Path $UpdateDir 'latest.json'; $UpdateClientsFile=Join-Path $UpdateDir 'clients.json'
if(!(Test-Path 'D:\')){
  New-Item -ItemType Directory -Force -Path $Base | Out-Null
  Set-Content (Join-Path $Base 'service_error.txt') 'Main PC D: drive available nahi hai. Vihan Enterprices central data D:\Vihan Enterprices\Data me rakha gaya hai.' -Encoding UTF8
  exit 5
}
New-Item -ItemType Directory -Force -Path $Base,$UpdateDir | Out-Null
if(!(Test-Path $ConfigFile)){exit 2}
$config=Get-Content $ConfigFile -Raw | ConvertFrom-Json
$Token=[string]$config.token
if($config.port){$Port=[int]$config.port}
$AdminSecretFile=Join-Path $Base 'restore-admin.key'
if(!(Test-Path $AdminSecretFile)){
  $rng=[Security.Cryptography.RandomNumberGenerator]::Create();$bytes=New-Object byte[] 32
  try{$rng.GetBytes($bytes)}finally{$rng.Dispose()}
  $secret=[Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
  [IO.File]::WriteAllText($AdminSecretFile,$secret,[Text.Encoding]::ASCII)
  try{& icacls.exe $AdminSecretFile /inheritance:r /grant:r 'SYSTEM:F' 'Administrators:F' | Out-Null}catch{}
}
$RestoreAdminSecret=[IO.File]::ReadAllText($AdminSecretFile).Trim()


. (Join-Path $PSScriptRoot 'StoragePaths.ps1')
. (Join-Path $PSScriptRoot 'Transport.ps1')
$TransportScheme=Get-VihanTransportScheme $config
$paths=Get-VihanStoragePaths $config
$DataDir=$paths.Data;$BlobDir=$paths.Blobs;$DbFile=$paths.Database;$PreferredBackupDir=$paths.Backup
$LegacyStateFile=Join-Path $DataDir 'storage.json';$LegacyWalFile=Join-Path $DataDir 'storage.wal';$LegacyBlobMetaFile=Join-Path $DataDir 'blobmeta.json'
$allowCreate=Assert-VihanDatabaseStart $config $DbFile $OldDataDir
New-Item -ItemType Directory -Force -Path $DataDir,$BlobDir|Out-Null
function Resolve-BackupDir(){
  $candidate=$paths.Backup
  if(!(Test-Path ([IO.Path]::GetPathRoot($candidate)))){throw "Configured backup drive is unavailable: $candidate"}
  New-Item -ItemType Directory -Force -Path $candidate|Out-Null
  return $candidate
}
$BackupDir=Resolve-BackupDir
$created=$false; $mutex=New-Object System.Threading.Mutex($true,'Global\VihanEnterpricesMainService',[ref]$created); if(!$created){exit 0}
Set-Content -Path $PidFile -Value $PID -Encoding ASCII

try{
  $bridge=Join-Path $PSScriptRoot 'VihanSqlite.cs'
  if(!(Test-Path $bridge)){throw "SQLite bridge missing: $bridge"}
  if(-not ('VihanSqliteDb' -as [type])){Add-Type -Path $bridge}
  $db=New-Object -TypeName VihanSqliteDb -ArgumentList $DbFile,$allowCreate
  if($db.ScalarText("PRAGMA quick_check",'') -ne 'ok'){throw 'SQLite integrity check failed; service startup stopped'}
$config=Update-VihanServerConfig $ConfigFile @{initializeDatabase=$false}
}catch{
  Set-Content (Join-Path $Base 'service_error.txt') ("SQLite start error:`r`n"+$_.Exception.ToString()) -Encoding UTF8
  try{$mutex.ReleaseMutex();$mutex.Dispose()}catch{}
  Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
  exit 4
}

function Q([object]$s){if($null -eq $s){return 'NULL'};return [VihanSqliteDb]::Quote([string]$s)}
function B([object]$v){if([bool]$v){return 1};return 0}
function Get-Revision(){return [int64]$db.ScalarLong("SELECT CAST(v AS INTEGER) FROM meta WHERE k='revision'",0)}
function Row-Record($r){if(!$r){return $null};return [pscustomobject]@{value=[string]$r['value'];deleted=([int]$r['deleted'] -ne 0);keyRev=[int64]$r['key_rev'];updatedAt=[string]$r['updated_at'];clientId=[string]$r['client_id']}}
function Get-CurrentRecord([string]$key){$rows=$db.Query("SELECT value,deleted,key_rev,updated_at,client_id,revision FROM kv WHERE key="+(Q $key)+" LIMIT 1");if($rows.Count -eq 0){return $null};return (Row-Record $rows[0])}

if($db.ScalarLong("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='meta'",0) -gt 0 -and $db.ScalarLong("SELECT CAST(v AS INTEGER) FROM meta WHERE k='schema_version'",0) -gt 2){throw 'Unsupported newer database schema; no downgrade or reset performed'}
$db.Exec(@"
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT NOT NULL);
INSERT OR IGNORE INTO meta(k,v) VALUES('revision','0');
CREATE TABLE IF NOT EXISTS kv(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT '',
  deleted INTEGER NOT NULL DEFAULT 0,
  key_rev INTEGER NOT NULL DEFAULT 0,
  revision INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT,
  client_id TEXT
);
CREATE TABLE IF NOT EXISTS changes(
  revision INTEGER PRIMARY KEY,
  key TEXT NOT NULL,
  value TEXT NOT NULL DEFAULT '',
  deleted INTEGER NOT NULL DEFAULT 0,
  key_rev INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT,
  client_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_changes_key ON changes(key);
CREATE TABLE IF NOT EXISTS blob_meta(
  blob_key TEXT PRIMARY KEY,
  db_name TEXT NOT NULL,
  store_name TEXT NOT NULL,
  item_id TEXT NOT NULL,
  record_json TEXT NOT NULL,
  blob_file TEXT,
  blob_type TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_blob_store ON blob_meta(db_name,store_name);
CREATE INDEX IF NOT EXISTS idx_blob_store_updated ON blob_meta(db_name,store_name,updated_at);
"@)

function Import-LegacyIfNeeded(){
  $done=$db.ScalarText("SELECT v FROM meta WHERE k='legacy_migrated'",'')
  if($done -eq '1'){return}
  $count=$db.ScalarLong('SELECT COUNT(*) FROM kv',0)
  if($count -gt 0){$db.Exec("INSERT OR REPLACE INTO meta(k,v) VALUES('legacy_migrated','1')");return}
  if(!(Test-Path $LegacyStateFile)){
    $db.Exec("INSERT OR REPLACE INTO meta(k,v) VALUES('legacy_migrated','1')")
    return
  }
  $legacyItems=@{};$legacyChanges=@();$legacyRevision=[int64]0
  try{
    $s=Get-Content $LegacyStateFile -Raw | ConvertFrom-Json
    $legacyRevision=[int64]$s.revision
    if($s.items){foreach($p in $s.items.psobject.Properties){$legacyItems[$p.Name]=$p.Value}}
    if($s.changes){$legacyChanges=@($s.changes)}
  }catch{throw "Purana storage.json read nahi hua: $($_.Exception.Message)"}
  if(Test-Path $LegacyWalFile){
    try{
      foreach($line in [IO.File]::ReadLines($LegacyWalFile)){
        if([string]::IsNullOrWhiteSpace($line)){continue}
        try{
          $r=$line|ConvertFrom-Json
          foreach($ch in @($r.changes)){
            if([int64]$ch.revision -le $legacyRevision){continue}
            $legacyItems[[string]$ch.key]=[pscustomobject]@{value=[string]$ch.value;deleted=[bool]$ch.deleted;keyRev=[int64]$ch.keyRev;updatedAt=[string]$ch.updatedAt;clientId=[string]$ch.clientId}
            $legacyChanges+=,$ch
            if([int64]$ch.revision -gt $legacyRevision){$legacyRevision=[int64]$ch.revision}
          }
        }catch{}
      }
    }catch{}
  }
  $db.Exec('BEGIN IMMEDIATE;')
  try{
    foreach($k in $legacyItems.Keys){
      $r=$legacyItems[$k]
      $rev=[int64]0
      if($r.PSObject.Properties['revision']){$rev=[int64]$r.revision}
      if($rev -eq 0){$hit=@($legacyChanges|Where-Object{[string]$_.key -eq [string]$k}|Sort-Object {[int64]$_.revision} -Descending|Select-Object -First 1);if($hit.Count){$rev=[int64]$hit[0].revision}}
      $sql="INSERT OR REPLACE INTO kv(key,value,deleted,key_rev,revision,updated_at,client_id) VALUES("+(Q $k)+","+(Q ([string]$r.value))+","+(B $r.deleted)+","+[int64]$r.keyRev+","+$rev+","+(Q ([string]$r.updatedAt))+","+(Q ([string]$r.clientId))+");"
      $db.Exec($sql)
    }
    foreach($ch in @($legacyChanges|Sort-Object {[int64]$_.revision}|Select-Object -Last 5000)){
      $sql="INSERT OR REPLACE INTO changes(revision,key,value,deleted,key_rev,updated_at,client_id) VALUES("+[int64]$ch.revision+","+(Q ([string]$ch.key))+","+(Q ([string]$ch.value))+","+(B $ch.deleted)+","+[int64]$ch.keyRev+","+(Q ([string]$ch.updatedAt))+","+(Q ([string]$ch.clientId))+");"
      $db.Exec($sql)
    }
    $db.Exec("INSERT OR REPLACE INTO meta(k,v) VALUES('revision',"+(Q ([string]$legacyRevision))+");")
    $db.Exec("INSERT OR REPLACE INTO meta(k,v) VALUES('legacy_migrated','1');")
    $db.Exec('COMMIT;')
  }catch{try{$db.Exec('ROLLBACK;')}catch{};throw}

  if((Test-Path $LegacyBlobMetaFile) -and ($db.ScalarLong('SELECT COUNT(*) FROM blob_meta',0) -eq 0)){
    try{
      $bm=Get-Content $LegacyBlobMetaFile -Raw|ConvertFrom-Json
      if($bm.items){
        $db.Exec('BEGIN IMMEDIATE;')
        try{
          foreach($p in $bm.items.psobject.Properties){
            $x=$p.Value;$recJson=($x.record|ConvertTo-Json -Depth 100 -Compress)
            $sql="INSERT OR REPLACE INTO blob_meta(blob_key,db_name,store_name,item_id,record_json,blob_file,blob_type,updated_at) VALUES("+(Q $p.Name)+","+(Q ([string]$x.db))+","+(Q ([string]$x.store))+","+(Q ([string]$x.id))+","+(Q $recJson)+","+(Q ([string]$x.blobFile))+","+(Q ([string]$x.blobType))+","+(Q ([string]$x.updatedAt))+");"
            $db.Exec($sql)
          }
          $db.Exec('COMMIT;')
        }catch{try{$db.Exec('ROLLBACK;')}catch{};throw}
      }
    }catch{}
  }
}
Import-LegacyIfNeeded
function Import-LegacyBlobIfNeeded(){
  if(!(Test-Path $LegacyBlobMetaFile)){return}
  if($db.ScalarLong('SELECT COUNT(*) FROM blob_meta',0) -gt 0){return}
  try{
    $bm=Get-Content $LegacyBlobMetaFile -Raw|ConvertFrom-Json
    if(!$bm.items){return}
    $db.Exec('BEGIN IMMEDIATE;')
    try{
      foreach($p in $bm.items.psobject.Properties){
        $x=$p.Value;$recJson=($x.record|ConvertTo-Json -Depth 100 -Compress)
        $sql="INSERT OR REPLACE INTO blob_meta(blob_key,db_name,store_name,item_id,record_json,blob_file,blob_type,updated_at) VALUES("+(Q $p.Name)+","+(Q ([string]$x.db))+","+(Q ([string]$x.store))+","+(Q ([string]$x.id))+","+(Q $recJson)+","+(Q ([string]$x.blobFile))+","+(Q ([string]$x.blobType))+","+(Q ([string]$x.updatedAt))+");"
        $db.Exec($sql)
      }
      $db.Exec('COMMIT;')
    }catch{try{$db.Exec('ROLLBACK;')}catch{};throw}
  }catch{}
}
Import-LegacyBlobIfNeeded
$db.Exec("INSERT OR REPLACE INTO meta(k,v) VALUES('schema_version','2');")

function Send-Bytes($ctx,[byte[]]$bytes,$type='application/octet-stream',$status=200){$ctx.Response.StatusCode=$status;$ctx.Response.ContentType=$type;$ctx.Response.ContentLength64=$bytes.Length;$ctx.Response.OutputStream.Write($bytes,0,$bytes.Length);$ctx.Response.OutputStream.Close()}
function Send-Text($ctx,$text,$type='text/plain; charset=utf-8',$status=200){$b=[Text.Encoding]::UTF8.GetBytes([string]$text);Send-Bytes $ctx $b $type $status}
function Send-Json($ctx,$obj,$status=200){$json=$obj|ConvertTo-Json -Depth 100 -Compress;Send-Text $ctx $json 'application/json; charset=utf-8' $status}
function Read-Body($ctx){$r=New-Object IO.StreamReader($ctx.Request.InputStream,$ctx.Request.ContentEncoding);$s=$r.ReadToEnd();$r.Close();if([string]::IsNullOrWhiteSpace($s)){return $null};return $s|ConvertFrom-Json}
function Read-ExactBytes([IO.Stream]$stream,[int]$count){
  if($count -lt 0 -or $count -gt 8388608){throw 'Invalid binary header length.'}
  $buf=New-Object byte[] $count;$off=0
  while($off -lt $count){$n=$stream.Read($buf,$off,$count-$off);if($n -le 0){throw 'Binary request incomplete.'};$off+=$n}
  return $buf
}
function Save-StreamToFile([IO.Stream]$stream,[string]$path){
  $dir=[IO.Path]::GetDirectoryName($path);if($dir){New-Item -ItemType Directory -Force -Path $dir|Out-Null}
  $fs=[IO.File]::Open($path,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try{$buf=New-Object byte[] 1048576;while(($n=$stream.Read($buf,0,$buf.Length)) -gt 0){$fs.Write($buf,0,$n)};$fs.Flush($true)}finally{$fs.Dispose()}
}
function Send-FileStream($ctx,[string]$path,[string]$type='application/octet-stream'){
  if(!(Test-Path $path)){Send-Json $ctx ([pscustomobject]@{error='File not found'}) 404;return}
  $fi=Get-Item -LiteralPath $path;$ctx.Response.StatusCode=200;$ctx.Response.ContentType=if([string]::IsNullOrWhiteSpace($type)){'application/octet-stream'}else{$type};$ctx.Response.ContentLength64=$fi.Length;$ctx.Response.SendChunked=$false
  $fs=[IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
  try{$buf=New-Object byte[] 1048576;while(($n=$fs.Read($buf,0,$buf.Length)) -gt 0){$ctx.Response.OutputStream.Write($buf,0,$n)}}finally{$fs.Dispose();$ctx.Response.OutputStream.Close()}
}
function Authorized($ctx){$c=$ctx.Request.Cookies['VE_AUTH'];$h=[string]$ctx.Request.Headers['X-Vihan-Token'];return (($c -and $c.Value -ceq $Token) -or ($h -ceq $Token))}
function Safe-Static($ctx,$rel){$rel=$rel.Replace('/','\').TrimStart('\');$full=[IO.Path]::GetFullPath((Join-Path $AppRoot $rel));$root=[IO.Path]::GetFullPath($AppRoot).TrimEnd('\')+'\';if(!$full.StartsWith($root,[StringComparison]::OrdinalIgnoreCase) -or !(Test-Path $full)){Send-Text $ctx 'Not Found' 'text/plain' 404;return};$ext=[IO.Path]::GetExtension($full).ToLowerInvariant();$types=@{'.html'='text/html; charset=utf-8';'.js'='application/javascript; charset=utf-8';'.css'='text/css; charset=utf-8';'.json'='application/json; charset=utf-8';'.png'='image/png';'.jpg'='image/jpeg';'.jpeg'='image/jpeg';'.svg'='image/svg+xml';'.ico'='image/x-icon'};$type=$types[$ext];if(!$type){$type='application/octet-stream'};Send-Bytes $ctx ([IO.File]::ReadAllBytes($full)) $type 200}

function Read-UpdateState(){
  if(!(Test-Path $UpdateStateFile)){return [pscustomobject]@{available=$false;version=$AppVersion}}
  try{return Get-Content $UpdateStateFile -Raw|ConvertFrom-Json}catch{return [pscustomobject]@{available=$false;version=$AppVersion}}
}
function Read-UpdateClients(){
  if(!(Test-Path $UpdateClientsFile)){return @()}
  try{$x=Get-Content $UpdateClientsFile -Raw|ConvertFrom-Json;return @($x.clients)}catch{return @()}
}

function Hash-Key($s){$sha=[Security.Cryptography.SHA256]::Create();try{$b=[Text.Encoding]::UTF8.GetBytes($s);return -join ($sha.ComputeHash($b)|ForEach-Object{$_.ToString('x2')})}finally{$sha.Dispose()}}
function Blob-Key($dbName,$store,$id){return ([string]$dbName)+'|'+([string]$store)+'|'+([string]$id)}

# ---- v1.0.35 Offline copy permission: which Client PCs may keep an offline read-only copy ----
# Default is DENY. Only PCs switched ON in offline-clients.json (admin page /app/offline-admin.html) receive data.
$OfflineClientsFile=Join-Path $Base 'offline-clients.json'
function Read-OfflineClients(){
  if(!(Test-Path $OfflineClientsFile)){return @()}
  try{$x=Get-Content $OfflineClientsFile -Raw|ConvertFrom-Json;return @($x.clients)}catch{return @()}
}
function Test-OfflineAllowed([string]$pc){
  if([string]::IsNullOrWhiteSpace($pc)){return $false}
  foreach($c in @(Read-OfflineClients)){if(([string]$c.pcName).ToLowerInvariant() -eq $pc.Trim().ToLowerInvariant()){return ($c.allowed -eq $true)}}
  return $false
}
function Save-OfflineClient([string]$pc,[bool]$allowed){
  $pc=$pc.Trim();$out=@()
  foreach($c in @(Read-OfflineClients)){if(([string]$c.pcName).ToLowerInvariant() -ne $pc.ToLowerInvariant()){$out+=,$c}}
  $out+=,([pscustomobject]@{pcName=$pc;allowed=$allowed;updatedAt=(Get-Date).ToString('o')})
  $tmp=$OfflineClientsFile+'.tmp'
  ([pscustomobject]@{clients=@($out)}|ConvertTo-Json -Depth 6)|Set-Content -Encoding UTF8 $tmp
  Move-Item -LiteralPath $tmp -Destination $OfflineClientsFile -Force
}
# True only when the HTTP request really comes from this (Main) PC itself. LAN clients can never pass this.
function Test-LocalRequest($req){
  try{
    $ra=$req.RemoteEndPoint.Address
    if($null -eq $ra){return $false}
    if([Net.IPAddress]::IsLoopback($ra)){return $true}
    if($ra.IsIPv4MappedToIPv6){$v4=$ra.MapToIPv4();if([Net.IPAddress]::IsLoopback($v4)){return $true};$ra=$v4}
    foreach($ip in [Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName())){if($ip.Equals($ra)){return $true}}
  }catch{}
  return $false
}

function Plan-Ops($ops,$clientId){
  $results=@();$planned=@();$pendingRecords=@{};$nextRevision=Get-Revision
  foreach($op in @($ops)){
    if($null -eq $op){continue};$key=[string]$op.key;if([string]::IsNullOrWhiteSpace($key)){continue}
    $cur=if($pendingRecords.ContainsKey($key)){$pendingRecords[$key]}else{Get-CurrentRecord $key};$curRev=if($cur){[int64]$cur.keyRev}else{0};$expected=[int64]$op.expectedRev;$seq=[int64]$op.seq
    if($expected -ne $curRev){$results+=,[pscustomobject]@{key=$key;seq=$seq;ok=$false;conflict=$true;current=$cur;revision=(Get-Revision)};continue}
    $nextRevision++
    $isRemove=([string]$op.op -eq 'remove');$newKeyRev=$curRev+1;$newValue=if($isRemove){''}else{[string]$op.value}
    $ch=[pscustomobject]@{revision=$nextRevision;key=$key;value=$newValue;deleted=$isRemove;keyRev=$newKeyRev;updatedAt=(Get-Date).ToString('o');clientId=[string]$clientId}
    $pendingRecords[$key]=$ch;$planned+=,$ch;$results+=,[pscustomobject]@{key=$key;seq=$seq;ok=$true;conflict=$false;keyRev=$newKeyRev;revision=$nextRevision}
  }
  return [pscustomobject]@{planned=$planned;results=$results;revision=$nextRevision}
}
function Commit-Plan($plan){
  $changes=@($plan.planned);if($changes.Count -eq 0){return}
  # Fast SQLite group commit: build one transaction and cross the PowerShell/C# boundary only once.
  # synchronous=FULL remains enabled, so acknowledged saves still get durable SQLite commit semantics.
  $sb=New-Object Text.StringBuilder
  [void]$sb.AppendLine('BEGIN IMMEDIATE;')
  foreach($ch in $changes){
    [void]$sb.AppendLine("INSERT OR REPLACE INTO kv(key,value,deleted,key_rev,revision,updated_at,client_id) VALUES("+(Q $ch.key)+","+(Q $ch.value)+","+(B $ch.deleted)+","+[int64]$ch.keyRev+","+[int64]$ch.revision+","+(Q $ch.updatedAt)+","+(Q $ch.clientId)+");")
    [void]$sb.AppendLine("INSERT OR REPLACE INTO changes(revision,key,value,deleted,key_rev,updated_at,client_id) VALUES("+[int64]$ch.revision+","+(Q $ch.key)+","+(Q $ch.value)+","+(B $ch.deleted)+","+[int64]$ch.keyRev+","+(Q $ch.updatedAt)+","+(Q $ch.clientId)+");")
  }
  [void]$sb.AppendLine("INSERT OR REPLACE INTO meta(k,v) VALUES('revision',"+(Q ([string][int64]$plan.revision))+");")
  # Pruning on every entry causes extra disk work. Keep the same 5000-change window, but prune only periodically.
  if(([int64]$plan.revision % 100) -eq 0){[void]$sb.AppendLine('DELETE FROM changes WHERE revision < (SELECT COALESCE(MAX(revision),0)-4999 FROM changes);')}
  [void]$sb.AppendLine('COMMIT;')
  $db.Exec($sb.ToString())
}
function Get-Snapshot(){
  $snap=@{};$kr=@{}
  foreach($r in $db.Query('SELECT key,value,deleted,key_rev,revision,updated_at,client_id FROM kv')){
    $k=[string]$r['key'];$rec=[pscustomobject]@{value=[string]$r['value'];deleted=([int]$r['deleted'] -ne 0);keyRev=[int64]$r['key_rev'];updatedAt=[string]$r['updated_at'];clientId=[string]$r['client_id']};$snap[$k]=$rec;$kr[$k]=[int64]$r['key_rev']
  }
  return [pscustomobject]@{revision=(Get-Revision);items=[pscustomobject]$snap;keyRevs=[pscustomobject]$kr}
}
function Get-ChangesSince([int64]$since){
  $rev=Get-Revision;$oldest=$db.ScalarLong('SELECT COALESCE(MIN(revision),0) FROM changes',0)
  if($oldest -eq 0){$oldest=$rev}
  if($since -lt ($oldest-1)){return [pscustomobject]@{full=$true;revision=$rev;items=(Get-Snapshot).items}}
  $arr=@();foreach($r in $db.Query('SELECT revision,key,value,deleted,key_rev,updated_at,client_id FROM changes WHERE revision > '+$since+' ORDER BY revision')){$arr+=,[pscustomobject]@{revision=[int64]$r['revision'];key=[string]$r['key'];value=[string]$r['value'];deleted=([int]$r['deleted'] -ne 0);keyRev=[int64]$r['key_rev'];updatedAt=[string]$r['updated_at'];clientId=[string]$r['client_id']}}
  return [pscustomobject]@{full=$false;revision=$rev;changes=$arr}
}
function Make-Backup(){
  $stamp=(Get-Date -Format 'yyyy-MM-dd_HH-mm-ss')+'_'+[guid]::NewGuid().ToString('N');$stage=Join-Path $env:TEMP ('VihanBackup_'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $stage|Out-Null
  try{
    $db.BackupTo((Join-Path $stage 'VihanEnterprices.db'))
    if(Test-Path $BlobDir){Copy-Item $BlobDir -Destination (Join-Path $stage 'Blobs') -Recurse -Force}
    $manifest=[pscustomobject]@{product=$Product;appVersion=$AppVersion;createdAt=(Get-Date).ToString('o');server=$env:COMPUTERNAME;persistence='SQLite';database='VihanEnterprices.db'}
    $manifest|ConvertTo-Json -Depth 20|Set-Content -Encoding UTF8 (Join-Path $stage 'backup_manifest.json')
    Add-Type -AssemblyName System.IO.Compression.FileSystem;$zip=Join-Path $BackupDir ('Vihan_Enterprices_Backup_'+$stamp+'.zip');[IO.Compression.ZipFile]::CreateFromDirectory($stage,$zip,[IO.Compression.CompressionLevel]::Optimal,$false)
    Get-ChildItem $BackupDir -Filter '*.zip'|Sort-Object LastWriteTime -Descending|Select-Object -Skip 30|Remove-Item -Force -ErrorAction SilentlyContinue
    return $zip
  }finally{Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue}
}

# Resolve a permitted TCP listener; preserve the actual bound port in server.json.
$bound=$false;$bindErrors=@()
foreach($candidate in (Get-VihanListenerPorts $config $Port @(17867,18080,28080,8000))){
  $trial=New-Object Net.HttpListener;$trial.Prefixes.Add("${TransportScheme}://+:$candidate/")
  try{$trial.Start();$listener=$trial;$Port=[int]$candidate;$bound=$true;break}
  catch{$bindErrors+=('Port '+$candidate+': '+$_.Exception.Message);try{$trial.Close()}catch{}}
}
if(!$bound){Set-Content (Join-Path $Base 'service_error.txt') ($bindErrors -join [Environment]::NewLine);try{$db.Dispose()}catch{};exit 3}
try{
  $config=Update-VihanServerConfig $ConfigFile @{port=$Port}
  $localConn=Join-Path $env:APPDATA 'Vihan Enterprices\connection.json'
  if(Test-Path $localConn){$cc=Get-Content $localConn -Raw|ConvertFrom-Json;$cc.port=$Port;$cc.filePort=[int]$config.filePort;$cc.serverUrl=Get-VihanServiceOrigin $config ([string]$config.serverName) $Port;$cc.serverIpUrl=Get-VihanServiceOrigin $config ([string]$config.serverIp) $Port;$cc|ConvertTo-Json -Depth 30|Set-Content -Encoding UTF8 $localConn}
}catch{Set-Content (Join-Path $Base 'service_port_update_warning.txt') $_.Exception.ToString()}

. (Join-Path $PSScriptRoot 'BlobStorage.ps1')
$dataIoMutex=New-Object Threading.Mutex($false,'Global\VihanEnterpricesDataIO')
$dataIoHeld=$false
$stop=$false
. (Join-Path $PSScriptRoot 'UserSecurity.ps1')
Initialize-VihanSecurity
while($listener.IsListening -and !$stop){
  try{
    $ctx=$listener.GetContext();$req=$ctx.Request;$path=$req.Url.AbsolutePath;$method=$req.HttpMethod.ToUpperInvariant()
    if(($method -eq 'POST' -and $path.StartsWith('/api/blob/')) -or $path.StartsWith('/api/backup')){
      try{$dataIoHeld=$dataIoMutex.WaitOne(30000)}catch [Threading.AbandonedMutexException]{$dataIoHeld=$true}
      if(!$dataIoHeld){throw 'Attachment/backup operation is busy; retry after the current operation finishes'}
    }
    if($path -eq '/health'){Send-Json $ctx ([pscustomobject]@{ok=$true;product=$Product;version=$AppVersion;serverName=$env:COMPUTERNAME;port=$Port;persistence='SQLite'});continue}
    if($path -eq '/connect'){$q=$req.QueryString['token'];if($q -cne $Token){Send-Text $ctx 'Invalid service file.' 'text/plain; charset=utf-8' 403;continue};$cookie=New-Object Net.Cookie('VE_AUTH',$Token,'/');$cookie.HttpOnly=$true;$cookie.Secure=$req.IsSecureConnection;$ctx.Response.Cookies.Add($cookie);$ctx.Response.StatusCode=302;$ctx.Response.RedirectLocation='/';$ctx.Response.Close();continue}
    if(!(Authorized $ctx)){Send-Text $ctx 'Service authorization required. Open app using Vihan Enterprices shortcut.' 'text/plain; charset=utf-8' 401;continue}
    if($path -eq '/' -or $path -eq '/index.html'){Safe-Static $ctx 'bootstrap.html';continue}
    if($path.StartsWith('/app/')){Safe-Static $ctx $path.Substring(5);continue}
    if(!(Invoke-VihanSecurityGate $ctx)){continue}
    if($path -eq '/api/status'){$up=Read-UpdateState;Send-Json $ctx ([pscustomobject]@{ok=$true;product=$Product;version=$AppVersion;serverName=$env:COMPUTERNAME;serverIp=[string]$config.serverIp;revision=(Get-Revision);dataPath=$DataDir;databasePath=$DbFile;backupPath=$BackupDir;preferredBackupPath=$PreferredBackupDir;persistence='SQLite WAL + synchronous FULL';fileServicePort=([int](Get-Content $ConfigFile -Raw|ConvertFrom-Json).filePort);antiFreeze='Dedicated File Service';centralUpdate=$true;latestUpdateVersion=[string]$up.version;updatePath=$UpdateDir});continue}
    if($path -eq '/api/update/status'){$up=Read-UpdateState;$clients=Read-UpdateClients;Send-Json $ctx ([pscustomobject]@{ok=$true;currentServerVersion=$AppVersion;latest=$up;clients=$clients;updatePath=$UpdateDir});continue}
    if($path -eq '/api/snapshot'){Send-Json $ctx (Get-Snapshot);continue}
    if($path -eq '/api/storage/changes'){$since=[int64]0;[void][int64]::TryParse([string]$req.QueryString['since'],[ref]$since);Send-Json $ctx (Get-ChangesSince $since);continue}
    if($path -eq '/api/storage/batch' -and $method -eq 'POST'){$b=Read-Body $ctx;$plan=Plan-Ops -ops @($b.ops) -clientId ([string]$b.clientId);Commit-Plan $plan;Send-Json $ctx ([pscustomobject]@{ok=$true;revision=(Get-Revision);results=@($plan.results)});continue}
    if($path -eq '/api/storage/set' -and $method -eq 'POST'){$b=Read-Body $ctx;$op=[pscustomobject]@{key=[string]$b.key;op='set';value=[string]$b.value;expectedRev=[int64]$b.expectedRev;seq=0};$plan=Plan-Ops -ops @($op) -clientId ([string]$b.clientId);$r=@($plan.results)[0];if($r.conflict){Send-Json $ctx ([pscustomobject]@{error='Data changed on another PC';revision=(Get-Revision);current=$r.current}) 409;continue};Commit-Plan $plan;Send-Json $ctx ([pscustomobject]@{ok=$true;revision=(Get-Revision);keyRev=[int64]$r.keyRev});continue}
    if($path -eq '/api/storage/remove' -and $method -eq 'POST'){$b=Read-Body $ctx;$op=[pscustomobject]@{key=[string]$b.key;op='remove';expectedRev=[int64]$b.expectedRev;seq=0};$plan=Plan-Ops -ops @($op) -clientId ([string]$b.clientId);$r=@($plan.results)[0];if($r.conflict){Send-Json $ctx ([pscustomobject]@{error='Data changed on another PC';revision=(Get-Revision);current=$r.current}) 409;continue};Commit-Plan $plan;Send-Json $ctx ([pscustomobject]@{ok=$true;revision=(Get-Revision);keyRev=[int64]$r.keyRev});continue}
    if($path -eq '/api/blob/list'){$dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$arr=@();$sql='SELECT record_json FROM blob_meta WHERE db_name='+(Q $dbn)+' AND store_name='+(Q $store)+' ORDER BY updated_at';foreach($r in $db.Query($sql)){try{$arr+=,([string]$r['record_json']|ConvertFrom-Json)}catch{}};Send-Json $ctx ([pscustomobject]@{items=$arr});continue}
    if($path -eq '/api/blob/meta'){$dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$id=[string]$req.QueryString['id'];$k=Blob-Key $dbn $store $id;$rows=$db.Query('SELECT record_json,blob_file,blob_type FROM blob_meta WHERE blob_key='+(Q $k)+' LIMIT 1');if($rows.Count -eq 0){Send-Json $ctx ([pscustomobject]@{error='Not found'}) 404;continue};$x=$rows[0];$rec=$null;try{$rec=[string]$x['record_json']|ConvertFrom-Json}catch{};$bf=[string]$x['blob_file'];$has=$false;if($bf){$has=Test-Path (Join-Path $BlobDir $bf)};Send-Json $ctx ([pscustomobject]@{record=$rec;hasBlob=$has;blobType=[string]$x['blob_type']});continue}
    if($path -eq '/api/blob/file'){$dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$id=[string]$req.QueryString['id'];$k=Blob-Key $dbn $store $id;$rows=$db.Query('SELECT blob_file,blob_type FROM blob_meta WHERE blob_key='+(Q $k)+' LIMIT 1');if($rows.Count -eq 0){Send-Json $ctx ([pscustomobject]@{error='Not found'}) 404;continue};$bf=[string]$rows[0]['blob_file'];if([string]::IsNullOrWhiteSpace($bf)){Send-Json $ctx ([pscustomobject]@{error='No file'}) 404;continue};Send-FileStream $ctx (Join-Path $BlobDir $bf) ([string]$rows[0]['blob_type']);continue}
    if($path -eq '/api/blob/put-binary' -and $method -eq 'POST'){
      $head=Read-ExactBytes $req.InputStream 4;$metaLength=[BitConverter]::ToInt32($head,0)
      if($metaLength -le 0 -or $metaLength -gt 4194304){throw 'Invalid attachment metadata length'}
      $metadata=Read-ExactBytes $req.InputStream $metaLength
      $record=([Text.Encoding]::UTF8.GetString($metadata))|ConvertFrom-Json
      $expected=if($req.ContentLength64 -ge 0){$req.ContentLength64-4-$metaLength}else{-1}
      Save-VihanBlob $record $req.InputStream $expected
      Send-Json $ctx ([pscustomobject]@{ok=$true;mode='raw-binary'});continue
    }
    if($path -eq '/api/blob/get'){$dbn=[string]$req.QueryString['db'];$store=[string]$req.QueryString['store'];$id=[string]$req.QueryString['id'];$k=Blob-Key $dbn $store $id;$rows=$db.Query('SELECT record_json,blob_file,blob_type FROM blob_meta WHERE blob_key='+(Q $k)+' LIMIT 1');if($rows.Count -eq 0){Send-Json $ctx ([pscustomobject]@{error='Not found'}) 404;continue};$x=$rows[0];$b64='';$bf=[string]$x['blob_file'];if($bf){$fp=Join-Path $BlobDir $bf;if(Test-Path $fp){$b64=[Convert]::ToBase64String([IO.File]::ReadAllBytes($fp))}};$rec=$null;try{$rec=[string]$x['record_json']|ConvertFrom-Json}catch{};Send-Json $ctx ([pscustomobject]@{record=$rec;blobBase64=$b64;blobType=[string]$x['blob_type']});continue}
    if($path -eq '/api/blob/put' -and $method -eq 'POST'){$b=Read-Body $ctx;Save-VihanBlob $b;Send-Json $ctx ([pscustomobject]@{ok=$true});continue}
    if($path -eq '/api/blob/delete' -and $method -eq 'POST'){$b=Read-Body $ctx;Remove-VihanBlob $b;Send-Json $ctx ([pscustomobject]@{ok=$true});continue}
    # ---- v1.0.35 offline copy (Client PCs): permission, incremental data, attachment list. Big files use the File Service. ----
    if($path -eq '/api/offline/permission'){$pc=[string]$req.QueryString['pc'];Send-Json $ctx ([pscustomobject]@{ok=$true;pc=$pc;allowed=(Test-OfflineAllowed $pc)});continue}
    if($path -eq '/api/offline/data'){
      $pc=[string]$req.QueryString['pc']
      if(!(Test-OfflineAllowed $pc)){Send-Json $ctx ([pscustomobject]@{error='Offline copy is not allowed for this PC'}) 403;continue}
      $since=[int64]0;[void][int64]::TryParse([string]$req.QueryString['since'],[ref]$since)
      if($since -le 0){$snap=Get-Snapshot;Send-Json $ctx ([pscustomobject]@{full=$true;revision=$snap.revision;items=$snap.items})}
      else{Send-Json $ctx (Get-ChangesSince $since)}
      continue
    }
    if($path -eq '/api/offline/manifest'){
      $pc=[string]$req.QueryString['pc']
      if(!(Test-OfflineAllowed $pc)){Send-Json $ctx ([pscustomobject]@{error='Offline copy is not allowed for this PC'}) 403;continue}
      $arr=New-Object System.Collections.ArrayList
      foreach($r in $db.Query('SELECT db_name,store_name,item_id,record_json,blob_file,blob_type,updated_at FROM blob_meta ORDER BY updated_at')){
        $bf=[string]$r['blob_file'];$size=[int64]0;$has=$false
        if($bf){$fp=Join-Path $BlobDir $bf;if(Test-Path -LiteralPath $fp){$has=$true;$size=[int64](Get-Item -LiteralPath $fp).Length}}
        [void]$arr.Add([pscustomobject]@{db=[string]$r['db_name'];store=[string]$r['store_name'];id=[string]$r['item_id'];updatedAt=[string]$r['updated_at'];blobType=[string]$r['blob_type'];hasBlob=$has;size=$size;recordJson=[string]$r['record_json']})
      }
      Send-Json $ctx ([pscustomobject]@{ok=$true;count=$arr.Count;items=@($arr)});continue
    }
    if($path -eq '/api/offline/clients'){
      # Admin only (same key as Backup Restore: C:\ProgramData\Vihan Enterprices\restore-admin.key)
      # v1.0.39: allowed from the Main PC itself (its own app window) with a valid service login, or with the admin key.
      $provided=[string]$req.Headers['X-Vihan-Restore-Key']
      $keyOk=((-not [string]::IsNullOrWhiteSpace($provided)) -and ($provided -ceq $RestoreAdminSecret))
      if((-not $keyOk) -and (-not (Test-LocalRequest $req))){Send-Json $ctx ([pscustomobject]@{error='Ye setting sirf Main PC par, Main PC ke app se badli ja sakti hai.';mainOnly=$true}) 403;continue}
      if($method -eq 'POST'){
        $b=Read-Body $ctx;$pcName=([string]$b.pcName).Trim()
        if([string]::IsNullOrWhiteSpace($pcName) -or $pcName.Length -gt 64){Send-Json $ctx ([pscustomobject]@{error='PC name invalid'}) 400;continue}
        Save-OfflineClient $pcName ($b.allowed -eq $true)
      }
      $rows=New-Object System.Collections.ArrayList;$seen=@{}
      foreach($k in @(Read-UpdateClients)){
        $n=[string]$k.pcName;if([string]::IsNullOrWhiteSpace($n)){continue}
        $seen[$n.ToLowerInvariant()]=$true
        [void]$rows.Add([pscustomobject]@{pcName=$n;role=[string]$k.role;lastSeen=[string]$k.lastSeen;version=[string]$k.version;allowed=(Test-OfflineAllowed $n);offlineHasCache=($k.offlineHasCache -eq $true);offlineSavedAt=[string]$k.offlineSavedAt;offlineKeys=[int]$k.offlineKeys;offlineError=[string]$k.offlineError})
      }
      foreach($c in @(Read-OfflineClients)){
        $n=[string]$c.pcName;if($seen.ContainsKey($n.ToLowerInvariant())){continue}
        [void]$rows.Add([pscustomobject]@{pcName=$n;role='';lastSeen='';version='';allowed=($c.allowed -eq $true)})
      }
      Send-Json $ctx ([pscustomobject]@{ok=$true;clients=@($rows)});continue
    }
    if($path -eq '/api/backup/restore' -and $method -eq 'POST'){
      $provided=[string]$req.Headers['X-Vihan-Restore-Key']
      if([string]::IsNullOrWhiteSpace($provided) -or $provided -cne $RestoreAdminSecret){Send-Json $ctx ([pscustomobject]@{error='Admin restore key incorrect'}) 403;continue}
      if($req.ContentLength64 -lt 1 -or $req.ContentLength64 -gt 2147483648){Send-Json $ctx ([pscustomobject]@{error='Backup file must be 1 byte to 2 GB'}) 413;continue}
      $inbox=Join-Path $Base 'RestoreInbox';New-Item -ItemType Directory -Force -Path $inbox|Out-Null
      $upload=Join-Path $inbox ([guid]::NewGuid().ToString('N')+'.zip')
      try{
        Save-StreamToFile $req.InputStream $upload
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $archive=[IO.Compression.ZipFile]::OpenRead($upload)
        try{
          $names=@($archive.Entries|ForEach-Object{$_.FullName})
          if($names -notcontains 'backup_manifest.json' -or $names -notcontains 'VihanEnterprices.db'){throw 'Invalid full-system backup archive'}
          foreach($entry in $archive.Entries){if($entry.FullName.StartsWith('/') -or $entry.FullName -match '(^|/)\.\.(/|$)' -or $entry.FullName -match '^[A-Za-z]:'){throw 'Unsafe backup archive path'}}
          $header=($archive.Entries|Where-Object{$_.FullName -eq 'VihanEnterprices.db'}|Select-Object -First 1).Open()
          try{$head=New-Object byte[] 16;$n=$header.Read($head,0,16);if($n -ne 16 -or [Text.Encoding]::ASCII.GetString($head) -ne "SQLite format 3`0"){throw 'Backup SQLite database signature invalid'}}finally{$header.Dispose()}
        }finally{$archive.Dispose()}
        $script=Join-Path $PSScriptRoot 'ApplyRemoteRestore.ps1';if(!(Test-Path $script)){throw 'Restore worker missing'}
        # Take a pre-restore backup before scheduling any destructive replacement.
        $safety=Make-Backup
        $job=Join-Path $inbox 'restore-status.json'
        [pscustomobject]@{status='scheduled';uploadedAt=(Get-Date).ToString('o');preRestoreBackup=$safety}|ConvertTo-Json|Set-Content -Encoding UTF8 $job
        $ps="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
        Start-Process -FilePath $ps -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$script+'"'),'-Archive',('"'+$upload+'"')) -WindowStyle Hidden | Out-Null
        Send-Json $ctx ([pscustomobject]@{ok=$true;status='scheduled';preRestoreBackup=$safety;message='Main server will restart; reconnect after restore'})
      }catch{Remove-Item $upload -Force -ErrorAction SilentlyContinue;Send-Json $ctx ([pscustomobject]@{error=$_.Exception.Message}) 400}
      continue
    }
    if($path -eq '/api/backup/download' -and $method -eq 'GET'){
      # Complete backup includes the central SQLite database and all Blobs, irrespective of company.
      $zip=Make-Backup
      $ctx.Response.AddHeader('Content-Disposition', ('attachment; filename="'+[IO.Path]::GetFileName($zip)+'"'))
      Send-FileStream $ctx $zip 'application/zip'
      continue
    }
    if($path -eq '/api/backup' -and $method -eq 'POST'){$zip=Make-Backup;Send-Json $ctx ([pscustomobject]@{ok=$true;file=[IO.Path]::GetFileName($zip);path=$zip;backupPath=$BackupDir});continue}
    Send-Text $ctx 'Not Found' 'text/plain; charset=utf-8' 404
  }catch{try{$status=if($_.Exception -is [UnauthorizedAccessException]){403}else{500};Send-Json $ctx ([pscustomobject]@{error=$_.Exception.Message}) $status}catch{}}finally{if($dataIoHeld){$dataIoMutex.ReleaseMutex();$dataIoHeld=$false}}
}
try{$db.Exec('PRAGMA wal_checkpoint(TRUNCATE);')}catch{};try{$dataIoMutex.Dispose()}catch{};try{$db.Dispose()}catch{};try{$listener.Stop();$listener.Close()}catch{};try{$mutex.ReleaseMutex();$mutex.Dispose()}catch{};Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
