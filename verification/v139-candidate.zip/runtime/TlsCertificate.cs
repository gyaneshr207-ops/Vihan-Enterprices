using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Cryptography.X509Certificates;
public static class VihanTlsCertificate {
  static int Length(byte[] b,ref int p){if(p>=b.Length)throw new Exception("Invalid SAN length");int n=b[p++];if((n&128)==0)return n;int count=n&127;if(count<1||count>4||p+count>b.Length)throw new Exception("Invalid SAN length");n=0;for(int i=0;i<count;i++)n=checked(n*256+b[p++]);return n;}
  public static string[] Names(X509Certificate2 cert){var names=new List<string>();foreach(var ext in cert.Extensions){if(ext.Oid.Value!="2.5.29.17")continue;var b=ext.RawData;int p=0;if(b.Length==0||b[p++]!=48)throw new Exception("Invalid SAN sequence");int length=Length(b,ref p),end=checked(p+length);if(end!=b.Length)throw new Exception("Invalid SAN bounds");while(p<end){int tag=b[p++],n=Length(b,ref p);if(n<0||p+n>end)throw new Exception("Invalid SAN entry");if(tag==130)names.Add(System.Text.Encoding.ASCII.GetString(b,p,n));else if(tag==135){if(n!=4&&n!=16)throw new Exception("Invalid IP SAN");var ip=new byte[n];Buffer.BlockCopy(b,p,ip,0,n);names.Add(new IPAddress(ip).ToString());}p+=n;}}return names.ToArray();}
  public static void Validate(X509Certificate2 cert,string[] requiredNames){
    if(!cert.HasPrivateKey)throw new Exception("Machine certificate private key required");
    if(cert.NotBefore.ToUniversalTime()>DateTime.UtcNow||cert.NotAfter.ToUniversalTime()<DateTime.UtcNow.AddDays(7))throw new Exception("Certificate is not valid for at least seven more days");
    bool server=false;foreach(var ext in cert.Extensions){var eku=ext as X509EnhancedKeyUsageExtension;if(eku!=null)foreach(var oid in eku.EnhancedKeyUsages)if(oid.Value=="1.3.6.1.5.5.7.3.1")server=true;}
    if(!server)throw new Exception("Explicit Server Authentication EKU required");
    var names=Names(cert);foreach(var name in requiredNames){bool found=false;foreach(var n in names)if(String.Equals(n,name,StringComparison.OrdinalIgnoreCase))found=true;if(!found)throw new Exception("Certificate SAN missing required service name: "+name);}
    if(!cert.Verify())throw new Exception("Certificate chain is not trusted or revocation verification failed; fix CA trust, do not bypass validation");
  }
}
