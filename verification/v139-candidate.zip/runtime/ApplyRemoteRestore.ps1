param([Parameter(Mandatory=$true)][string]$Archive)
$ErrorActionPreference='Stop'
$Product='Vihan Enterprices'
$Base=Join-Path $env:ProgramData $Product
. (Join-Path $PSScriptRoot 'StoragePaths.ps1')
. (Join-Path $PSScriptRoot 'ArchiveSafety.ps1')
$server=Get-Content (Join-Path $Base 'server.json') -Raw|ConvertFrom-Json
$paths=Get-VihanStoragePaths $server
$Data=$paths.Data;$BackupDir=$paths.Backup
$Inbox=Join-Path $Base 'RestoreInbox'
$Status=Join-Path $Inbox 'restore-status.json'
$MainTask='Vihan Enterprices Main Service'
$FilesTask='Vihan Enterprices File Service'
function Write-State([string]$state,[string]$detail){
  [pscustomobject]@{status=$state;detail=$detail;updatedAt=(Get-Date).ToString('o')} | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 $Status
}
$stage=Join-Path $Inbox ('validated_'+[guid]::NewGuid().ToString('N'))
$prev=$Data+'_before_restore_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N')
$switched=$false;$restoreFailed=$false
try{
  if(!(Test-Path $Archive)){throw 'Uploaded archive not found'}
  New-Item -ItemType Directory -Path $stage -Force | Out-Null
  Expand-VihanArchive $Archive $stage
  $manifest=Join-Path $stage 'backup_manifest.json'
  $dbFile=Join-Path $stage 'VihanEnterprices.db'
  if(!(Test-Path $manifest) -or !(Test-Path $dbFile)){throw 'Archive missing manifest or SQLite DB'}
  $meta=Get-Content $manifest -Raw | ConvertFrom-Json
  if([string]$meta.product -ne $Product){throw 'Not a Vihan Enterprices backup'}
  $stream=[IO.File]::OpenRead($dbFile)
  try{$sig=New-Object byte[] 16;[void]$stream.Read($sig,0,16);if([Text.Encoding]::ASCII.GetString($sig) -ne "SQLite format 3`0"){throw 'Not a valid SQLite database'}}finally{$stream.Dispose()}
  # Recover any WAL included by older official backups in the isolated staging
  # copy, validate actual SQLite integrity/schema and attachments before stopping
  # services or replacing a single byte of live data.
  if(-not ('VihanSqliteDb' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'VihanSqlite.cs')}
  $check=New-Object VihanSqliteDb -ArgumentList $dbFile
  try{
    if($check.ScalarText('PRAGMA quick_check','') -ne 'ok'){throw 'Backup SQLite integrity check failed'}
    foreach($table in @('meta','kv','blob_meta')){
      if($check.ScalarLong("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name="+[VihanSqliteDb]::Quote($table),0) -ne 1){throw ('Backup schema missing '+$table)}
    }
    if($check.ScalarLong("SELECT CAST(v AS INTEGER) FROM meta WHERE k='schema_version'",0) -gt 2){throw 'Backup database schema is newer than this application'}
    foreach($row in $check.Query("SELECT blob_file FROM blob_meta WHERE blob_file IS NOT NULL AND blob_file<>''")){
      $file=[string]$row['blob_file']
      if([IO.Path]::GetFileName($file) -ne $file -or !(Test-Path -LiteralPath (Join-Path (Join-Path $stage 'Blobs') $file))){throw 'Backup contains a missing or unsafe attachment reference'}
    }
    . (Join-Path $PSScriptRoot 'UserSecurity.ps1')
    Clear-VihanRestoredSessions $check
    $check.Exec('PRAGMA wal_checkpoint(TRUNCATE);')
  }finally{$check.Dispose()}
  Write-State 'validated' 'Backup validated, stopping services'
  try{Stop-ScheduledTask -TaskName $MainTask -ErrorAction SilentlyContinue}catch{}
  try{Stop-ScheduledTask -TaskName $FilesTask -ErrorAction SilentlyContinue}catch{}
  Stop-VihanTrackedService (Join-Path $Base 'service.pid') (Join-Path $PSScriptRoot 'MainService.ps1')
  Stop-VihanTrackedService (Join-Path $Base 'file_service.pid') (Join-Path $PSScriptRoot 'FileService.ps1')
  Start-Sleep -Seconds 2
  if(Test-Path $Data){Move-Item -LiteralPath $Data -Destination $prev -ErrorAction Stop}
  $switched=$true
  New-Item -ItemType Directory -Path $Data -Force | Out-Null
  Copy-Item -LiteralPath $dbFile -Destination (Join-Path $Data 'VihanEnterprices.db') -Force
  $blobs=Join-Path $stage 'Blobs'
  if(Test-Path $blobs){Copy-Item -LiteralPath $blobs -Destination (Join-Path $Data 'Blobs') -Recurse -Force}
  else{New-Item -ItemType Directory -Path (Join-Path $Data 'Blobs') -Force | Out-Null}
  # Staged WAL, if supplied by an older backup, was recovered and checkpointed above.
  Write-State 'complete' ('Restored. Previous data retained: '+$prev)
}catch{
  $detail=$_.Exception.ToString()
  if($switched){
    try{if(Test-Path $Data){Remove-Item $Data -Recurse -Force};if(Test-Path $prev){Move-Item $prev $Data}}catch{$detail+='; rollback failed: '+$_.Exception.Message}
  }
  Write-State 'failed' $detail
  $restoreFailed=$true
}finally{
  try{Start-ScheduledTask -TaskName $MainTask -ErrorAction SilentlyContinue}catch{}
  try{Start-ScheduledTask -TaskName $FilesTask -ErrorAction SilentlyContinue}catch{}
  Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item $Archive -Force -ErrorAction SilentlyContinue
}

if($restoreFailed){exit 1}
