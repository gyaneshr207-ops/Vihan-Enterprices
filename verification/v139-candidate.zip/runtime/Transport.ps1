# Shared transport policy. TLS never falls back to an unbound port or HTTP.
function Get-VihanTransportScheme($Config){
  if($Config.tls -and $Config.tls.enabled -eq $true){
    if(([string]$Config.tls.certificateThumbprint) -notmatch '^[0-9A-Fa-f]{40,64}$'){throw 'TLS certificate thumbprint missing/invalid'}
    if([int]$Config.port -lt 1 -or [int]$Config.port -gt 65535 -or [int]$Config.filePort -lt 1 -or [int]$Config.filePort -gt 65535 -or [int]$Config.port -eq [int]$Config.filePort){throw 'TLS requires distinct, valid Main and File ports'}
    return 'https'
  }
  if($Config.requireTls -eq $true){throw 'TLS is required but not configured; refusing plaintext startup'}
  return 'http'
}
function Get-VihanListenerPorts($Config,[int]$Port,[int[]]$LegacyFallback){
  if((Get-VihanTransportScheme $Config) -eq 'https'){return ,@($Port)}
  return ,@(@($Port)+$LegacyFallback|Select-Object -Unique)
}
function Get-VihanServiceOrigin($Config,[string]$HostName,[int]$Port){
  $scheme=Get-VihanTransportScheme $Config
  if([string]::IsNullOrWhiteSpace($HostName) -or $HostName -match '[/\\@?#\s]'){throw 'Invalid service host'}
  if($HostName.Contains(':') -and !$HostName.StartsWith('[')){$HostName='['+$HostName+']'}
  return ('{0}://{1}:{2}' -f $scheme,$HostName,$Port)
}
function Assert-VihanConnectionTransport($Config){
  $scheme=Get-VihanTransportScheme $Config
  foreach($name in @('serverUrl','serverIpUrl')){
    if(!$Config.$name){continue}
    $uri=$null
    if(![uri]::TryCreate([string]$Config.$name,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -notin @('http','https') -or $uri.UserInfo -or $uri.AbsolutePath -ne '/' -or $uri.Query -or $uri.Fragment){throw 'Invalid service origin'}
    if($scheme -eq 'https' -and $uri.Scheme -ne 'https'){throw 'TLS connection cannot contain an HTTP downgrade URL'}
  }
}
