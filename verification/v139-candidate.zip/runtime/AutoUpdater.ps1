param(
  [Parameter(Mandatory=$true)][string]$PackagePath,
  [Parameter(Mandatory=$true)][string]$InstallRoot,
  [string]$RelaunchExe='',
  [switch]$MainPc,
  [int]$DelaySeconds=1
)
$ErrorActionPreference='Stop'
$Product='Vihan Enterprices'
. (Join-Path $InstallRoot 'runtime\StoragePaths.ps1')
. (Join-Path $InstallRoot 'runtime\ArchiveSafety.ps1')
$Base=Join-Path $env:ProgramData $Product
$LogDir=if($MainPc){Join-Path 'D:\Vihan Enterprices' 'Updates'}else{Join-Path $InstallRoot 'updates'}
New-Item -ItemType Directory -Force -Path $LogDir|Out-Null
$Log=Join-Path $LogDir 'auto_update.log'
function Log([string]$m){try{Add-Content -Path $Log -Encoding UTF8 -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+'  '+$m)}catch{}}
function DesktopExe(){if($RelaunchExe -and (Test-Path $RelaunchExe)){return $RelaunchExe};$p=Join-Path $InstallRoot 'desktop-runtime\Vihan Enterprices.exe';if(Test-Path $p){return $p};return ''}
function Stop-DesktopApp(){
  try{
    Get-Process -Name 'Vihan Enterprices' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 900
  }catch{}
}
function Stop-MainServices(){
  try{Stop-ScheduledTask -TaskName 'Vihan Enterprices Main Service' -ErrorAction SilentlyContinue}catch{}
  try{Stop-ScheduledTask -TaskName 'Vihan Enterprices File Service' -ErrorAction SilentlyContinue}catch{}
  Stop-VihanTrackedService (Join-Path $Base 'service.pid') (Join-Path $InstallRoot 'runtime\MainService.ps1')
  Stop-VihanTrackedService (Join-Path $Base 'file_service.pid') (Join-Path $InstallRoot 'runtime\FileService.ps1')
  Start-Sleep -Milliseconds 900
}
function Repair-Main(){
  if(!$MainPc){return}
  try{$repair=Join-Path $InstallRoot 'runtime\RepairMainService.ps1';if(Test-Path $repair){& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $repair -NoPrompt;if($LASTEXITCODE -ne 0){throw ('Main service repair exit '+$LASTEXITCODE)}}}catch{Log ('Main service repair error '+$_.Exception.Message);throw}
}
function Start-Desktop(){
  $exe=DesktopExe
  if($exe){try{Start-Process -FilePath $exe -WorkingDirectory ([IO.Path]::GetDirectoryName($exe))|Out-Null;Log ('Desktop relaunched: '+$exe)}catch{Log ('Desktop relaunch warning '+$_.Exception.Message)}}
}
function Backup-Current([string]$dir){
  New-Item -ItemType Directory -Force -Path $dir|Out-Null
  foreach($name in @('app','runtime')){ $s=Join-Path $InstallRoot $name;if(Test-Path $s){Copy-Item $s (Join-Path $dir $name) -Recurse -Force} }
  foreach($name in @('manifest.json','installed_version.json')){$file=Join-Path $InstallRoot $name;if(Test-Path $file){Copy-Item $file (Join-Path $dir $name) -Force}}
  $desktopHost=Join-Path $InstallRoot 'desktop-runtime\resources\app';if(Test-Path $desktopHost){Copy-Item $desktopHost (Join-Path $dir 'desktop_host') -Recurse -Force}
}
function Restore-Current([string]$dir){
  Log ('Rollback from '+$dir)
  foreach($name in @('app','runtime')){ $s=Join-Path $dir $name;$d=Join-Path $InstallRoot $name;if(Test-Path $s){if(Test-Path $d){Remove-Item $d -Recurse -Force -ErrorAction SilentlyContinue};Copy-Item $s $d -Recurse -Force} }
  foreach($name in @('manifest.json','installed_version.json')){$file=Join-Path $dir $name;$target=Join-Path $InstallRoot $name;if(Test-Path $file){Copy-Item $file $target -Force}else{Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue}}
  $hs=Join-Path $dir 'desktop_host';$hd=Join-Path $InstallRoot 'desktop-runtime\resources\app';if(Test-Path $hs){if(Test-Path $hd){Remove-Item $hd -Recurse -Force -ErrorAction SilentlyContinue};Copy-Item $hs $hd -Recurse -Force}
}
$stage=$null;$zipForExpand=$null;$rollback=$null
try{
  if($DelaySeconds -gt 0){Start-Sleep -Seconds $DelaySeconds}
  if(!(Test-Path $PackagePath)){throw 'Update package missing: '+$PackagePath}
  $stage=Join-Path $env:TEMP ('VihanAutoUpdate_'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $stage|Out-Null
  $zipForExpand=Join-Path $env:TEMP ('VihanAutoUpdatePkg_'+[guid]::NewGuid().ToString('N')+'.zip')
  Copy-Item -LiteralPath $PackagePath -Destination $zipForExpand -Force
  Expand-VihanArchive $zipForExpand $stage
  $mf=Join-Path $stage 'manifest.json';if(!(Test-Path $mf)){throw 'Update manifest missing'}
  $m=Get-Content $mf -Raw|ConvertFrom-Json;if([string]$m.product -ne $Product){throw 'Invalid Vihan update package'}
  $ver=[string]$m.appVersion;if([string]::IsNullOrWhiteSpace($ver)){throw 'Update version missing'}
  $parsedVersion=$null;if(![version]::TryParse($ver,[ref]$parsedVersion)){throw 'Invalid numeric update version'}
  $diskVersionFile=Join-Path $InstallRoot 'app\version.json'
  if(Test-Path $diskVersionFile){$diskVersion=Get-Content $diskVersionFile -Raw|ConvertFrom-Json;if($parsedVersion -le [version]([string]$diskVersion.version)){throw 'Update must be newer than the installed application; use the installer for repair'}}
  if(!(Test-Path (Join-Path $stage 'app\index.html')) -or !(Test-Path (Join-Path $stage 'app\vihan-sync.js')) -or !(Test-Path (Join-Path $stage 'runtime\electron-app\main.js'))){throw 'Update app/runtime incomplete'}
  Log ('Applying v'+$ver+' to '+$InstallRoot+' MainPc='+$MainPc)
  $rollback=Join-Path $LogDir ('Rollback_Pre_'+$ver+'_'+(Get-Date -Format 'yyyyMMdd_HHmmss'))
  Backup-Current $rollback
  Stop-DesktopApp
  if($MainPc){Stop-MainServices}
  New-Item -ItemType Directory -Force -Path (Join-Path $InstallRoot 'app'),(Join-Path $InstallRoot 'runtime')|Out-Null
  Copy-Item (Join-Path $stage 'app\*') (Join-Path $InstallRoot 'app') -Recurse -Force
  Copy-Item (Join-Path $stage 'runtime\*') (Join-Path $InstallRoot 'runtime') -Recurse -Force
  Copy-Item (Join-Path $stage 'manifest.json') (Join-Path $InstallRoot 'manifest.json') -Force
  $hostSrc=Join-Path $InstallRoot 'runtime\electron-app';$hostDest=Join-Path $InstallRoot 'desktop-runtime\resources\app'
  if((Test-Path $hostSrc) -and (Test-Path (Join-Path $InstallRoot 'desktop-runtime\Vihan Enterprices.exe'))){
    if(Test-Path $hostDest){Remove-Item $hostDest -Recurse -Force -ErrorAction Stop};New-Item -ItemType Directory -Force -Path $hostDest|Out-Null;Copy-Item (Join-Path $hostSrc '*') $hostDest -Recurse -Force
    if(!(Test-Path (Join-Path $hostDest 'main.js'))){throw 'Desktop host update incomplete'}
  }
  [pscustomobject]@{version=$ver;updatedAt=(Get-Date).ToString('o')}|ConvertTo-Json|Set-Content -Encoding UTF8 (Join-Path $InstallRoot 'installed_version.json')
  Repair-Main
  Start-Desktop
  Log ('Update v'+$ver+' complete')
  exit 0
}catch{
  Log ('ERROR '+$_.Exception.ToString())
  try{Stop-DesktopApp}catch{}
  if($rollback -and (Test-Path $rollback)){try{Restore-Current $rollback;Log 'Rollback complete'}catch{Log ('Rollback ERROR '+$_.Exception.ToString())}}
  Repair-Main
  Start-Desktop
  exit 5
}finally{
  if($stage){Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue}
  if($zipForExpand){Remove-Item $zipForExpand -Force -ErrorAction SilentlyContinue}
}
