$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
$Product='Vihan Enterprices';$Root=Split-Path $PSScriptRoot -Parent
$dialog=New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title='Vihan Enterprices Update Package select karein'
$dialog.Filter='Vihan Update (*.veupdate;*.zip)|*.veupdate;*.zip'
if($dialog.ShowDialog() -ne 'OK'){exit 0}
$main=Test-Path (Join-Path (Join-Path $env:ProgramData $Product) 'server.json')
# Run the same rollback-capable updater for manual and automatic updates.
$tempUpdater=Join-Path $env:TEMP ('VihanManualUpdater_'+[guid]::NewGuid().ToString('N')+'.ps1')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'AutoUpdater.ps1') -Destination $tempUpdater
$argsList=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$tempUpdater+'"'),'-PackagePath',('"'+$dialog.FileName+'"'),'-InstallRoot',('"'+$Root+'"'),'-DelaySeconds','0')
if($main){$argsList+='-MainPc';$child=Start-Process powershell.exe -Verb RunAs -ArgumentList $argsList -PassThru -Wait}
else{$child=Start-Process powershell.exe -ArgumentList $argsList -PassThru -Wait}
Remove-Item -LiteralPath $tempUpdater -Force -ErrorAction SilentlyContinue
if($child.ExitCode -ne 0){[System.Windows.Forms.MessageBox]::Show('Update failed. Review auto_update.log and rollback status.',$Product,'OK','Error')|Out-Null;exit 1}
[System.Windows.Forms.MessageBox]::Show('Update completed. Data and connection configuration were retained.',$Product,'OK','Information')|Out-Null
