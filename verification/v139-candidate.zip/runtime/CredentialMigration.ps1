# Offline/staged preparation ONLY: never switches a production database or rewrites server.json.
param([Parameter(Mandatory=$true)][string]$SourceDatabase,[Parameter(Mandatory=$true)][string]$OutputDirectory,[switch]$PrepareCopy)
$ErrorActionPreference='Stop'
if(![IO.Path]::IsPathRooted($SourceDatabase) -or ![IO.Path]::IsPathRooted($OutputDirectory)){throw 'Absolute paths required'}
if(!(Test-Path -LiteralPath $SourceDatabase -PathType Leaf)){throw 'Existing source database required'}
if(Test-Path -LiteralPath $OutputDirectory){throw 'Output must be a new directory; no existing files will be overwritten'}
if(!$PrepareCopy){Write-Output 'PLAN ONLY: no database opened or changed. PrepareCopy creates a separate verified credential-migration candidate; switching production still needs explicit operator approval.';return}
if(-not ('VihanSqliteDb' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'VihanSqlite.cs')}
if(-not ('VihanAuthCrypto' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'VihanAuthCrypto.cs')}
New-Item -ItemType Directory -Path $OutputDirectory|Out-Null
# A plaintext safety snapshot is retained deliberately; on Windows restrict access before writing it.
if($env:OS -eq 'Windows_NT'){
  & icacls.exe $OutputDirectory /inheritance:r /grant:r (($env:USERDOMAIN+'\'+$env:USERNAME)+':(OI)(CI)F') 'SYSTEM:(OI)(CI)F' 'Administrators:(OI)(CI)F'|Out-Null
  if($LASTEXITCODE -ne 0){throw 'Cannot restrict migration/safety directory; stopped before database copy'}
}
$mutex=New-Object Threading.Mutex($false,'Global\VihanEnterpricesDataIO');$held=$false;$source=$null;$candidate=$null
try{
 try{$held=$mutex.WaitOne(30000)}catch [Threading.AbandonedMutexException]{$held=$true};if(!$held){throw 'Data operations busy; retry'}
 $source=New-Object VihanSqliteDb -ArgumentList $SourceDatabase
 $safety=Join-Path $OutputDirectory 'before-credentials.db';$source.BackupTo($safety)
 $file=Join-Path $OutputDirectory 'VihanEnterprices.db';$source.BackupTo($file)
 $blobs=Join-Path (Split-Path $SourceDatabase -Parent) 'Blobs';if(Test-Path -LiteralPath $blobs){Copy-Item -LiteralPath $blobs -Destination (Join-Path $OutputDirectory 'Blobs') -Recurse}
 $source.Dispose();$source=$null;$mutex.ReleaseMutex();$held=$false
 $candidate=New-Object VihanSqliteDb -ArgumentList $file
 $value=$candidate.ScalarText("SELECT value FROM kv WHERE key='multiCompanyAdminV2' AND deleted=0",'')
 if(!$value){throw 'No identity store found; use explicit fresh provisioning rather than inventing user accounts'}
 $root=$value|ConvertFrom-Json;$converted=0
 foreach($c in @($root.companies)){foreach($u in @($c.users)){
   if($u.passwordHash){if(!([string]$u.passwordHash).StartsWith('pbkdf2-sha256$600000$')){throw 'Unsupported existing password hash'}}
   elseif($u.password){$hash=[VihanAuthCrypto]::HashPassword([string]$u.password);if(![VihanAuthCrypto]::Verify([string]$u.password,$hash)){throw 'Credential self-verification failed'};$u|Add-Member NoteProperty passwordHash $hash -Force;$converted++}
   elseif($u.active -ne $false){throw 'Active account has no usable credential; candidate rejected'}
   $u.PSObject.Properties.Remove('password')
 }}
 $json=$root|ConvertTo-Json -Depth 100 -Compress
 $candidate.Exec('PRAGMA secure_delete=ON;BEGIN IMMEDIATE;UPDATE kv SET value='+[VihanSqliteDb]::Quote($json)+" WHERE key='multiCompanyAdminV2';DELETE FROM changes;UPDATE meta SET v=CAST(v AS INTEGER)+1 WHERE k='revision';COMMIT;")
 # Clearing changes forces older clients to request a fresh projected snapshot after the revision bump.
 if($candidate.ScalarLong("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='auth_sessions'",0)){$candidate.Exec('DELETE FROM auth_sessions;')}
 $candidate.Exec('PRAGMA wal_checkpoint(TRUNCATE);VACUUM;PRAGMA wal_checkpoint(TRUNCATE);')
 if($candidate.ScalarText('PRAGMA integrity_check','') -ne 'ok'){throw 'Candidate integrity failed'}
 $candidate.Dispose();$candidate=$null
 $checksum=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
 @{status='prepared-copy-only';converted=$converted;candidateSha256=$checksum;productionSwitched=$false;sourceBusinessRecordsNotReplaced=$true;rollback='Retain original production directory and protected before-credentials.db. Do not auto-switch paths.';warning='before-credentials.db contains original credentials. Restrict and retain under operator policy.'}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $OutputDirectory 'migration-report.json') -Encoding UTF8
 Write-Output ('Prepared and integrity-verified separate copy. Converted account count: '+$converted+'. No production switch performed.')
}catch{Set-Content -LiteralPath (Join-Path $OutputDirectory 'PREPARATION_FAILED.txt') -Value 'Preparation failed; do not deploy this output. Source not switched.';throw}
finally{if($source){$source.Dispose()};if($candidate){$candidate.Dispose()};if($held){$mutex.ReleaseMutex()};$mutex.Dispose()}
