param([Parameter(Mandatory=$true)][string]$Database,[string]$Username='admin',[switch]$InitializeNewIdentityStore)
$ErrorActionPreference='Stop'
if(!$InitializeNewIdentityStore){throw 'Explicit InitializeNewIdentityStore required; existing accounts must use staged migration'}
if(![IO.Path]::IsPathRooted($Database) -or !(Test-Path -LiteralPath $Database)){throw 'Existing initialized database absolute path required; this tool never creates a missing master'}
if(-not ('VihanSqliteDb' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'VihanSqlite.cs')}
if(-not ('VihanAuthCrypto' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'VihanAuthCrypto.cs')}
$mutex=New-Object Threading.Mutex($false,'Global\VihanEnterpricesDataIO');$held=$false;$conn=$null
try{
 try{$held=$mutex.WaitOne(30000)}catch [Threading.AbandonedMutexException]{$held=$true};if(!$held){throw 'Database busy'}
 $conn=New-Object VihanSqliteDb -ArgumentList $Database
 if($conn.ScalarLong('SELECT COUNT(*) FROM kv',0) -ne 0){throw 'Database contains existing application records; no identity replacement performed'}
 $secret=Read-Host 'New Admin password (at least 12 characters)' -AsSecureString
 $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
 try{$password=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr);if($password.Length -lt 12){throw 'Password must have at least 12 characters'};$hash=[VihanAuthCrypto]::HashPassword($password)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr);$password=$null;$secret.Dispose()}
 $companies=@();for($i=1;$i -le 5;$i++){$companies+=,[pscustomobject]@{id=[guid]::NewGuid().ToString('N');name=('Company '+$i);active=$true;studentModule=($i -eq 1);address='';phone='';signature='';logo='';users=@();records=@();students=@();joinings=@();leaves=@();payments=@()}}
 $companies[0].users=@([pscustomobject]@{username=$Username;passwordHash=$hash;role='Admin';active=$true})
 $root=@{companies=$companies;studentCompanyId=$companies[0].id;company2ModuleId=$companies[1].id}|ConvertTo-Json -Depth 100 -Compress
 $conn.Exec("BEGIN IMMEDIATE;INSERT INTO kv(key,value,deleted,key_rev,revision,updated_at,client_id) VALUES('multiCompanyAdminV2',"+[VihanSqliteDb]::Quote($root)+",0,1,1,"+[VihanSqliteDb]::Quote([DateTime]::UtcNow.ToString('o'))+",'explicit-provision');UPDATE meta SET v='1' WHERE k='revision';COMMIT;")
 Write-Output 'New identity store provisioned. Sign in with Admin login. No default password or ordinary user account was created.'
}finally{if($conn){$conn.Dispose()};if($held){$mutex.ReleaseMutex()};$mutex.Dispose()}
