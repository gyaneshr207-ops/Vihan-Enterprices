$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
$Product='Vihan Enterprices'
$Base=Join-Path $env:ProgramData $Product
$identity=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if(!$identity.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  $child=Start-Process powershell.exe -Verb RunAs -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"')) -PassThru -Wait
  exit $child.ExitCode
}
$dialog=New-Object System.Windows.Forms.OpenFileDialog
$dialog.Title='Vihan Enterprices complete SQLite backup select karein'
$dialog.Filter='Vihan Backup (*.zip)|*.zip'
if($dialog.ShowDialog() -ne 'OK'){exit 0}
if([System.Windows.Forms.MessageBox]::Show('Restore replaces all companies central data. The existing data directory will be retained for rollback. Continue?',$Product,'YesNo','Warning') -ne 'Yes'){exit 0}
# Preserve the selected archive. The shared validated worker only removes its inbox copy.
$inbox=Join-Path $Base 'RestoreInbox';New-Item -ItemType Directory -Force -Path $inbox|Out-Null
$copy=Join-Path $inbox ([guid]::NewGuid().ToString('N')+'.zip')
Copy-Item -LiteralPath $dialog.FileName -Destination $copy
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'ApplyRemoteRestore.ps1') -Archive $copy
if($LASTEXITCODE -ne 0){[System.Windows.Forms.MessageBox]::Show('Restore failed. Review restore-status.json. Existing data was retained or rollback was attempted.',$Product,'OK','Error')|Out-Null;exit 1}
[System.Windows.Forms.MessageBox]::Show('Restore completed. Reopen the app and verify all companies and attachments.',$Product,'OK','Information')|Out-Null
