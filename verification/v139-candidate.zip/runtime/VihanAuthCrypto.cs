using System;
using System.Text;
using System.Security.Cryptography;
public static class VihanAuthCrypto {
 public static string RandomToken(){var b=new byte[32];using(var r=RandomNumberGenerator.Create())r.GetBytes(b);return Convert.ToBase64String(b).TrimEnd('=').Replace('+','-').Replace('/','_');}
 public static string Digest(string s){using(var h=SHA256.Create())return Convert.ToBase64String(h.ComputeHash(Encoding.UTF8.GetBytes(s??"")));}
 public static bool Equal(string a,string b){var x=Encoding.UTF8.GetBytes(a??"");var y=Encoding.UTF8.GetBytes(b??"");int d=x.Length^y.Length;for(int i=0;i<x.Length;i++)d|=x[i]^(i<y.Length?y[i]:0);return d==0;}
 public static string HashPassword(string p){if(string.IsNullOrEmpty(p)||p.Length>1024)throw new ArgumentException("Password required (max 1024 characters)");var salt=new byte[16];using(var r=RandomNumberGenerator.Create())r.GetBytes(salt);using(var k=new Rfc2898DeriveBytes(p,salt,600000,HashAlgorithmName.SHA256))return "pbkdf2-sha256$600000$"+Convert.ToBase64String(salt)+"$"+Convert.ToBase64String(k.GetBytes(32));}
 public static bool Verify(string p,string h){try{var a=h.Split('$');if(a.Length!=4||a[0]!="pbkdf2-sha256"||a[1]!="600000"||p==null||p.Length>1024)return false;var salt=Convert.FromBase64String(a[2]);if(salt.Length!=16)return false;using(var k=new Rfc2898DeriveBytes(p,salt,600000,HashAlgorithmName.SHA256))return Equal(Convert.ToBase64String(k.GetBytes(32)),a[3]);}catch{return false;}}
}
