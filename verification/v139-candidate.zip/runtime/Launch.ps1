$ErrorActionPreference='SilentlyContinue'
$Product='Vihan Enterprices'
$Root=Split-Path $PSScriptRoot -Parent
$exe=Join-Path $Root 'desktop-runtime\Vihan Enterprices.exe'
if(Test-Path $exe){Start-Process -FilePath $exe -WorkingDirectory (Split-Path $exe -Parent);exit 0}
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show("Vihan Enterprices Desktop Runtime install nahi hai.`n`nLatest Vihan Enterprices Setup ko dobara run karein.",$Product,'OK','Error')|Out-Null
exit 2
