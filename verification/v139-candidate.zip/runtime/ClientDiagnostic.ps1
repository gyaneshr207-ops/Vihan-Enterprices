$ErrorActionPreference='SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
$Product='Vihan Enterprices';$Port=17867;$FilePort=17868
$ClientDir=Join-Path $env:APPDATA $Product;$Conn=Join-Path $ClientDir 'connection.json'
$desktop=[Environment]::GetFolderPath('Desktop');$report=Join-Path $desktop ('Vihan_Client_Diagnostic_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.txt')
$lines=New-Object System.Collections.Generic.List[string]
function Add([string]$s){$lines.Add($s)}
Add ('Vihan Enterprices Client Diagnostic - '+(Get-Date))
Add ('Computer: '+$env:COMPUTERNAME)
Add ('User: '+$env:USERNAME)
Add ('Connection file: '+$Conn)
if(!(Test-Path $Conn)){
  Add 'RESULT: connection.json nahi mili. Service file import karein.'
  $lines|Set-Content -Encoding UTF8 $report
  [System.Windows.Forms.MessageBox]::Show("Connection file nahi mili.`nService file import karein.`n`nReport:`n$report",$Product,'OK','Error')|Out-Null
  exit 2
}
try{$c=Get-Content $Conn -Raw|ConvertFrom-Json}catch{Add ('RESULT: connection.json invalid - '+$_.Exception.Message);$lines|Set-Content -Encoding UTF8 $report;[System.Windows.Forms.MessageBox]::Show("Connection file invalid hai.`n`nReport:`n$report",$Product,'OK','Error')|Out-Null;exit 2}
Add ('Server name: '+[string]$c.serverName)
Add ('Server IP: '+[string]$c.serverIp)
Add ('Main Port: '+[string]$c.port);$fp=if($c.filePort){[int]$c.filePort}else{([int]$c.port)+1};Add ('File Port: '+$fp)
$urls=@();if($c.serverIpUrl){$urls+=[string]$c.serverIpUrl};if($c.serverUrl -and $c.serverUrl -ne $c.serverIpUrl){$urls+=[string]$c.serverUrl}
$success=$false
foreach($u in $urls){
  $health=$u.TrimEnd('/')+'/health';Add ('Testing: '+$health)
  try{$sw=[Diagnostics.Stopwatch]::StartNew();$r=Invoke-WebRequest -UseBasicParsing -Uri $health -TimeoutSec 5;$sw.Stop();Add ('  HTTP '+$r.StatusCode+' in '+$sw.ElapsedMilliseconds+' ms');if($r.StatusCode -eq 200){$success=$true}}catch{Add ('  FAIL: '+$_.Exception.Message)}
}
if($c.serverName){try{$p=Test-Connection -ComputerName ([string]$c.serverName) -Count 1 -Quiet;Add ('Ping server name: '+$p)}catch{Add ('Ping server name: error')}}
$targetHost=if($c.serverIp){[string]$c.serverIp}else{[string]$c.serverName};$targetPort=if($c.port){[int]$c.port}else{$Port};try{$tnc=Test-NetConnection -ComputerName $targetHost -Port $targetPort -WarningAction SilentlyContinue;Add ('TCP port open: '+$tnc.TcpTestSucceeded)}catch{Add ('TCP port test: error')}
try{$ft=Test-NetConnection -ComputerName $targetHost -Port $fp -WarningAction SilentlyContinue;Add ('File Service TCP port open: '+$ft.TcpTestSucceeded)}catch{Add ('File Service TCP port test: error')}
if($success){Add 'RESULT: CONNECTED - Client Main Service tak pahunch raha hai.'}else{Add 'RESULT: NOT CONNECTED - Main PC/service/LAN/firewall check karein.'}
$lines|Set-Content -Encoding UTF8 $report
if($success){[System.Windows.Forms.MessageBox]::Show("Client connection OK hai.`n`nReport Desktop par save hui:`n$report",$Product,'OK','Information')|Out-Null;exit 0}else{[System.Windows.Forms.MessageBox]::Show("Client Main Service se connect nahi ho raha.`n`nReport Desktop par save hui:`n$report`n`nIs report ka screenshot/text bhej sakte hain.",$Product,'OK','Warning')|Out-Null;exit 3}
