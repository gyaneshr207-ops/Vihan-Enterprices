function Expand-VihanArchive([string]$Archive,[string]$Destination){
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $root=[IO.Path]::GetFullPath($Destination).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
  $zip=[IO.Compression.ZipFile]::OpenRead($Archive)
  try{
    $entries=New-Object 'System.Collections.Generic.List[object]'
    $seen=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach($entry in $zip.Entries){
      $name=$entry.FullName.Replace('\','/')
      if(!$name -or $name.StartsWith('/') -or $name.Contains(':')){throw 'Unsafe archive path'}
      $parts=$name.TrimEnd('/').Split('/')
      foreach($part in $parts){if(!$part -or $part -eq '.' -or $part -eq '..' -or $part.TrimEnd('.',' ') -ne $part -or $part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)'){throw 'Unsafe archive path component'}}
      $relative=($parts -join [IO.Path]::DirectorySeparatorChar)
      $target=[IO.Path]::GetFullPath([IO.Path]::Combine($root,$relative))
      if(!$target.StartsWith($root,[StringComparison]::OrdinalIgnoreCase) -or !$seen.Add($target)){throw 'Archive path escape or duplicate destination'}
      $entries.Add([pscustomobject]@{Entry=$entry;Target=$target;Directory=$name.EndsWith('/')})
    }
    foreach($item in $entries){
      if($item.Directory){[IO.Directory]::CreateDirectory($item.Target)|Out-Null;continue}
      [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($item.Target))|Out-Null
      [IO.Compression.ZipFileExtensions]::ExtractToFile($item.Entry,$item.Target,$false)
    }
  }finally{$zip.Dispose()}
}
