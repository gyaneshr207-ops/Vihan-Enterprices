$ErrorActionPreference='Continue'
$roots=@("$env:ProgramData\Vihan Enterprices",'C:\ProgramData\Vihan Enterprices','D:\Vihan Enterprices','D:\Vihan Enterprices\Config')|Select-Object -Unique
Write-Host 'Vihan Enterprices - Main Service SAFE diagnostic' -ForegroundColor Cyan
Write-Host 'No file, database, permission, key or scheduled task will be changed.'
Write-Host ('Computer: '+$env:COMPUTERNAME)
foreach($r in $roots){
 Write-Host ('CONFIG LOCATION: '+$r)
 Write-Host ('  server.json present: '+(Test-Path -LiteralPath (Join-Path $r 'server.json')))
 Write-Host ('  protected admin key present: '+(Test-Path -LiteralPath (Join-Path $r 'restore-admin.key')))
}
Write-Host ('Central data directory present: '+(Test-Path 'D:\Vihan Enterprices\Data'))
Write-Host ('Installer source directory present: '+(Test-Path 'D:\VihanEnterpricesInstallerSource'))
Write-Host 'Scheduled tasks (name, state only):'
Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object {$_.TaskName -like '*Vihan*'} | Select-Object TaskName,State | Format-Table -AutoSize
$cfg=$null
try{$cfg=Get-Content -LiteralPath (Join-Path $env:ProgramData 'Vihan Enterprices\server.json') -Raw|ConvertFrom-Json}catch{}
Write-Host 'Local service listening test (does not use protected credentials):'
foreach($port in $(if($cfg.tls.enabled -eq $true){@($cfg.port,$cfg.filePort)}else{@(17867,18080,28080,8000)})){
 try{$r=Invoke-WebRequest -UseBasicParsing -Uri ("{0}://127.0.0.1:{1}/health" -f $(if($cfg.tls.enabled -eq $true){'https'}else{'http'}),$port) -TimeoutSec 2;Write-Host ("  ${port}: HTTP "+[int]$r.StatusCode)}
 catch{if($_.Exception.Response){Write-Host ("  ${port}: HTTP "+[int]$_.Exception.Response.StatusCode)}else{Write-Host ("  ${port}: unreachable")}}
}
Write-Host 'Do not share connection.json, server.json or restore-admin.key contents.'
