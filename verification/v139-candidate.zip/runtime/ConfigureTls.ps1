# Review first. Apply only to an explicitly selected isolated/test or approved live installation.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$CertificateThumbprint,[string]$ServerConfig=(Join-Path $env:ProgramData 'Vihan Enterprices\server.json'),[string]$ConnectionFile=(Join-Path $env:APPDATA 'Vihan Enterprices\connection.json'),[string]$OutputDirectory,[switch]$Apply)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Transport.ps1')
$AppId='{0F915C66-5EB7-46E0-8236-B4D816FE55E1}'
if($CertificateThumbprint -notmatch '^[a-fA-F0-9]{40}$'){throw 'Exact SHA-1 Windows certificate-store thumbprint required (certificate identity, not a password hash)'}
$CertificateThumbprint=$CertificateThumbprint.ToUpperInvariant()
if(!(Test-Path -LiteralPath $ServerConfig -PathType Leaf)){throw 'Existing explicit server configuration required'}
$config=Get-Content -LiteralPath $ServerConfig -Raw|ConvertFrom-Json
$hosts=@('localhost','127.0.0.1',[string]$config.serverName,[string]$config.serverIp)|Where-Object{$_}|Select-Object -Unique
$plan=[pscustomobject]@{mode='review-only';windowsRequired=$true;mainPort=[int]$config.port;filePort=[int]$config.filePort;requiredExactSANs=@($hosts);certificateStore='LocalMachine\My';minimumTls='1.2';requiresTrustedCA=$true;productionChanged=$false}
if(!$Apply){$plan;return}
if($env:OS -ne 'Windows_NT'){throw 'TLS HTTP.sys activation requires Windows; no configuration was changed'}
$principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Run elevated for machine certificate bindings and service restart'}
if(-not ('VihanTlsCertificate' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'TlsCertificate.cs')}
$certificate=Get-Item -LiteralPath ('Cert:\LocalMachine\My\'+$CertificateThumbprint)
[VihanTlsCertificate]::Validate($certificate,[string[]]$hosts)
$config|Add-Member NoteProperty tls ([pscustomobject]@{enabled=$true;certificateThumbprint=$CertificateThumbprint;minimumVersion='TLSv1.2';configuredAt=(Get-Date).ToUniversalTime().ToString('o')}) -Force
$config|Add-Member NoteProperty requireTls $true -Force
[void](Get-VihanTransportScheme $config)
$old=Get-Content -LiteralPath $ServerConfig -Raw|ConvertFrom-Json
if(!$OutputDirectory){$OutputDirectory=Join-Path (Split-Path $ServerConfig -Parent) ('TlsRollback_'+[guid]::NewGuid().ToString('N'))}
if(Test-Path -LiteralPath $OutputDirectory){throw 'Rollback output must be a new directory'}
New-Item -ItemType Directory -Path $OutputDirectory|Out-Null
& icacls.exe $OutputDirectory /inheritance:r /grant:r 'SYSTEM:(OI)(CI)F' 'Administrators:(OI)(CI)F'|Out-Null
if($LASTEXITCODE -ne 0){throw 'Cannot restrict configuration rollback directory; stopped before copying identity files'}
Copy-Item -LiteralPath $ServerConfig -Destination (Join-Path $OutputDirectory 'server.before.json')
$hadConnection=Test-Path -LiteralPath $ConnectionFile
if($hadConnection){Copy-Item -LiteralPath $ConnectionFile -Destination (Join-Path $OutputDirectory 'connection.before.json')}
$bindings=@();$changed=@();$configChanged=$false
function Invoke-NetshChecked([string[]]$Arguments){$answer=& netsh.exe @Arguments 2>&1;if($LASTEXITCODE -ne 0){throw ('HTTP.sys operation failed: '+($answer -join ' '))}}
function Set-ConnectionTls($Connection){
 foreach($name in @('tls','requireTls','port','filePort')){$Connection|Add-Member NoteProperty $name $config.$name -Force}
 $Connection|Add-Member NoteProperty serverUrl (Get-VihanServiceOrigin $config ([string]$config.serverName) ([int]$config.port)) -Force
 $Connection|Add-Member NoteProperty serverIpUrl (Get-VihanServiceOrigin $config ([string]$config.serverIp) ([int]$config.port)) -Force
 Assert-VihanConnectionTransport $Connection
 return $Connection
}
try{
 foreach($port in @([int]$config.port,[int]$config.filePort)){
   $address='0.0.0.0:'+ $port;$existing=& netsh.exe http show sslcert "ipport=$address" 2>&1;$found=$LASTEXITCODE -eq 0
   if($found){if(($existing -join '') -notmatch [regex]::Escape($AppId.Trim('{}')) -or !$old.tls.certificateThumbprint -or (($existing -join '') -replace '\s','') -notmatch [regex]::Escape([string]$old.tls.certificateThumbprint)){throw 'Port certificate binding is not verifiably owned by this installation; no overwrite permitted'}}
   $bindings+=,[pscustomobject]@{address=$address;existed=$found;oldThumbprint=[string]$old.tls.certificateThumbprint}
 }
 # Bind both fixed ports before enabling TLS. Never choose an unbound fallback port.
 foreach($b in $bindings){$verb=if($b.existed){'update'}else{'add'};Invoke-NetshChecked @('http',$verb,'sslcert',('ipport='+$b.address),('certhash='+$CertificateThumbprint),('appid='+$AppId),'certstorename=MY','disablelegacytls=enable');$changed+=,$b}
 foreach($port in @([int]$config.port,[int]$config.filePort)){
   $url='https://+:'+ $port+'/'
   $existing=& netsh.exe http show urlacl "url=$url" 2>&1
   if($LASTEXITCODE -ne 0){Invoke-NetshChecked @('http','add','urlacl',('url='+$url),'sddl=D:(A;;GX;;;SY)(A;;GX;;;BA)')}
 }
 $config|ConvertTo-Json -Depth 30|Set-Content -LiteralPath $ServerConfig -Encoding UTF8;$configChanged=$true
 $connection=if($hadConnection){Get-Content -LiteralPath $ConnectionFile -Raw|ConvertFrom-Json}else{[pscustomobject]@{product=$config.product;serverName=$config.serverName;serverIp=$config.serverIp;token=$config.token}}
 $connection=Set-ConnectionTls $connection
 $parent=Split-Path $ConnectionFile -Parent;New-Item -ItemType Directory -Force -Path $parent|Out-Null
 $connection|ConvertTo-Json -Depth 30|Set-Content -LiteralPath $ConnectionFile -Encoding UTF8
 # This private service file contains the existing device token. Never upload it.
 $connection|ConvertTo-Json -Depth 30|Set-Content -LiteralPath (Join-Path $OutputDirectory 'Vihan_TLS_Client.veservice') -Encoding UTF8
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'RepairMainService.ps1') -NoPrompt
 if($LASTEXITCODE -ne 0){throw 'TLS service restart/health verification failed'}
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 foreach($port in @([int]$config.port,[int]$config.filePort)){
   $response=Invoke-WebRequest -UseBasicParsing -Uri ((Get-VihanServiceOrigin $config '127.0.0.1' $port)+'/health') -TimeoutSec 10
   $health=$response.Content|ConvertFrom-Json
   if($response.StatusCode -ne 200 -or $health.product -ne 'Vihan Enterprices' -or [string]$health.version -ne [string]$config.appVersion){throw 'Main/File HTTPS identity or version mismatch'}
 }
 @{status='TLS activated and HTTPS Main/File health verified';productionDatabaseChanged=$false;clientAction='Import the trusted CA through your managed trust process, then import the private TLS service file on each Client. Restart Client desktop.'}|ConvertTo-Json
}catch{
 if($configChanged){Copy-Item -LiteralPath (Join-Path $OutputDirectory 'server.before.json') -Destination $ServerConfig -Force;if($hadConnection){Copy-Item -LiteralPath (Join-Path $OutputDirectory 'connection.before.json') -Destination $ConnectionFile -Force}else{Remove-Item -LiteralPath $ConnectionFile -Force -ErrorAction SilentlyContinue}}
 foreach($b in $changed){try{if($b.existed){Invoke-NetshChecked @('http','update','sslcert',('ipport='+$b.address),('certhash='+$b.oldThumbprint),('appid='+$AppId),'certstorename=MY')}else{Invoke-NetshChecked @('http','delete','sslcert',('ipport='+$b.address))}}catch{Write-Warning 'TLS binding rollback failed; use restricted rollback directory and verify before restarting services'}}
 if($configChanged){& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'RepairMainService.ps1') -NoPrompt}
 throw
}
