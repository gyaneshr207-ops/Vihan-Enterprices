# Shared, non-migrating Main/File/restore storage contract.
function Assert-VihanAbsolutePath([string]$Path,[string]$Label,[switch]$DDrive){
  if([string]::IsNullOrWhiteSpace($Path) -or $Path -notmatch '^[A-Za-z]:[\\/]' -or $Path -match '(^|[\\/])\.\.([\\/]|$)'){
    throw "$Label must be an absolute Windows path without parent traversal."
  }
  if($DDrive -and $Path -notmatch '^[Dd]:[\\/]'){throw "$Label is not on D:. No automatic database migration is permitted. Review the existing configuration and backup first."}
  return $Path.TrimEnd('\','/')
}
function Get-VihanStoragePaths($Config){
  $data=if($Config.dataDir){[string]$Config.dataDir}else{'D:\Vihan Enterprices\Data'}
  $backup=if($Config.backupDir){[string]$Config.backupDir}else{'D:\Vihan Enterprices\Backups'}
  $data=Assert-VihanAbsolutePath $data 'Central data directory' -DDrive
  $backup=Assert-VihanAbsolutePath $backup 'Backup directory'
  [pscustomobject]@{Data=$data;Database=(Join-Path $data 'VihanEnterprices.db');Blobs=(Join-Path $data 'Blobs');Backup=$backup;Updates='D:\Vihan Enterprices\Updates'}
}
function Assert-VihanDatabaseStart($Config,[string]$Database,[string]$LegacyDirectory){
  if([string]::IsNullOrWhiteSpace([string]$Config.token)){throw 'Main service token is missing; run the supported setup/recovery workflow.'}
  if(Test-Path -LiteralPath $Database){return $false}
  if($Config.initializeDatabase -ne $true){throw "Configured database is missing: $Database. Refusing to create an empty replacement. Restore the correct drive/data or explicitly initialize a new installation."}
  foreach($folder in @((Split-Path $Database -Parent),$LegacyDirectory)){
    foreach($name in @('VihanEnterprices.db','storage.json','storage.wal','blobmeta.json')){
      if($folder -and (Test-Path -LiteralPath (Join-Path $folder $name))){throw 'Existing/legacy data detected. Automatic initialization or migration is blocked; make a verified backup and approve a migration first.'}
    }
  }
  return $true
}
function Update-VihanServerConfig([string]$Path,[hashtable]$Changes){
  $lock=New-Object Threading.Mutex($false,'Global\VihanEnterpricesConfigIO');$held=$false
  try{
    try{$held=$lock.WaitOne(15000)}catch [Threading.AbandonedMutexException]{$held=$true}
    if(!$held){throw 'Server configuration is busy'}
    $latest=Get-Content -LiteralPath $Path -Raw|ConvertFrom-Json
    foreach($name in $Changes.Keys){$latest|Add-Member -NotePropertyName $name -NotePropertyValue $Changes[$name] -Force}
    $temporary=$Path+'.tmp.'+[guid]::NewGuid().ToString('N')
    try{$latest|ConvertTo-Json -Depth 30|Set-Content -Encoding UTF8 $temporary;Move-Item -LiteralPath $temporary -Destination $Path -Force}finally{Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue}
    return $latest
  }finally{if($held){$lock.ReleaseMutex()};$lock.Dispose()}
}
function Stop-VihanTrackedService([string]$PidFile,[string]$ExpectedScript){
  if(!(Test-Path -LiteralPath $PidFile)){return}
  $servicePid=[int](Get-Content -LiteralPath $PidFile -Raw)
  $process=Get-Process -Id $servicePid -ErrorAction SilentlyContinue
  if(!$process){return}
  if($servicePid -eq $PID){throw 'Refusing to stop the current maintenance process'}
  $details=Get-CimInstance Win32_Process -Filter ('ProcessId='+$servicePid) -ErrorAction Stop
  if(!$details -or [string]::IsNullOrWhiteSpace([string]$details.CommandLine) -or ([string]$details.CommandLine).IndexOf($ExpectedScript,[StringComparison]::OrdinalIgnoreCase) -lt 0){throw 'Stale PID belongs to another process; no process was stopped'}
  Stop-Process -Id $servicePid -Force -ErrorAction Stop
  Wait-Process -Id $servicePid -Timeout 10 -ErrorAction SilentlyContinue
  if(Get-Process -Id $servicePid -ErrorAction SilentlyContinue){throw 'Service process did not stop; data replacement is blocked'}
}
function Test-VihanAdminKey([string]$Provided,[string]$KeyFile){
  if([string]::IsNullOrWhiteSpace($Provided) -or !(Test-Path -LiteralPath $KeyFile)){return $false}
  $expected=[IO.File]::ReadAllText($KeyFile).Trim()
  return (![string]::IsNullOrWhiteSpace($expected) -and $Provided -ceq $expected)
}
