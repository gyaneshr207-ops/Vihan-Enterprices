$ErrorActionPreference='Stop'
$Product='Vihan Enterprices'
$install=Split-Path $PSScriptRoot -Parent
$base=Join-Path $env:ProgramData $Product
$server=Join-Path $base 'server.json'
$connection=Join-Path (Join-Path $env:APPDATA $Product) 'connection.json'
$result=[ordered]@{product=$Product;machine=$env:COMPUTERNAME;applicationRoot=$install;dDrivePresent=(Test-Path 'D:\');serverConfigurationPresent=(Test-Path $server);connectionPresent=(Test-Path $connection);protectedAdminKeyPresent=(Test-Path (Join-Path $base 'restore-admin.key'));sqliteIntegrity='Not run on live production data';writePermission='Not inferred from file presence; verify as the service account on Windows'}
if(Test-Path $server){
  $config=Get-Content -LiteralPath $server -Raw|ConvertFrom-Json
  $result.mode='Main PC';$result.configuredDataDirectory=[string]$config.dataDir;$result.configuredBackupDirectory=[string]$config.backupDir
  if($result.dDrivePresent){
    . (Join-Path $PSScriptRoot 'StoragePaths.ps1')
    $paths=Get-VihanStoragePaths $config
    $result.database=$paths.Database;$result.blobs=$paths.Blobs;$result.backup=$paths.Backup;$result.updates=$paths.Updates
    $result.databasePresent=Test-Path -LiteralPath $paths.Database
    if($result.databasePresent){$result.databaseBytes=(Get-Item -LiteralPath $paths.Database).Length}
  }
  $result.systemConfiguration=$base;$result.mainErrorLog=Join-Path $base 'service_error.txt';$result.fileErrorLog=Join-Path $base 'file_service_error.txt'
}else{$result.mode='Client/unconfigured PC; no local writable master is expected'}
# No token, password, key, credential-file content or production record is emitted.
[pscustomobject]$result|ConvertTo-Json -Depth 6
