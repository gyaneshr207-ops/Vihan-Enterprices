# Shared by Main and File service; identity always comes from server-side sessions.
function Initialize-VihanSecurity {
  if(-not ('VihanAuthCrypto' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'VihanAuthCrypto.cs')}
  $db.Exec("CREATE TABLE IF NOT EXISTS auth_sessions(token_hash TEXT PRIMARY KEY,company_id TEXT NOT NULL,username TEXT NOT NULL,login_type TEXT NOT NULL,fingerprint TEXT NOT NULL,expires INTEGER NOT NULL);CREATE TABLE IF NOT EXISTS auth_attempts(identity TEXT PRIMARY KEY,failures INTEGER NOT NULL,window_start INTEGER NOT NULL);CREATE TABLE IF NOT EXISTS auth_draft_keys(identity_hash TEXT PRIMARY KEY,key_id TEXT UNIQUE NOT NULL,draft_key TEXT NOT NULL,owner_text TEXT NOT NULL);")
}
function Convert-VihanCanonical($Value) {
  if($null -eq $Value -or $Value -is [string] -or $Value -is [ValueType]){return $Value}
  if($Value -is [System.Collections.IDictionary]){$result=[ordered]@{};foreach($key in @($Value.Keys|Sort-Object -CaseSensitive)){$result[$key]=Convert-VihanCanonical $Value[$key]};return $result}
  if($Value -is [System.Collections.IEnumerable]){return ,@($Value|ForEach-Object{Convert-VihanCanonical $_})}
  $result=[ordered]@{};foreach($p in @($Value.PSObject.Properties|Sort-Object Name -CaseSensitive)){$result[$p.Name]=Convert-VihanCanonical $p.Value};return $result
}
function Get-VihanCanonicalJson($Value){return (ConvertTo-Json -InputObject (Convert-VihanCanonical $Value) -Depth 100 -Compress)}
function Get-VihanRoot {
  $v=$db.ScalarText("SELECT value FROM kv WHERE key='multiCompanyAdminV2' AND deleted=0",'')
  if(!$v){return [pscustomobject]@{companies=@()}}
  try{return ($v|ConvertFrom-Json)}catch{throw 'Identity store is invalid; Main Admin must review a verified backup. No reset performed.'}
}
function Get-VihanUser($Identity) {
  $root=Get-VihanRoot
  $c=@($root.companies|Where-Object{[string]$_.id -ceq [string]$Identity.companyId -and $_.active -ne $false})
  if($c.Count -ne 1){return $null}
  $u=@($c[0].users|Where-Object{[string]$_.username -ceq [string]$Identity.username -and $_.active -ne $false})
  if($u.Count -ne 1){return $null}
  if($Identity.type -eq 'admin' -and $u[0].role -cne 'Admin'){return $null}
  return $u[0]
}
function Get-VihanFingerprint($Identity,$User) {
  $parts=@([string]$Identity.companyId,[string]$Identity.username,[string]$Identity.type,[string]$User.role,[string]$User.password,[string]$User.passwordHash,[string]$User.staffId)
  if($Identity.type -ne 'admin'){$parts+=,(Get-VihanPermissions $Identity|ConvertTo-Json -Depth 100 -Compress)}
  return [VihanAuthCrypto]::Digest(($parts|ConvertTo-Json -Compress))
}
function Get-VihanIdentity($Request) {
  $token=[string]$Request.Headers['X-Vihan-Session']
  if(!$token -and $Request.Cookies['VE_SESSION']){$token=[string]$Request.Cookies['VE_SESSION'].Value}
  if($token.Length -ne 43){return $null}
  $rows=$db.Query('SELECT * FROM auth_sessions WHERE token_hash='+(Q ([VihanAuthCrypto]::Digest($token)))+' AND expires>'+[DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
  if($rows.Count -ne 1){return $null}
  $r=$rows[0];$identity=[pscustomobject]@{companyId=[string]$r['company_id'];username=[string]$r['username'];type=[string]$r['login_type'];tokenHash=[string]$r['token_hash']}
  $u=Get-VihanUser $identity
  if(!$u -or !( [VihanAuthCrypto]::Equal((Get-VihanFingerprint $identity $u),[string]$r['fingerprint']))){$db.Exec('DELETE FROM auth_sessions WHERE token_hash='+(Q $identity.tokenHash));return $null}
  return $identity
}
function Set-VihanSessionCookie($Context,[string]$Token) {
  $cookie=New-Object Net.Cookie('VE_SESSION',$Token,'/');$cookie.HttpOnly=$true;$cookie.Secure=$Context.Request.IsSecureConnection
  # SameSite header supplied explicitly for Windows Framework Cookie compatibility.
  $Context.Response.AppendHeader('Set-Cookie',($cookie.ToString()+'; Path=/; HttpOnly; SameSite=Strict'+$(if($cookie.Secure){'; Secure'}else{''})))
}
function Invoke-VihanLogin($Context,$Body) {
  $name=[string]$Body.username;$pass=[string]$Body.password;$type=[string]$Body.type;$cid=[string]$Body.companyId
  if($name.Length -gt 128 -or $pass.Length -gt 1024 -or $type -cnotin @('admin','user')){Send-Json $Context @{error='Invalid login'} 401;return}
  $now=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds();$ip=[string]$Context.Request.RemoteEndPoint.Address
  $attemptId=[VihanAuthCrypto]::Digest($ip);$a=$db.Query('SELECT failures,window_start FROM auth_attempts WHERE identity='+(Q $attemptId))
  if($a.Count -and [long]$a[0]['window_start'] -gt ($now-900) -and [int]$a[0]['failures'] -ge 20){Send-Json $Context @{error='Too many login attempts; retry after 15 minutes'} 429;return}
  $identity=$null
  foreach($c in @((Get-VihanRoot).companies)){
    if($c.active -eq $false -or ($type -eq 'user' -and [string]$c.id -cne $cid)){continue}
    foreach($u in @($c.users)){
      if($u.active -eq $false -or [string]$u.username -cne $name -or ($type -eq 'admin' -and $u.role -cne 'Admin')){continue}
      $ok=if($u.passwordHash){[VihanAuthCrypto]::Verify($pass,[string]$u.passwordHash)}else{![string]::IsNullOrEmpty([string]$u.password) -and [VihanAuthCrypto]::Equal($pass,[string]$u.password)}
      if($ok){$identity=[pscustomobject]@{companyId=[string]$c.id;username=$name;type=$type;role=[string]$u.role};break}
    }
    if($identity){break}
  }
  if(!$identity){$db.Exec('INSERT INTO auth_attempts VALUES('+(Q $attemptId)+',1,'+$now+') ON CONFLICT(identity) DO UPDATE SET failures=CASE WHEN window_start<'+($now-900)+' THEN 1 ELSE failures+1 END,window_start=CASE WHEN window_start<'+($now-900)+' THEN '+$now+' ELSE window_start END');Send-Json $Context @{error='Invalid username or password'} 401;return}
  $db.Exec('DELETE FROM auth_attempts WHERE identity='+(Q $attemptId)+';DELETE FROM auth_sessions WHERE expires<='+$now)
  $previousIdentity=Get-VihanIdentity $Context.Request;if($previousIdentity){$db.Exec('DELETE FROM auth_sessions WHERE token_hash='+(Q $previousIdentity.tokenHash))}
  $token=[VihanAuthCrypto]::RandomToken();$u=Get-VihanUser $identity
  $db.Exec('INSERT INTO auth_sessions VALUES('+(Q ([VihanAuthCrypto]::Digest($token)))+','+(Q $identity.companyId)+','+(Q $name)+','+(Q $type)+','+(Q (Get-VihanFingerprint $identity $u))+','+($now+28800)+')')
  Set-VihanSessionCookie $Context $token
  Send-Json $Context @{ok=$true;session=$identity;expiresAt=($now+28800)}
}
function Remove-VihanSecrets($Value,[bool]$AccountContext=$false) {
  if($null -eq $Value -or $Value -is [string] -or $Value -is [ValueType]){return $Value}
  if($Value -is [System.Collections.IEnumerable] -and $Value -isnot [System.Collections.IDictionary] -and $Value -isnot [pscustomobject]){return ,@($Value|ForEach-Object{Remove-VihanSecrets $_ $AccountContext})}
  $result=@{}
  $properties=if($Value -is [System.Collections.IDictionary]){@($Value.Keys|ForEach-Object{[pscustomobject]@{Name=[string]$_;Value=$Value[$_]}})}else{@($Value.PSObject.Properties)}
  foreach($p in $properties){if($AccountContext -and $p.Name -match '^(password|passwordHash|passwordSalt|passwd|credential|credentials|token|secret)$'){continue};$result[$p.Name]=Remove-VihanSecrets $p.Value ($AccountContext -or $p.Name -eq 'users')}
  return [pscustomobject]$result
}
function Get-VihanPermissions($Identity) {
  $root=Get-VihanRoot;$key='all_company_user_roles_v596';$entry=([string]$Identity.companyId+'::'+([string]$Identity.username).ToLowerInvariant())
  if([string]$root.company2ModuleId -ceq [string]$Identity.companyId){$key='company2_user_role_permissions_v408';$entry=[string]$Identity.username}
  $v=$db.ScalarText('SELECT value FROM kv WHERE key='+(Q $key)+' AND deleted=0','{}')|ConvertFrom-Json
  $p=$v.PSObject.Properties[$entry];if($p){return [pscustomobject]@{legacyDefault=$false;values=$(if($null -ne $p.Value){$p.Value}else{[pscustomobject]@{}})}};return [pscustomobject]@{legacyDefault=$true;values=[pscustomobject]@{}}
}
function Test-VihanPermission($Identity,[string]$Permission) {
  if(!$Identity){return $false};if($Identity.type -eq 'admin'){return $true}
  $effective=Get-VihanPermissions $Identity;if($effective.legacyDefault){return $true};$p=$effective.values.PSObject.Properties[$Permission];return ($p -and $p.Value -is [bool] -and $p.Value)
}
function Get-VihanSettingPermission([string]$Key) {
  $map=@{
    'company2_daybook_heads_v224'='setHead';'company2_transaction_heads_v258'='setTxHead';'company2_daybook_settings_v224'='setOpening';'company2_party_customer_master_v345'='setParty';'company2_payment_modes_v534'='setPaymentMode';'company2_items_v442'='setItem';'db452_account_heads_v1'='setHead';'db472_print_settings_v1'='setPrint';'db586_transaction_types'='setTransactionType';'company2_daybook_font_settings_v517'='setFont';'db461_page_font_style'='setFont';'db856_daybook_button_colours'='setFont';'db857_daybook_button_colour_full_control'='setFont';'company2_recent_transaction_columns_v396'='setRecent';'company2_quick_entry_templates_v380'='settings';'company2_data_entry_settings_v672'='dataSettings';'company2_data_entry_settings_meta_v696'='dataSettings';'company2_main_counter_opening_v663'='cashMainSettings';'company2_tally_report_v652'='bankSettings';'db276_opening_desc_history'='setOpening';'db283_opening_adjustments'='setOpening';'db284_sso_adjustments'='setSso';'db286_sso_desc_history'='setSso'
  }
  return $map[$Key]
}
function Get-VihanPolicy([string]$Key) {
  # Explicit namespace inventory. Unknown namespaces are Admin-only, never inferred from a caller company id.
  $map=@{
    'company2_inquiries_v153'=@('c2InquiryAccess','c2InquiryAccess','c2InquiryAccess','c2InquiryAccess');
    'company2_data_entry_v671'=@('c2DataEntryAccess','dataAdd','dataEdit','dataDelete');
    'company2_bank_book_entries_v626'=@('c2BankBookAccess','bankAdd','bankEdit','bankDelete');
    'company2_bank_book_banks_v626'=@('c2BankBookAccess','bankSettings','bankSettings','bankSettings');
    'company2_bank_opening_adjustments_v636'=@('c2BankBookAccess','bankSettings','bankSettings','bankSettings');
    'company2_daybook_accountbook_v224'=@('c2DayBookAccess','save','editAll','delete')
  }
  if($map.ContainsKey($Key)){return ,$map[$Key]};return $null
}
function Test-VihanReadKey($Identity,[string]$Key) {
  if(!$Identity){return $false};if($Identity.type -eq 'admin'){return $true}
  if($Key -eq 'mc_staff_management_v712'){return ![string]::IsNullOrEmpty([string](Get-VihanUser $Identity).staffId)}
  if($Key -eq 'multiCompanyAdminV2' -or $Key -eq 'all_company_user_roles_v596'){return $true}
  if($Key -eq 'company2_user_role_permissions_v408'){return ([string](Get-VihanRoot).company2ModuleId -ceq [string]$Identity.companyId)}
  if([string](Get-VihanRoot).company2ModuleId -cne [string]$Identity.companyId){return $false}
  if($setting=Get-VihanSettingPermission $Key){$module=switch($setting){'dataSettings'{'c2DataEntryAccess'};'cashMainSettings'{'c2CashMainAccess'};'bankSettings'{'c2BankBookAccess'};default{'c2DayBookAccess'}};return (Test-VihanPermission $Identity $module)}
  if($Key -in @('company2_financial_approval_v612','company2_resubmit_requests_v614')){return (Test-VihanPermission $Identity 'c2DayBookAccess')}
  $policy=Get-VihanPolicy $Key;if($policy){return (Test-VihanPermission $Identity $policy[0])}
  # Settings essential for rendering; writes remain separately protected.
  if($Key -in @('company2_daybook_heads_v224','company2_transaction_heads_v258','company2_daybook_settings_v224','company2_party_customer_master_v345','company2_payment_modes_v534','db452_account_heads_v1','db472_print_settings_v1','company2_data_entry_settings_v672','company2_unified_voucher_sequence_v829','company2_bank_voucher_sequence_v654')){return (Test-VihanPermission $Identity 'c2DayBookAccess') -or (Test-VihanPermission $Identity 'c2DataEntryAccess') -or (Test-VihanPermission $Identity 'c2BankBookAccess')}
  return $false
}
function Get-VihanProjectedValue($Identity,[string]$Key,[string]$Value) {
  try{$v=(ConvertFrom-Json ('{"value":'+$Value+'}')).value}catch{if($Key -in @('multiCompanyAdminV2','mc_staff_management_v712','company2_user_role_permissions_v408','all_company_user_roles_v596')){throw 'Protected storage record is malformed; no raw record was returned'};return $Value}
  if($Key -eq 'multiCompanyAdminV2' -and $Identity.type -ne 'admin'){
    $v.companies=@($v.companies|Where-Object{[string]$_.id -ceq [string]$Identity.companyId})
    foreach($c in $v.companies){$c.users=@($c.users|ForEach-Object{if([string]$_.username -ceq [string]$Identity.username){$_}else{[pscustomobject]@{username=$_.username;fullName=$_.fullName;signature=$_.signature;role=$_.role;active=$_.active}}});foreach($entry in @(@('students','moduleStudents'),@('joinings','moduleStudentJoining'),@('leaves','moduleStudentLeave'),@('payments','modulePayment'),@('records','moduleRecords'))){if(!(Test-VihanPermission $Identity $entry[1])){$c|Add-Member NoteProperty $entry[0] @() -Force}}}
    # Drop global settings/staff metadata from a company user's aggregate.
    foreach($c in $v.companies){$c|Add-Member NoteProperty studentModule ([string]$c.id -ceq [string]$v.studentCompanyId) -Force;foreach($f in @('address','phone','signature')){if(!$c.PSObject.Properties[$f]){$c|Add-Member NoteProperty $f ''}};foreach($u in $c.users){foreach($f in @('signature','aadhaar','pan','phone','fullName','photo','idImage')){if(!$u.PSObject.Properties[$f]){$u|Add-Member NoteProperty $f ''}}}}
    $safe=[pscustomobject]@{companies=$v.companies;company2ModuleId=$v.company2ModuleId;studentCompanyId=$v.studentCompanyId};$v=$safe
  }
  if($Key -eq 'mc_staff_management_v712' -and $Identity.type -ne 'admin'){$v=Get-VihanOwnStaffView $Identity $v}
  if($Key -in @('company2_financial_approval_v612','company2_resubmit_requests_v614') -and $Identity.type -ne 'admin'){$v=@($v|Where-Object{[string]$_.companyId -ceq [string]$Identity.companyId -and [string]$_.user -ceq [string]$Identity.username})}
  if($Key -eq 'company2_user_role_permissions_v408' -and $Identity.type -ne 'admin'){$o=@{};$p=$v.PSObject.Properties[[string]$Identity.username];if($p){$o[$p.Name]=$p.Value};$v=$o}
  if($Key -eq 'all_company_user_roles_v596' -and $Identity.type -ne 'admin'){$o=@{};$p=$v.PSObject.Properties[([string]$Identity.companyId+'::'+([string]$Identity.username).ToLowerInvariant())];if($p){$o[$p.Name]=$p.Value};$v=$o}
  return (Get-VihanCanonicalJson (Remove-VihanSecrets $v))
}
function Get-VihanSecureSnapshot($Identity) {
  $items=@{};$revs=@{}
  foreach($r in $db.Query('SELECT key,value,deleted,key_rev,updated_at,client_id FROM kv')){
    $k=[string]$r['key'];if(!(Test-VihanReadKey $Identity $k)){continue}
    $items[$k]=@{value=(Get-VihanProjectedValue $Identity $k ([string]$r['value']));deleted=([int]$r['deleted'] -ne 0);keyRev=[long]$r['key_rev'];updatedAt=[string]$r['updated_at'];clientId=[string]$r['client_id']};$revs[$k]=[long]$r['key_rev']
  }
  return @{revision=($db.ScalarLong("SELECT CAST(v AS INTEGER) FROM meta WHERE k='revision'",0));items=$items;keyRevs=$revs;full=$true}
}
function Assert-VihanTransactionAction($Identity,$Row,$Policy,[string]$Action){
  if($Policy[0] -ne 'c2DayBookAccess'){return}
  $prefix=switch -Regex ([string]$Row.type){'^purchase$'{'purchase'};'^sales?$'{'sales'};default{''}}
  if($prefix){$suffix=switch($Action){'add'{'Save'};'edit'{'Edit'};default{'Delete'}};if(!(Test-VihanPermission $Identity ($prefix+$suffix))){throw 'Purchase/Sales action permission denied'}}
  if($Action -ne 'delete' -and $Row.date){$d=[datetime]::MinValue;if(![datetime]::TryParseExact([string]$Row.date,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$d)){throw 'Invalid transaction date'};if($d.Date -lt [datetime]::Today -and !(Test-VihanPermission $Identity 'oldDate')){throw 'Past-date permission denied'};if($d.Date -gt [datetime]::Today -and !(Test-VihanPermission $Identity 'futureDate')){throw 'Future-date permission denied'}}
}
function Assert-VihanRows($Identity,$Old,$New,$Policy) {
  $before=@{};$after=@{}
  foreach($row in @($Old)){if($null -eq $row){continue};if(!$row.id -or $before.ContainsKey([string]$row.id)){throw 'Unique row id required'};$before[[string]$row.id]=$row}
  foreach($row in @($New)){if($null -eq $row){continue};if(!$row.id -or $after.ContainsKey([string]$row.id)){throw 'Unique row id required'};$after[[string]$row.id]=$row}
  foreach($id in $before.Keys){if(!$after.ContainsKey($id)){Assert-VihanTransactionAction $Identity $before[$id] $Policy 'delete';if(!(Test-VihanPermission $Identity $Policy[3])){throw 'Delete permission denied'}}elseif((Get-VihanCanonicalJson $before[$id]) -cne (Get-VihanCanonicalJson $after[$id])){Assert-VihanTransactionAction $Identity $after[$id] $Policy 'edit';if(!(Test-VihanPermission $Identity $Policy[2]) -and !(($Policy[2] -in @('editAll','bankEdit')) -and (Test-VihanPermission $Identity 'editOwn') -and [string]$before[$id].createdBy -ceq [string]$Identity.username)){throw 'Edit permission denied'};if($after[$id].createdBy -cne $before[$id].createdBy){throw 'Record ownership cannot be reassigned'}}}
  foreach($id in $after.Keys){if(!$before.ContainsKey($id)){Assert-VihanTransactionAction $Identity $after[$id] $Policy 'add';if(!(Test-VihanPermission $Identity $Policy[1])){throw 'Add permission denied'}}}
}
function Assert-VihanWrite($Identity,$Op) {
  $key=[string]$Op.key;$current=$db.ScalarText('SELECT value FROM kv WHERE key='+(Q $key)+' AND deleted=0','null')
  if($Identity.type -eq 'admin'){
    if($key -eq 'multiCompanyAdminV2' -and $Op.op -eq 'remove'){throw 'Cannot delete identity store'}
    if($key -eq 'multiCompanyAdminV2'){
      $old=$current|ConvertFrom-Json;$new=[string]$Op.value|ConvertFrom-Json
      # Credentials are never accepted in generic storage writes. Preserve existing server-side fields.
      foreach($c in @($new.companies)){foreach($u in @($c.users)){
        if($u.password -or $u.passwordHash){throw 'Use the protected user credentials API'}
        $previous=@($old.companies|Where-Object{[string]$_.id -ceq [string]$c.id}|ForEach-Object{$_.users}|Where-Object{[string]$_.username -ceq [string]$u.username})
        if($previous.Count -eq 1){foreach($field in @('password','passwordHash')){if($previous[0].PSObject.Properties[$field]){$u|Add-Member NoteProperty $field $previous[0].$field -Force}}}
        elseif($u.active -ne $false){throw 'Create new users with the protected user credentials API'}
      }}
      $admins=@($new.companies|Where-Object{$_.active -ne $false}|ForEach-Object{$_.users}|Where-Object{$_.role -ceq 'Admin' -and $_.active -ne $false});if(!$admins.Count){throw 'At least one active Admin must remain'}
      $Op.value=$new|ConvertTo-Json -Depth 100 -Compress
    }
    return
  }
  if($Op.op -ne 'remove'){$parsed=(ConvertFrom-Json ('{"value":'+[string]$Op.value+'}')).value;Assert-VihanDisplayIds $parsed}
  if($key -eq 'mc_staff_management_v712'){if($Op.op -eq 'remove'){throw 'Staff deletion requires Admin'};$Op.value=Merge-VihanOwnAttendance $Identity ([string]$Op.value);return}
  if($key -eq 'multiCompanyAdminV2'){if($Op.op -eq 'remove'){throw 'Cannot remove company aggregate'};$Op.value=Merge-VihanCompanyWrite $Identity ([string]$Op.value);return}
  if(!(Test-VihanReadKey $Identity $key)){throw 'Company/module permission denied'}
  if($key -in @('company2_financial_approval_v612','company2_resubmit_requests_v614')){if($Op.op -eq 'remove'){throw 'Audit/request deletion requires Admin'};$Op.value=Merge-VihanOwnRequests $Identity $key ([string]$Op.value);return}
  $settingPermission=Get-VihanSettingPermission $key;if($settingPermission){
    if($key -eq 'company2_daybook_settings_v224'){
      $before=$current|ConvertFrom-Json;$after=if($Op.op -eq 'remove'){[pscustomobject]@{}}else{[string]$Op.value|ConvertFrom-Json}
      $fields=@($before.PSObject.Properties.Name)+@($after.PSObject.Properties.Name)|Select-Object -Unique
      foreach($field in $fields){if(!$field){continue};if(($before.$field|ConvertTo-Json -Compress) -ceq ($after.$field|ConvertTo-Json -Compress)){continue};$required=if($field -match '(?i)sso'){'setSso'}elseif($field -match '(?i)opening'){'setOpening'}else{'settings'};if(!(Test-VihanPermission $Identity $required)){throw ('Settings field permission denied: '+$required)}}
    }elseif(!(Test-VihanPermission $Identity $settingPermission)){throw ('Settings permission denied: '+$settingPermission)};return
  }
  if($key -in @('company2_unified_voucher_sequence_v829','company2_bank_voucher_sequence_v654')){if(!(Test-VihanPermission $Identity 'save') -and !(Test-VihanPermission $Identity 'bankAdd') -and !(Test-VihanPermission $Identity 'cashMainAdd')){throw 'Voucher mutation denied'};[long]$n=0;[long]$prev=0;[void][long]::TryParse($current,[ref]$prev);if($Op.op -eq 'remove' -or ![long]::TryParse([string]$Op.value,[ref]$n) -or $n -lt $prev -or $n -gt ($prev+1000)){throw 'Invalid voucher counter change'};return}
  $policy=Get-VihanPolicy $key
  if(!$policy){throw 'Settings or unmapped storage mutation requires Admin'}
  if($Op.op -eq 'remove'){if(!(Test-VihanPermission $Identity $policy[3])){throw 'Delete permission denied'};return}
  $old=$current|ConvertFrom-Json;$new=[string]$Op.value|ConvertFrom-Json
  Assert-VihanRows $Identity $old $new $policy
  foreach($row in @($new)){if($null -eq $row){continue};$prior=@($old|Where-Object{[string]$_.id -ceq [string]$row.id});if(!$prior.Count){$row|Add-Member NoteProperty createdBy ([string]$Identity.username) -Force;$row|Add-Member NoteProperty updatedBy ([string]$Identity.username) -Force}elseif((Get-VihanCanonicalJson $row) -cne (Get-VihanCanonicalJson $prior[0])){$row|Add-Member NoteProperty updatedBy ([string]$Identity.username) -Force}}
  $Op.value=ConvertTo-Json -InputObject @($new) -Depth 100 -Compress
}
function Assert-VihanBlobAccess($Identity,[string]$Database,[string]$Store,[string]$Action,$Record=$null) {
  if(!$Identity){throw [UnauthorizedAccessException]::new('User session required')}
  if($Identity.type -eq 'admin'){return}
  if($Record){Assert-VihanDisplayIds $Record}
  if([string](Get-VihanRoot).company2ModuleId -cne [string]$Identity.companyId){throw [UnauthorizedAccessException]::new('Company file access denied')}
  $rules=@{'OfficeAllDocumentsV819'=@('c2DocumentsAccess','docs');'OfficeAllSoftwareV821'=@('c2SoftwareAccess','software');'company2_counter2_pdf_database_v203'=@('c2CounterAccess','counter');'company2_data_entry_documents_v675'=@('c2DataEntryAccess','data')}
  if(!$rules.ContainsKey($Database)){throw [UnauthorizedAccessException]::new('Unmapped/company file access denied')}
  $r=$rules[$Database];if(!(Test-VihanPermission $Identity $r[0])){throw [UnauthorizedAccessException]::new('Module file access denied')}
  $perm=if($r[1] -eq 'counter'){'c2CounterAccess'}elseif($r[1] -eq 'data'){switch($Action){'read'{'dataView'};'delete'{'dataDelete'};'create'{'dataAdd'};default{'dataEdit'}}}elseif($Store -eq 'folders'){switch($Action){'read'{''};'delete'{$r[1]+'DeleteFolder'};'create'{$r[1]+'CreateFolder'};default{$r[1]+'RenameFolder'}}}else{switch($Action){'read'{''};'file'{if(Test-VihanPermission $Identity ($r[1]+'Open')){''}else{$r[1]+'Download'}};'delete'{$r[1]+'DeleteFile'};'create'{$r[1]+'Upload'};default{$r[1]+'Edit'}}}
  if($Action -eq 'edit' -and $Record -and $r[1] -in @('docs','software')){
    $lookup=([string]$Database+'|'+[string]$Store+'|'+[string]$Record.id);$existing=$db.Query('SELECT record_json FROM blob_meta WHERE blob_key='+(Q $lookup)+' LIMIT 1')
    if($existing.Count){$before=[string]$existing[0]['record_json']|ConvertFrom-Json;$after=(Get-VihanCanonicalJson $Record.record)|ConvertFrom-Json;$field=if($Store -eq 'folders'){'parentId'}else{'folderId'};$moved=([string]$before.$field -cne [string]$after.$field);foreach($f in @($field,'updatedAt')){$before.PSObject.Properties.Remove($f);$after.PSObject.Properties.Remove($f)};if($moved -and (Get-VihanCanonicalJson $before) -ceq (Get-VihanCanonicalJson $after)){$perm=$r[1]+$(if($Store -eq 'folders'){'MoveFolder'}else{'MoveFile'})}}
  }
  if($perm -and !(Test-VihanPermission $Identity $perm)){throw [UnauthorizedAccessException]::new('File action permission denied')}
  if($Record -and $Action -in @('create','edit') -and $r[1] -in @('docs','software')){
    if([string]$Record.record.id -cne [string]$Record.id){throw [UnauthorizedAccessException]::new('Attachment identity mismatch')}
    if($Store -notin @('folders','files')){throw [UnauthorizedAccessException]::new('Unknown file store')}
    $key=([string]$Database+'|'+[string]$Store+'|'+[string]$Record.id)
    $rows=$db.Query('SELECT record_json FROM blob_meta WHERE blob_key='+(Q $key)+' LIMIT 1')
    if($rows.Count -and $Action -eq 'edit'){
      $old=[string]$rows[0]['record_json']|ConvertFrom-Json
      $field=if($Store -eq 'folders'){'parentId'}else{'folderId'}
      if([string]$old.$field -cne [string]$Record.record.$field){$move=$r[1]+$(if($Store -eq 'folders'){'MoveFolder'}else{'MoveFile'});if(!(Test-VihanPermission $Identity $move)){throw [UnauthorizedAccessException]::new('Move permission denied')}}
    }
    if($Store -eq 'files' -and ($Record.PSObject.Properties['blobBase64'] -or $Record.PSObject.Properties['blobType'])){if(!(Test-VihanPermission $Identity ($r[1]+'Upload'))){throw [UnauthorizedAccessException]::new('Upload permission denied')}}
  }

}
function Test-VihanRequestOrigin($Request) {
  $origin=[string]$Request.Headers['Origin'];if(!$origin){return $true}
  try{$u=[uri]$origin;$hostName=$Request.Url.DnsSafeHost;return ($u.Scheme -eq $Request.Url.Scheme -and $u.DnsSafeHost -eq $hostName -and $u.Port -in @([int]$config.port,[int]$config.filePort))}catch{return $false}
}
function Invoke-VihanSecurityGate($Context) {
  $Context.Response.Headers['Cache-Control']='no-store'
  $r=$Context.Request;$path=$r.Url.AbsolutePath;$method=$r.HttpMethod.ToUpperInvariant();$script:RequestIdentity=$null
  if(!(Test-VihanRequestOrigin $r)){Send-Json $Context @{error='Request origin denied'} 403;return $false}
  if($path -eq '/api/auth/info'){
    $companies=@((Get-VihanRoot).companies|Where-Object{$_.active -ne $false}|ForEach-Object{@{id=$_.id;name=$_.name;logo=$_.logo;active=$true;users=@();records=@()}})
    Send-Json $Context @{securityVersion=1;companies=$companies;requiresProvisioning=($companies.Count -eq 0)};return $false
  }
  if($path -eq '/api/auth/login' -and $method -eq 'POST'){Invoke-VihanLogin $Context (Read-Body $Context);return $false}
  if($path -in @('/api/status','/api/update/status','/api/update/package','/api/update/heartbeat')){return $true}
  $identity=Get-VihanIdentity $r
  if(!$identity){if($r.Cookies['VE_SESSION'] -and $r.Cookies['VE_SESSION'].Value){Set-VihanSessionCookie $Context ''};Send-Json $Context @{error='User login required';code='LOGIN_REQUIRED';securityVersion=1} 401;return $false}
  $script:RequestIdentity=$identity
  if($path -in @('/api/auth/root','/api/storage/batch','/api/storage/set','/api/storage/remove') -and !(Get-Command Plan-Ops -ErrorAction SilentlyContinue)){Send-Json $Context @{error='Use the Main Service for text/identity mutations'} 404;return $false}
  if($path -eq '/api/auth/root' -and $method -eq 'POST'){Invoke-VihanCredentialRoot $Context $identity (Read-Body $Context);return $false}
  if($path -eq '/api/auth/logout' -and $method -eq 'POST'){$db.Exec('DELETE FROM auth_sessions WHERE token_hash='+(Q $identity.tokenHash));Set-VihanSessionCookie $Context '';Send-Json $Context @{ok=$true};return $false}
  if($path -eq '/api/auth/draft-key'){Send-VihanDraftKey $Context $identity;return $false}
  if($path -eq '/api/auth/session'){Send-Json $Context @{session=@{type=$identity.type;companyId=$identity.companyId;username=$identity.username;role=[string](Get-VihanUser $identity).role};securityVersion=1};return $false}
  if($path -eq '/api/snapshot'){Send-Json $Context (Get-VihanSecureSnapshot $identity);return $false}
  if($path -eq '/api/storage/changes'){$since=[long]0;[void][long]::TryParse([string]$r.QueryString['since'],[ref]$since);Send-Json $Context (Get-VihanSecureChanges $identity $since);return $false}
  if($path -eq '/api/offline/clients' -and $identity.type -eq 'admin'){return $true}
  if($path.StartsWith('/api/offline/')){
    $pc=[string]$r.QueryString['pc'];if(!(Test-OfflineAllowed $pc)){Send-Json $Context @{error='Offline copy is not allowed for this PC'} 403;return $false}
    if($path -eq '/api/offline/permission'){Send-Json $Context @{ok=$true;allowed=$true;securityVersion=1};return $false}
    if($path -eq '/api/offline/data'){
      $snapshot=Get-VihanSecureSnapshot $identity
      $snapshot.securityVersion=1;$snapshot.principal=@{type=$identity.type;username=$identity.username;companyId=$identity.companyId;role=[string](Get-VihanUser $identity).role};$snapshot.offlineExpiresAt=([DateTimeOffset]::UtcNow.ToUnixTimeSeconds()+86400)
      Send-Json $Context $snapshot;return $false
    }
    if($path -eq '/api/offline/manifest'){
      $items=@();foreach($row in $db.Query('SELECT * FROM blob_meta ORDER BY updated_at')){
        try{Assert-VihanBlobAccess $identity ([string]$row['db_name']) ([string]$row['store_name']) 'file'}catch{continue}
        $file=[string]$row['blob_file'];$present=($file -and (Test-Path -LiteralPath (Join-Path $BlobDir $file)));$size=if($present){(Get-Item -LiteralPath (Join-Path $BlobDir $file)).Length}else{0}
        $items+=,@{db=[string]$row['db_name'];store=[string]$row['store_name'];id=[string]$row['item_id'];recordJson=([string]$row['record_json']);blobType=[string]$row['blob_type'];hasBlob=[bool]$present;size=$size;updatedAt=[string]$row['updated_at']}
      };Send-Json $Context @{items=$items;securityVersion=1};return $false
    }
    if($path -eq '/api/offline/blob'){try{Assert-VihanBlobAccess $identity ([string]$r.QueryString['db']) ([string]$r.QueryString['store']) 'file'}catch{Send-Json $Context @{error='Offline file access denied'} 403;return $false};return $true}
    Send-Json $Context @{error='Offline Admin session required'} 403;return $false
  }
  if($path.StartsWith('/api/backup') -or $path.StartsWith('/api/update/') -or $path -eq '/api/auth/users'){
    if($identity.type -ne 'admin'){Send-Json $Context @{error='Admin session required'} 403;return $false}
  }
  if($path -eq '/api/storage/batch' -or $path -in @('/api/storage/set','/api/storage/remove')){
    $b=Read-Body $Context;$ops=if($path -eq '/api/storage/batch'){@($b.ops)}else{@([pscustomobject]@{key=$b.key;op=$(if($path.EndsWith('remove')){'remove'}else{'set'});value=$b.value;expectedRev=$b.expectedRev;seq=0})}
    try{foreach($op in $ops){Assert-VihanWrite $identity $op}}catch{Send-Json $Context @{error=$_.Exception.Message} 403;return $false}
    $plan=Plan-Ops $ops ([string]$b.clientId);Commit-Plan $plan
    # Conflict results can contain server credentials or another company's aggregate: project before returning.
    foreach($result in @($plan.results)){if($result.current){$result.current.value=Get-VihanProjectedValue $identity ([string]$result.key) ([string]$result.current.value)}}
    Send-Json $Context @{ok=$true;revision=(Get-Revision);results=@($plan.results)};return $false
  }
  if($path.StartsWith('/api/blob/') -and $method -eq 'GET'){
    $action=if($path -in @('/api/blob/file','/api/blob/get')){'file'}else{'read'}
    try{Assert-VihanBlobAccess $identity ([string]$r.QueryString['db']) ([string]$r.QueryString['store']) $action}catch{Send-Json $Context @{error=$_.Exception.Message} 403;return $false}
  }
  return $true
}
function Merge-VihanCompanyWrite($Identity,$Value) {
  $root=Get-VihanRoot;$incoming=$Value|ConvertFrom-Json
  $companies=@($incoming.companies)
  if($companies.Count -ne 1 -or [string]$companies[0].id -cne [string]$Identity.companyId){throw 'Only own company aggregate is writable'}
  $old=@($root.companies|Where-Object{[string]$_.id -ceq [string]$Identity.companyId})[0];$next=$companies[0]
  $projected=(Get-VihanProjectedValue $Identity 'multiCompanyAdminV2' ($root|ConvertTo-Json -Depth 100 -Compress))|ConvertFrom-Json
  $visible=$projected.companies[0]
  foreach($p in $next.PSObject.Properties){
    if($p.Name -in @('students','joinings','leaves','payments','records')){
      $perm=@{students='moduleStudents';joinings='moduleStudentJoining';leaves='moduleStudentLeave';payments='modulePayment';records='moduleRecords'}[$p.Name]
      $prior=$visible.PSObject.Properties[$p.Name].Value
      if((Get-VihanCanonicalJson $p.Value) -cne (Get-VihanCanonicalJson $prior)){
        if(!(Test-VihanPermission $Identity $perm)){throw ('Permission denied: '+$perm)}
        $old|Add-Member NoteProperty $p.Name $p.Value -Force
      }
    }elseif($p.Name -eq 'users'){
      if((Get-VihanCanonicalJson $p.Value) -cne (Get-VihanCanonicalJson $visible.users)){throw 'User management requires Admin'}
    }elseif($p.Name -ne 'id'){
      $prev=$visible.PSObject.Properties[$p.Name]
      if(!$prev -or (Get-VihanCanonicalJson $p.Value) -cne (Get-VihanCanonicalJson $prev.Value)){
        if($p.Name -notin @('name','address','phone','logo','signature') -or !(Test-VihanPermission $Identity 'companyEdit')){throw ('Company field change denied: '+$p.Name)}
        $old|Add-Member NoteProperty $p.Name $p.Value -Force
      }
    }
  }
  return ($root|ConvertTo-Json -Depth 100 -Compress)
}
function Invoke-VihanCredentialRoot($Context,$Identity,$Body) {
  if($Identity.type -ne 'admin'){Send-Json $Context @{error='Admin required'} 403;return}
  $root=$Body.value|ConvertFrom-Json;$old=Get-VihanRoot
  $seen=@{};$activeAdmins=0
  foreach($c in @($root.companies)){
    if(!$c.id -or $seen.ContainsKey([string]$c.id)){throw 'Unique company id required'};$seen[[string]$c.id]=$true;$names=@{}
    foreach($u in @($c.users)){
      if(!$u.username -or $names.ContainsKey([string]$u.username)){throw 'Unique user name required'};$names[[string]$u.username]=$true
      $previous=@($old.companies|Where-Object{[string]$_.id -ceq [string]$c.id}|ForEach-Object{$_.users}|Where-Object{[string]$_.username -ceq [string]$u.username})
      if($u.password){if($u.role -ceq 'Admin' -and ([string]$u.password).Length -lt 12){throw 'New Admin passwords must have at least 12 characters'};$h=[VihanAuthCrypto]::HashPassword([string]$u.password);$u.PSObject.Properties.Remove('password');$u|Add-Member NoteProperty passwordHash $h -Force}
      elseif($u.passwordHash){throw 'Client-provided password hash is not accepted'}
      elseif($previous.Count -eq 1){foreach($f in @('password','passwordHash')){if($previous[0].PSObject.Properties[$f]){$u|Add-Member NoteProperty $f $previous[0].$f -Force}}}
      elseif($u.active -ne $false){throw 'New or renamed user requires password'}
      if($c.active -ne $false -and $u.active -ne $false -and $u.role -eq 'Admin'){$activeAdmins++}
    }
  }
  if(!$activeAdmins){throw 'At least one active Admin must remain'}
  $op=[pscustomobject]@{key='multiCompanyAdminV2';value=($root|ConvertTo-Json -Depth 100 -Compress);op='set';expectedRev=[long]$Body.expectedRev;seq=0}
  $plan=Plan-Ops @($op) 'credential-admin'
  if(@($plan.planned).Count -ne 1){Send-Json $Context @{error='Data changed; refresh before user/password changes'} 409;return}
  Commit-Plan $plan
  Send-Json $Context @{ok=$true;snapshot=(Get-VihanSecureSnapshot $Identity);reauthenticate=$true}
}

function Clear-VihanRestoredSessions($Database) {
  if($Database.ScalarLong("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='auth_sessions'",0)){$Database.Exec('DELETE FROM auth_sessions;')}
}

function Merge-VihanOwnRequests($Identity,[string]$Key,[string]$Value){
  $oldJson=$db.ScalarText('SELECT value FROM kv WHERE key='+(Q $Key)+' AND deleted=0','[]');$old=@($oldJson|ConvertFrom-Json);$new=@($Value|ConvertFrom-Json)
  $own=@($old|Where-Object{$_ -and [string]$_.companyId -ceq [string]$Identity.companyId -and [string]$_.user -ceq [string]$Identity.username});$others=@($old|Where-Object{$_ -and ([string]$_.companyId -cne [string]$Identity.companyId -or [string]$_.user -cne [string]$Identity.username)})
  $seen=@{};foreach($row in $new){if(!$row.id -or $seen.ContainsKey([string]$row.id) -or [string]$row.companyId -cne [string]$Identity.companyId -or [string]$row.user -cne [string]$Identity.username){throw 'Request identity/ownership denied'};$seen[[string]$row.id]=$true
    $prior=@($own|Where-Object{[string]$_.id -ceq [string]$row.id})
    if(!$prior.Count){if($Key -ne 'company2_financial_approval_v612' -or $row.status -cne 'Pending' -or $row.decisionBy -or $row.decisionAt -or $row.autoApproved){throw 'Only pending requests may be created by users'};continue}
    if((Get-VihanCanonicalJson $row) -ceq (Get-VihanCanonicalJson $prior[0])){continue}
    $oldCopy=(Get-VihanCanonicalJson $prior[0])|ConvertFrom-Json;$newCopy=(Get-VihanCanonicalJson $row)|ConvertFrom-Json
    if($Key -eq 'company2_resubmit_requests_v614'){
      if($prior[0].status -cne 'Open' -or $row.status -cne 'Resubmitted'){throw 'Resubmit status transition denied'};$allowed=@('status','completedAt')
    }else{
      if($prior[0].status -cne 'Resubmit Requested' -or $row.status -cne 'Resubmitted / Auto Approved' -or $row.decisionBy -cne 'AUTO' -or [string]$row.record.id -cne [string]$prior[0].record.id){throw 'Users cannot approve/reject or rewrite another request'};$allowed=@('status','decisionAt','decisionBy','record')
    }
    foreach($field in $allowed){$oldCopy.PSObject.Properties.Remove($field);$newCopy.PSObject.Properties.Remove($field)}
    if((Get-VihanCanonicalJson $oldCopy) -cne (Get-VihanCanonicalJson $newCopy)){throw 'Protected request field change denied'}
  }
  foreach($row in $own){if(!$seen.ContainsKey([string]$row.id)){throw 'Request deletion requires Admin'}}
  return (ConvertTo-Json -InputObject @($others+$new) -Depth 100 -Compress)
}

function Get-VihanSecureChanges($Identity,[long]$Since){
  $revision=$db.ScalarLong("SELECT CAST(v AS INTEGER) FROM meta WHERE k='revision'",0)
  $oldest=$db.ScalarLong('SELECT COALESCE(MIN(revision),0) FROM changes',0)
  if($Since -le 0 -or $Since -gt $revision -or ($oldest -eq 0 -and $Since -lt $revision) -or ($oldest -gt 0 -and $Since -lt ($oldest-1))){return (Get-VihanSecureSnapshot $Identity)}
  $changes=@()
  foreach($item in $db.Query('SELECT key,MAX(revision) AS last_revision FROM changes WHERE revision>'+ $Since+' GROUP BY key ORDER BY last_revision')){
    $key=[string]$item['key'];if(!(Test-VihanReadKey $Identity $key)){continue}
    # Return CURRENT values, never credential-bearing historical versions or stale aggregate projections.
    $rows=$db.Query('SELECT value,deleted,key_rev,revision,updated_at,client_id FROM kv WHERE key='+(Q $key)+' LIMIT 1');if(!$rows.Count){continue};$row=$rows[0]
    $value=if([int]$row['deleted']){''}else{Get-VihanProjectedValue $Identity $key ([string]$row['value'])}
    $changes+=,@{key=$key;value=$value;deleted=([int]$row['deleted'] -ne 0);keyRev=[long]$row['key_rev'];revision=[long]$row['revision'];updatedAt=[string]$row['updated_at'];clientId=[string]$row['client_id']}
  }
  return @{full=$false;revision=$revision;changes=$changes}
}

function Send-VihanDraftKey($Context,$Identity){
  $user=Get-VihanUser $Identity
  $identityHash=[VihanAuthCrypto]::Digest((@([string]$Identity.type,[string]$Identity.companyId,[string]$Identity.username,[string]$user.password,[string]$user.passwordHash,[string]$user.staffId)|ConvertTo-Json -Compress))
  $owner=ConvertTo-Json -InputObject @([string]$Identity.type,[string]$Identity.companyId,[string]$Identity.username) -Compress
  $db.Exec('INSERT OR IGNORE INTO auth_draft_keys VALUES('+(Q $identityHash)+','+(Q ([guid]::NewGuid().ToString('N')))+','+(Q ([VihanAuthCrypto]::RandomToken()))+','+(Q $owner)+')')
  $own=$db.Query('SELECT key_id,draft_key,owner_text FROM auth_draft_keys WHERE identity_hash='+(Q $identityHash))[0]
  $kid=[string]$Context.Request.QueryString['kid']
  if(!$kid -or $kid -ceq [string]$own['key_id']){Send-Json $Context @{kid=[string]$own['key_id'];key=[string]$own['draft_key'];owner=[string]$own['owner_text']};return}
  if($Identity.type -ne 'admin'){Send-Json $Context @{error='Private draft key does not belong to this account'} 403;return}
  $rows=$db.Query('SELECT key_id,draft_key,owner_text FROM auth_draft_keys WHERE key_id='+(Q $kid))
  if(!$rows.Count){Send-Json $Context @{error='Draft recovery key not found in this Main database/backup'} 404;return}
  Send-Json $Context @{kid=[string]$rows[0]['key_id'];key=[string]$rows[0]['draft_key'];owner=[string]$rows[0]['owner_text'];adminRecovery=$true}
}
function Get-VihanOwnStaffView($Identity,$Data){
  $staffId=[string](Get-VihanUser $Identity).staffId
  return [pscustomobject]@{staff=@($Data.staff|Where-Object{[string]$_.id -ceq $staffId});attendance=@($Data.attendance|Where-Object{[string]$_.staffId -ceq $staffId});salary=@($Data.salary|Where-Object{[string]$_.staffId -ceq $staffId});staffAccount=@($Data.staffAccount|Where-Object{[string]$_.staffId -ceq $staffId});activity=@($Data.activity|Where-Object{[string]$_.staffId -ceq $staffId});attSettings=$(if($Data.attSettings){$Data.attSettings}else{[pscustomobject]@{}})}
}
function Merge-VihanOwnAttendance($Identity,[string]$Value){
  $staffId=[string](Get-VihanUser $Identity).staffId;if(!$staffId){throw 'Staff link required'}
  $raw=$db.ScalarText("SELECT value FROM kv WHERE key='mc_staff_management_v712' AND deleted=0",'{}')
  $data=$raw|ConvertFrom-Json;$view=Get-VihanOwnStaffView $Identity $data;$new=$Value|ConvertFrom-Json
  if($view.staff.Count -ne 1 -or $view.staff[0].active -eq $false){throw 'Active linked Staff record required'}
  foreach($p in $new.PSObject.Properties){if($p.Name -notin @('staff','attendance','salary','staffAccount','activity','attSettings')){throw 'Staff management requires Admin'}}
  foreach($field in @('staff','salary','staffAccount','attSettings')){if((Get-VihanCanonicalJson $new.$field) -cne (Get-VihanCanonicalJson $view.$field)){throw 'Staff/payroll/settings changes require Admin'}}
  $now=Get-Date;$today=$now.ToString('yyyy-MM-dd');$time=$now.ToString('HH:mm');$map=@{};$allIds=@{};$dates=@{}
  foreach($row in @($data.attendance)){if($row){$allIds[[string]$row.id]=$row}}
  foreach($row in @($new.attendance)){
    if(!$row.id -or [string]$row.staffId -cne $staffId -or $map.ContainsKey([string]$row.id) -or $dates.ContainsKey([string]$row.date)){throw 'Attendance identity/duplicate date denied'}
    $dates[[string]$row.date]=$true;$prior=$allIds[[string]$row.id]
    if($prior -and [string]$prior.staffId -cne $staffId){throw 'Another Staff attendance cannot be changed'}
    if($prior -and (Get-VihanCanonicalJson $prior) -ceq (Get-VihanCanonicalJson $row)){$map[[string]$row.id]=$prior;continue}
    if([string]$row.date -cne $today){throw 'Self attendance can change only today'}
    if(!$prior){
      if([string]$row.companyId -cne [string]$Identity.companyId -or !$row.inTime){throw 'Own current-company Mark In required'}
      foreach($p in $row.PSObject.Properties){if($p.Name -notin @('id','staffId','date','companyId','inTime','outTime','status','remark','updatedAt','source')){throw 'Unexpected self-attendance field'}}
      if($row.remark -and $row.remark -cne 'User Login Attendance'){throw 'Self attendance remark is fixed'}
      $row.inTime=$time;$row|Add-Member NoteProperty status 'Present' -Force;if($row.outTime){$row.outTime=$time}
    }else{
      $before=(Get-VihanCanonicalJson $prior)|ConvertFrom-Json;$after=(Get-VihanCanonicalJson $row)|ConvertFrom-Json
      foreach($field in @('inTime','outTime','status','updatedAt','source','workingMinutes','lateMinutes','earlyOutMinutes')){$before.PSObject.Properties.Remove($field);$after.PSObject.Properties.Remove($field)}
      if((Get-VihanCanonicalJson $before) -cne (Get-VihanCanonicalJson $after)){throw 'Protected attendance field change denied'}
      if($prior.inTime -and [string]$row.inTime -cne [string]$prior.inTime){throw 'Mark In already recorded'}
      if($prior.outTime -and [string]$row.outTime -cne [string]$prior.outTime){throw 'Mark Out already recorded'}
      $markIn=(!$prior.inTime -and $row.inTime);$markOut=(!$prior.outTime -and $row.outTime)
      if(!$markIn -and !$markOut){throw 'Attendance changes require a Mark In/Out transition'}
      if($markIn){$row.inTime=$time;$row.status='Present'}elseif([string]$row.status -cne [string]$prior.status){throw 'Attendance status change denied'}
      if($markOut){if(!$row.inTime -or $time -clt [string]$row.inTime){throw 'Mark Out cannot precede Mark In'};$row.outTime=$time}
    }
    foreach($field in @('workingMinutes','lateMinutes','earlyOutMinutes')){$row.PSObject.Properties.Remove($field)}
    $row|Add-Member NoteProperty updatedAt $now.ToString('o') -Force;$row|Add-Member NoteProperty source 'user-login' -Force;$map[[string]$row.id]=$row
  }
  foreach($row in @($view.attendance)){if(!$map.ContainsKey([string]$row.id)){throw 'Attendance deletion requires Admin'}}
  $other=@($data.attendance|Where-Object{[string]$_.staffId -cne $staffId});$data|Add-Member NoteProperty attendance @($other+@($map.Values)) -Force
  $newLogs=@();$ownToday=@($map.Values|Where-Object{[string]$_.date -ceq $today})
  foreach($log in @($new.activity)){
    $prior=@($data.activity|Where-Object{[string]$_.id -ceq [string]$log.id})
    if($prior.Count){if([string]$prior[0].staffId -cne $staffId){throw 'Another Staff activity cannot be changed'};continue}
    if(!$log.id -or $log.activity -cnotin @('User Mark In','User Mark Out') -or [string]$log.staff -cne [string]$view.staff[0].name -or !$ownToday.Count){throw 'Self attendance activity denied'}
    $eventTime=if($log.activity -ceq 'User Mark In'){$ownToday[0].inTime}else{$ownToday[0].outTime};if(!$eventTime){throw 'Attendance event has not occurred'}
    if(@($data.activity|Where-Object{[string]$_.staffId -ceq $staffId -and $_.activity -ceq $log.activity -and ([string]$_.details).StartsWith($today)}).Count){continue}
    $newLogs+=,[pscustomobject]@{id=[string]$log.id;ts=$now.ToString('o');activity=[string]$log.activity;staff=[string]$view.staff[0].name;staffId=$staffId;actor=[string]$Identity.username;details=($today+' '+[string]$eventTime)}
  }
  if($newLogs.Count -gt 2){throw 'Too many self-attendance activities'}
  $data|Add-Member NoteProperty activity @(@($newLogs+@($data.activity))|Select-Object -First 1000) -Force
  return (ConvertTo-Json -InputObject $data -Depth 100 -Compress)
}
function Assert-VihanDisplayIds($Value){
  if($null -eq $Value -or $Value -is [string] -or $Value -is [ValueType]){return}
  if($Value -is [System.Collections.IEnumerable] -and $Value -isnot [System.Collections.IDictionary] -and $Value -isnot [pscustomobject]){foreach($item in $Value){Assert-VihanDisplayIds $item};return}
  foreach($p in $Value.PSObject.Properties){
    if(($p.Name -ceq 'id' -or $p.Name -cmatch '(Id|ID)$') -and $null -ne $p.Value){
      if($p.Value -isnot [string] -and $p.Value -isnot [ValueType]){throw 'Record identifiers must be scalar values'}
      $text=[string]$p.Value
      if($text.Length -gt 512 -or $text -match '[''"<>&\\`\x00-\x1F\u2028\u2029]'){throw 'Record identifier contains unsafe markup characters; legacy IDs require Admin review, not automatic rewriting'}
    }
    Assert-VihanDisplayIds $p.Value
  }
}
