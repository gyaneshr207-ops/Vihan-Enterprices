# VIHAN ENTERPRICES 1.0.38

यह existing software का security-repaired SOURCE package है। पहले `reports/security/SECURITY_REPORT_HI.md`, `TEST_REPORT_HI.md` और `WINDOWS_STORAGE_AND_ACTIVATION_HI.md` पढ़ें।

Server user sessions/company authorization, credential filtering/hashing, scoped protected offline copy और related regression tests जोड़े गए हैं। Existing page styles/navigation retained हैं। Production credential migration/activation नहीं की गई।

Windows/Main–Client/installer/TLS verification बाकी है; compiled .exe उपलब्ध नहीं। Existing HTTP transport network encryption नहीं देता। इसे 100% certified production build न मानें। Candidate migration/backup directories में business data हो सकती है; उन्हें GitHub/chat में upload न करें।
